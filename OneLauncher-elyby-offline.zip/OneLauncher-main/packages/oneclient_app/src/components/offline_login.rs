//! The offline account dialog both the settings page and onboarding raise it
//! offline accounts need no server they play under a derived uuid

use oneclient_core::LauncherError;

use crate::components::{Button, Icon, IconType, OverlayPopup, TextInput};
use crate::hooks::{AddOfflineAccountKeys, use_add_offline_account};
use crate::i18n::t;
use freya::prelude::*;
use freya::query::{MutationCapability, MutationStateData, UseMutation};
use crate::theme::{colors, rounded, text_size};
use crate::ui::border_all_color;

#[derive(Clone)]
pub struct OfflineLogin {
    add: UseMutation<crate::hooks::AddOfflineAccountMutation>,
    open: State<bool>,
    username: State<String>,
    pub pending: bool,
    pub error: Option<String>,
}

impl OfflineLogin {
    /// Opens the dialog the account is created once the user confirms
    pub fn start(&self) {
        self.open.set(true);
    }

    pub fn popup(&self) -> Option<impl IntoElement> {
        if !*self.open.read() {
            return None;
        }
        Some(offline_dialog(self.clone()))
    }
}

pub fn use_offline_login() -> OfflineLogin {
    let add = use_add_offline_account();
    let open = use_state(|| false);
    let username = use_state(String::new);

    // Only a success closes a duplicate-username error stays on screen
    use_side_effect(move || {
        if let MutationStateData::Settled { res: Ok(_), .. } = &*add.read().state() {
            open.set(false);
            username.set(String::new());
        }
    });

    let pending = add.read().state().is_loading();
    let error = mutation_err_text(&add);

    OfflineLogin {
        add,
        open,
        username,
        pending,
        error,
    }
}

/// Hooks live in [`use_offline_login`] this only renders so the popup can
/// appear and disappear without reshuffling the hook order
fn offline_dialog(handle: OfflineLogin) -> impl IntoElement {
    let username = handle.username;
    let name = username.read().trim().to_string();
    let uuid_preview = (!name.is_empty())
        .then(|| oneclient_auth::offline_uuid(&name).to_string());
    let error = handle.error.clone();
    let pending = handle.pending;

    let confirm = handle.clone();
    let on_confirm = move |_: Event<PressEventData>| {
        let name = confirm.username.peek().trim().to_string();
        if name.is_empty() {
            return;
        }
        confirm.add.mutate(AddOfflineAccountKeys { username: name });
    };

    let mut close = handle.clone();
    let cancel = handle.clone();
    OverlayPopup::new()
        .on_close(move |()| close.open.set(false))
        .child(
            rect()
                .width(Size::window_percent(100.))
                .height(Size::window_percent(100.))
                .center()
                .child(
                    rect()
                        .vertical()
                        .width(Size::px(380.))
                        .max_width(Size::window_percent(90.))
                        .spacing(16.)
                        .padding(Gaps::new_all(20.))
                        .corner_radius(rounded(16.))
                        .background(colors::page_elevated())
                        .border(border_all_color(1., colors::component_border()))
                        .child(
                            label()
                                .text(t("oneclient.settings.accounts.offline.title"))
                                .font_size(text_size(18.))
                                .font_weight(FontWeight::SEMI_BOLD)
                                .color(colors::fg_primary()),
                        )
                        .child(
                            rect()
                                .vertical()
                                .width(Size::fill())
                                .spacing(6.)
                                .child(field_label(t(
                                    "oneclient.settings.accounts.offline.username",
                                )))
                                .child(TextInput::new(username).placeholder(t(
                                    "oneclient.settings.accounts.offline.username_placeholder",
                                ))),
                        )
                        .child(
                            rect()
                                .vertical()
                                .width(Size::fill())
                                .spacing(6.)
                                .child(field_label("UUID"))
                                .child(
                                    label()
                                        .text(uuid_preview.unwrap_or_else(|| "-".to_string()))
                                        .font_size(text_size(12.))
                                        .color(colors::fg_secondary()),
                                ),
                        )
                        .map(error, |el, msg| {
                            el.child(hint_line(IconType::AlertTriangle, msg, colors::danger()))
                        })
                        .child(
                            rect()
                                .horizontal()
                                .width(Size::fill())
                                .main_align(Alignment::End)
                                .spacing(8.)
                                .child(
                                    Button::new()
                                        .ghost()
                                        .on_press(move |_| cancel.open.set(false))
                                        .text(t("oneclient.common.cancel")),
                                )
                                .child(
                                    Button::new()
                                        .primary()
                                        .enabled(!pending)
                                        .on_press(on_confirm)
                                        .child(Icon::new(IconType::Plus).size(16.))
                                        .text(t("oneclient.settings.accounts.offline.confirm")),
                                ),
                        ),
                ),
        )
        .into_element()
}

fn field_label(text: &str) -> impl IntoElement {
    label()
        .text(text.to_string())
        .font_size(text_size(11.))
        .font_weight(FontWeight::MEDIUM)
        .color(colors::fg_secondary())
        .into_element()
}

fn hint_line(icon: IconType, text: String, color: Color) -> impl IntoElement {
    rect()
        .horizontal()
        .width(Size::fill())
        .content(Content::Flex)
        .cross_align(Alignment::Center)
        .spacing(6.)
        .child(Icon::new(icon).size(13.).color(color))
        .child(
            label()
                .text(text)
                .font_size(text_size(12.))
                .width(Size::flex(1.0))
                .color(color),
        )
        .into_element()
}

fn mutation_err_text<M>(mutation: &UseMutation<M>) -> Option<String>
where
    M: MutationCapability<Err = LauncherError>,
{
    match &*mutation.read().state() {
        MutationStateData::Settled { res: Err(err), .. }
        | MutationStateData::Loading {
            res: Some(Err(err)),
        } => Some(err.to_string()),
        _ => None,
    }
}
