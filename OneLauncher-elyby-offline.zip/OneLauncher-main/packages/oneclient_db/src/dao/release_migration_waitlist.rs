use sqlx::SqlitePool;

use crate::models::ReleaseMigrationWaitlistRow;

#[allow(clippy::too_many_arguments)]
pub async fn upsert(
    pool: &SqlitePool,
    target_cluster_id: i64,
    provider: i64,
    project_id: &str,
    content_type: i64,
    source_hash: &str,
    display_name: &str,
    added_at: &str,
    expires_at: &str,
    enabled: bool,
) -> Result<(), sqlx::Error> {
    let enabled = i64::from(enabled);
    sqlx::query!(
        r"
		INSERT INTO release_migration_waitlist (
			target_cluster_id, provider, project_id, content_type,
			source_hash, display_name, added_at, expires_at, enabled
		)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
		ON CONFLICT(target_cluster_id, provider, project_id) DO UPDATE SET
			content_type = excluded.content_type,
			source_hash = excluded.source_hash,
			display_name = excluded.display_name,
			added_at = excluded.added_at,
			expires_at = excluded.expires_at,
			enabled = excluded.enabled
		",
        target_cluster_id,
        provider,
        project_id,
        content_type,
        source_hash,
        display_name,
        added_at,
        expires_at,
        enabled
    )
    .execute(pool)
    .await?;
    Ok(())
}

pub async fn list_all(pool: &SqlitePool) -> Result<Vec<ReleaseMigrationWaitlistRow>, sqlx::Error> {
    sqlx::query_as!(
        ReleaseMigrationWaitlistRow,
        r"
		SELECT
			target_cluster_id, provider, project_id, content_type,
			source_hash, display_name, expires_at, enabled
		FROM release_migration_waitlist
		",
    )
    .fetch_all(pool)
    .await
}

pub async fn delete(
    pool: &SqlitePool,
    target_cluster_id: i64,
    provider: i64,
    project_id: &str,
) -> Result<(), sqlx::Error> {
    sqlx::query!(
        "DELETE FROM release_migration_waitlist WHERE target_cluster_id = ? AND provider = ? AND project_id = ?",
        target_cluster_id,
        provider,
        project_id
    )
    .execute(pool)
    .await?;
    Ok(())
}

pub async fn delete_expired(pool: &SqlitePool, now: &str) -> Result<u64, sqlx::Error> {
    let result = sqlx::query!(
        "DELETE FROM release_migration_waitlist WHERE expires_at <= ?",
        now
    )
    .execute(pool)
    .await?;
    Ok(result.rows_affected())
}
