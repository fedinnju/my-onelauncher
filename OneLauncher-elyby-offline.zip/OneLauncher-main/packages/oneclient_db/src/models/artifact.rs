use serde::{Deserialize, Serialize};
use sqlx::FromRow;

#[derive(Debug, Clone, FromRow)]
pub struct ArtifactRow {
    pub hash: String,
    pub content_type: i64,
    pub path: String,
    pub file_name: String,
    pub size_bytes: Option<i64>,
}

#[derive(Debug, Clone, FromRow)]
pub struct ProviderReleaseRow {
    pub provider: i64,
    pub project_id: String,
    pub version_id: String,
    pub hash: String,
    pub display_name: String,
    pub display_version: String,
    pub published_at: Option<String>,
    pub mc_versions: String,
    pub mc_loaders: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[repr(i64)]
pub enum SeenStatus {
    New = 0,
    Updated = 1,
    #[default]
    Seen = 2,
}

impl SeenStatus {
    pub fn as_i64(self) -> i64 {
        self as i64
    }

    pub fn from_repr(value: i64) -> Option<Self> {
        match value {
            0 => Some(Self::New),
            1 => Some(Self::Updated),
            2 => Some(Self::Seen),
            _ => None,
        }
    }
}

#[derive(Debug, Clone, FromRow)]
pub struct ClusterArtifactRow {
    pub cluster_id: i64,
    pub hash: String,
    pub cluster_file_name: String,
    pub enabled: i64,
    pub seen_status: i64,
}

impl ClusterArtifactRow {
    pub fn status(&self) -> SeenStatus {
        SeenStatus::from_repr(self.seen_status).unwrap_or_default()
    }
}

#[derive(Debug, Clone, FromRow)]
pub struct LinkedArtifactRow {
    pub hash: String,
    pub cluster_file_name: String,
    pub enabled: i64,
    pub seen_status: i64,
    pub content_type: i64,
    pub file_name: String,
    pub size_bytes: Option<i64>,
    pub provider: Option<i64>,
    pub project_id: Option<String>,
    pub version_id: Option<String>,
    pub display_name: Option<String>,
    pub display_version: Option<String>,
    pub published_at: Option<String>,
    pub added_at: Option<String>,
}

// used for resourcepacks and shaders
#[derive(Debug, Clone, FromRow)]
pub struct GlobalArtifactRow {
    pub hash: String,
    pub file_name: String,
    pub enabled: i64,
}

/// One entry of a release's declared dependency list.
///
/// Either id may be empty: the providers pin a project, a version, or both.
#[derive(Debug, Clone, FromRow)]
pub struct ReleaseDependencyRow {
	pub dependency_project_id: String,
	pub dependency_version_id: String,
	pub kind: String,
}

/// A dependency declared by an artifact the cluster has installed.
///
/// The edge points the way the provider wrote it — `hash` needs
/// `dependency_project_id` — so a caller after the reverse graph inverts it.
#[derive(Debug, Clone, FromRow)]
pub struct ClusterDependencyEdgeRow {
	/// The installed artifact that declares the dependency.
	pub hash: String,
	pub provider: i64,
	pub dependency_project_id: String,
	pub dependency_version_id: String,
	pub kind: String,
}

/// A release the cluster has installed whose dependency list was never
/// recorded.
#[derive(Debug, Clone, FromRow)]
pub struct UnsyncedReleaseRow {
	pub provider: i64,
	pub project_id: String,
	pub version_id: String,
}
