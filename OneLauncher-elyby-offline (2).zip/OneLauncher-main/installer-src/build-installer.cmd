@echo off
setlocal enabledelayedexpansion

REM ============================================================================
REM Builds the OneClient installer that installs YOUR launcher build
REM (the ely.by / offline-account fork) - full offline installer, no downloads.
REM
REM Run from the ROOT of the fork (OneLauncher-main):
REM     installer-src\build-installer.cmd
REM
REM Requirements (on Windows):
REM   - Rust toolchain (MSVC)            https://rustup.rs
REM   - Python 3                         https://python.org
REM   - Visual Studio 2022 Build Tools   (needed to build and for the CRT DLLs)
REM   - NSIS 3 (makensis.exe on PATH)    https://nsis.sourceforge.io
REM
REM Result: installer-src\oneclient_app_2.10.2_x64-setup.exe - the same
REM original installer, but with YOUR launcher (ely.by + offline accounts)
REM embedded inside. Works fully offline.
REM ============================================================================

set "ROOT=%~dp0.."
pushd "%ROOT%"

echo [1/5] Building the launcher (release)...
cargo build --release --bin oneclient_app || goto :fail
if not exist target\release\oneclient_app.exe (
    echo ERROR: target\release\oneclient_app.exe was not built
    goto :fail
)

echo [2/5] Staging app-local VC++ runtime DLLs...
rem Try "python", fall back to the "py" launcher if python is not on PATH.
set "PY=python"
python --version >nul 2>nul || set "PY=py -3"
%PY% --version >nul 2>nul || (
    echo ERROR: Python not found. Install Python 3 with "Add python.exe to PATH".
    goto :fail
)
%PY% distribution\windows\bundle-crt.py || goto :fail

echo [3/5] Collecting payload...
if not exist installer-src\payload mkdir installer-src\payload
copy /y target\release\oneclient_app.exe installer-src\payload\ || goto :fail
copy /y target\crt\*.dll installer-src\payload\ || goto :fail

set SIZE=0
for %%F in (installer-src\payload\*) do set /a SIZE+=%%~zF
set /a SIZE+=1023
set /a SIZE/=1024

echo [4/5] Compiling installer ^(payload: !SIZE! KB^)...
rem Find makensis: on PATH first, then standard NSIS install locations.
set "MAKENSIS="
where makensis >nul 2>nul && set "MAKENSIS=makensis"
if not defined MAKENSIS if exist "%ProgramFiles(x86)%\NSIS\makensis.exe" set "MAKENSIS=%ProgramFiles(x86)%\NSIS\makensis.exe"
if not defined MAKENSIS if exist "%ProgramFiles%\NSIS\makensis.exe" set "MAKENSIS=%ProgramFiles%\NSIS\makensis.exe"
if not defined MAKENSIS if exist "%LOCALAPPDATA%\Programs\NSIS\makensis.exe" set "MAKENSIS=%LOCALAPPDATA%\Programs\NSIS\makensis.exe"
if not defined MAKENSIS (
    echo ERROR: makensis.exe not found. Install NSIS 3 ^(https://nsis.sourceforge.io^).
    goto :fail
)
"%MAKENSIS%" /DESTIMATEDSIZE=!SIZE! installer-src\installer.nsi || goto :fail

echo [5/5] Done.
echo Installer with YOUR build: installer-src\oneclient_app_2.10.2_x64-setup.exe
popd
exit /b 0

:fail
popd
echo.
echo build-installer.cmd FAILED
exit /b 1
