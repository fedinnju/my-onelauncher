Файлы, которые кладутся сюда перед сборкой установщика:

  oneclient_app.exe  - собранный лаунчер (твоя версия с Ely.by и оффлайн-аккаунтами)
  *.dll              - VC++ runtime DLL (кладёт build-installer.cmd из target\crt\)

Пустой папкой установщик не соберётся. Заполняется автоматически скриптом
build-installer.cmd, либо вручную (см. README.md в папке installer-src).
