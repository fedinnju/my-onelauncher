# Установщик OneClient, который ставит ТВОЮ версию (Ely.by + оффлайн)

Это переделанный оригинальный инсталлер `oneclient_app_2.10.2_x64-setup.exe`.

Сделано на основе того же самого шаблона NSIS (cargo-packager 0.11.8), которым
Polyfrost собирает оригинал: те же страницы, папка установки, ярлыки, записи
реестра, деинсталлятор и флаги командной строки (`/S`, `/P`, `/NS`, `/R`, `/D=`).

**Главное отличие от прошлой версии: никаких скачиваний.** Лаунчер и VC++ runtime
DLL **вшиты внутрь инсталлера** (папка `payload\`) — ровно так же, как это делает
оригинальный инсталлер. Установщик работает полностью офлайн и ставит всегда
твою сборку с Ely.by и оффлайн-аккаунтами.

## Состав папки

| Файл | Что это |
| --- | --- |
| `installer.nsi` | Скрипт оригинального инсталлера (офлайн-вариант: payload вшит) |
| `build-installer.cmd` | Собирает твою версию лаунчера и упаковывает её в инсталлер — одной командой |
| `English.nsh`, `FileAssociation.nsh` | Файлы оригинального шаблона (не менялись) |
| `plugins\` | Плагины NSIS из оригинального инсталлера (ApplicationID, nsis_tauri_utils) |
| `payload\` | Сюда кладётся собранный `oneclient_app.exe` + CRT DLL перед сборкой |

## Способ 1 (на Windows, одной командой)

Из корня распакованного форка (OneLauncher-main):

```bat
installer-src\build-installer.cmd
```

Скрипт сам: соберёт лаунчер (`cargo build --release`), положит рядом с exe
VC++ runtime DLL (`distribution\windows\bundle-crt.py`, как в официальных сборках),
упакует всё в `installer-src\oneclient_app_2.10.2_x64-setup.exe` через makensis.

Нужно только: Rust (MSVC), Python 3, Visual Studio Build Tools, NSIS 3 на PATH.

## Способ 2 (без установки чего-либо — сборка на GitHub, только браузер) — РЕКОМЕНДУЕТСЯ

Ничего устанавливать не нужно: Rust/Cargo/NSIS не требуются, всё собирает
сервер GitHub. Понадобятся всего два файла: `OneLauncher-elyby-offline.zip`
и `github-build.yml` (лежит рядом, в папке `download/`).

Пошагово — в файле `КАК-СОБРАТЬ-НА-GITHUB.md`. Коротко:

1. Создай **публичный** репозиторий на GitHub (New repository → Public → с README).
2. «uploading an existing file» → перетащи **один файл** `OneLauncher-elyby-offline.zip` → Commit changes.
3. **Add file → Create new file** → имя `.github/workflows/build.yml` → вставь содержимое `github-build.yml` → Commit changes.
4. Сборка стартует сама (вкладка Actions), ~40–60 минут.
5. В завершившемся запуске внизу, раздел **Artifacts**, скачай `OneClient-windows-setup` →
   внутри `oneclient_app_2.10.2_x64-setup.exe` — оригинальный инсталлер, ставящий твою версию.

## Способ 3 (GitHub, если загрузил весь исходник репозитория)

В исходники форка (`OneLauncher-elyby-offline.zip`) уже добавлен workflow
`.github/workflows/build_installer.yml`: если загрузить в репозиторий всё
содержимое zip (например, через GitHub Desktop), то **OneClient Installer Build**
соберёт тот же самый инсталлер (Actions → Run workflow, если не запустился сам).

## Способ 4 (вручную, без build-installer.cmd)

```bat
cargo build --release --bin oneclient_app
python distribution\windows\bundle-crt.py
copy target\release\oneclient_app.exe installer-src\payload\
copy target\crt\*.dll installer-src\payload\
makensis installer-src\installer.nsi
```

## Заметки

- Название продукта, версия и прочее в `installer.nsi` намеренно оставлены как
  в оригинале (OneClient 2.10.2) — меняется только то, что внутри.
- Если поменяешь версию в `Cargo.toml`, поправь `!define VERSION` в `installer.nsi`.
- Размер для «Программы и компоненты» (`EstimatedSize`) подставляется
  `build-installer.cmd` автоматически (`makensis /DESTIMATEDSIZE=...`).
- Скрипт проверен компиляцией makensis 3.11: ноль ошибок/предупреждений,
  payload ~71 MB сжимается в ~23 MB (solid LZMA, как в оригинале).
