use std::ffi::OsString;
use std::path::{Path, PathBuf};

use oneclient_db::DbPool;
use oneclient_db::dao::game_session as session_dao;
use oneclient_db::models::{ArtifactRow, ClusterRow};

use crate::error::ContentResult;
use oneclient_common::domain::ContentType;
use oneclient_common::paths;

use super::manifest;
use super::paths::artifact_absolute_path;

const STAGING_SUFFIX: &str = ".oneclient-tmp";

pub(crate) fn shares_content(cluster: &ClusterRow, content_type: ContentType) -> bool {
    content_type.is_global() && crate::modpacks::shares_game_dir(cluster)
}

pub async fn sharing_cluster_ids(
    db: &DbPool,
    group: Option<&str>,
) -> Result<Vec<i64>, sqlx::Error> {
    Ok(oneclient_db::dao::cluster::list_all(db)
        .await?
        .into_iter()
        .filter(|cluster| {
            crate::modpacks::shares_game_dir(cluster)
                && paths::cluster_shared_group(&cluster.folder_name).as_deref() == group
        })
        .map(|cluster| cluster.id)
        .collect())
}

pub async fn sharing_with(db: &DbPool, cluster: &ClusterRow) -> Result<Vec<i64>, sqlx::Error> {
    sharing_cluster_ids(
        db,
        paths::cluster_shared_group(&cluster.folder_name).as_deref(),
    )
    .await
}

/// What a live add actually did, so a caller can say so instead of promising
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LiveSync {
    /// The file is in the running game's folder now
    Applied,
    /// It could not be put there; it arrives at the next launch instead
    Deferred,
    /// Nothing to do: this content type never reloads, or no session owns the folder
    Skipped,
}

/// so a rerun that died mid-way leaves atleast one stale file, that next rerun clears anyways
fn staging_path(dest: &Path) -> PathBuf {
    let mut name = OsString::from(".");
    name.push(dest.file_name().unwrap_or_else(|| "entry".as_ref()));
    name.push(STAGING_SUFFIX);

    dest.with_file_name(name)
}

/// A launcher killed between the copy and the rename leaves one of these behind
/// and every other pass over these folders skips dotfiles
#[tracing::instrument(level = "debug")]
pub async fn sweep_staging_files(dir: &Path) {
    let Ok(mut entries) = polyio::read_dir(dir).await else {
        return;
    };

    while let Ok(Some(entry)) = entries.next_entry().await {
        let path = entry.path();
        let Some(name) = path.file_name().and_then(|name| name.to_str()) else {
            continue;
        };

        if !name.starts_with('.') || !name.ends_with(STAGING_SUFFIX) {
            continue;
        }

        if let Err(err) = remove_entry(&path).await {
            tracing::debug!(file = name, error = %err, "failed to clear a stale staging file");
        }
    }
}

/// written to a staging name and renamed into place so the destination is never missing even for a moment
#[tracing::instrument(level = "debug")]
pub async fn link_or_copy(src: &Path, dest: &Path) -> ContentResult<()> {
    if let Some(parent) = dest.parent() {
        polyio::create_dir_all(parent).await?;
    }

    let staging = staging_path(dest);
    remove_entry(&staging).await?;

    if polyio::symlink_file(src, &staging).await.is_err() {
        polyio::copy(src, &staging).await?;
    }

    if let Err(err) = polyio::rename(&staging, dest).await {
        remove_entry(&staging).await.ok();
        return Err(err.into());
    }

    Ok(())
}

pub async fn remove_entry(path: &Path) -> ContentResult<()> {
    if polyio::symlink_metadata(path).await.is_err() {
        return Ok(());
    }

    polyio::remove_file(path).await?;
    Ok(())
}

pub async fn drop_unmanaged_mod(
    cluster: &ClusterRow,
    content_type: ContentType,
    file_name: &str,
    hash: &str,
    db: &DbPool,
) {
    if content_type != ContentType::Mod || session_owns(cluster, db).await {
        return;
    }
    let Ok(dir) = paths::cluster_dir(&cluster.folder_name) else {
        return;
    };
    if manifest::mods_live_in_cluster(&dir).await {
        return;
    }

    let path = dir.join(content_type.folder_name()).join(file_name);
    let linked = polyio::sha1_file(&path)
        .await
        .is_ok_and(|disk| polyio::normalize_hash(&disk) == hash);
    if linked && let Err(err) = remove_entry(&path).await {
        tracing::debug!(file = file_name, error = %err, "could not drop the unlinked mod from the cluster folder");
    }
}

async fn materialized_root(
    cluster: &ClusterRow,
    content_type: ContentType,
) -> Option<(PathBuf, &'static str)> {
    if shares_content(cluster, content_type) {
        return paths::cluster_shared_dir(&cluster.folder_name)
            .ok()
            .map(|dir| (dir, manifest::GLOBAL_MANIFEST_NAME));
    }

    if content_type == ContentType::Mod
        && let Ok(dir) = paths::cluster_dir(&cluster.folder_name)
        && manifest::mods_live_in_cluster(&dir).await
    {
        return Some((dir, manifest::MODS_MANIFEST_NAME));
    }

    paths::cluster_game_dir(&cluster.folder_name, cluster.is_isolated())
        .ok()
        .map(|dir| (dir, manifest::MANIFEST_NAME))
}

async fn session_owns(cluster: &ClusterRow, db: &DbPool) -> bool {
    let Ok(game_dir) = paths::cluster_game_dir(&cluster.folder_name, cluster.is_isolated()) else {
        return false;
    };

    let owned = manifest::load(&game_dir, manifest::MANIFEST_NAME)
        .await
        .is_some_and(|session| session.cluster_id == cluster.id);

    if !owned || !cluster.is_isolated() {
        return owned;
    }

    match session_dao::unfinished_sessions(db).await {
        Ok(sessions) => sessions
            .iter()
            .any(|session| session.cluster_id == cluster.id),
        Err(err) => {
            tracing::debug!(error = %err, "cannot tell whether the instance is running; treating it as running");
            true
        }
    }
}

#[tracing::instrument(level = "debug", skip(cluster, db), fields(cluster_id = cluster.id))]
pub async fn try_unlink_materialized(
    cluster: &ClusterRow,
    content_type: ContentType,
    file_name: &str,
    db: &DbPool,
) -> LiveSync {
    if !content_type.reloads_in_game() && session_owns(cluster, db).await {
        tracing::debug!(
            file = file_name,
            "file will be moved at next launch due to an active session"
        );
        return LiveSync::Deferred;
    }

    let Some((root, manifest_name)) = materialized_root(cluster, content_type).await else {
        return LiveSync::Deferred;
    };

    let _guard = manifest::lock().await;

    let Some(mut loaded) = manifest::load(&root, manifest_name).await else {
        return LiveSync::Skipped;
    };

    let relative = manifest::entry_path(content_type.folder_name(), file_name);
    let ours = if shares_content(cluster, content_type) {
        loaded.contains(&relative)
    } else {
        loaded.owns(cluster.id, &relative)
    };

    if !ours {
        return LiveSync::Skipped;
    }

    let path = root.join(&relative);
    if let Err(err) = remove_entry(&path).await {
        tracing::debug!(
            file = file_name,
            error = %err,
            "could not drop package from the game folder now; it goes at the next launch"
        );
        return LiveSync::Deferred;
    }

    loaded.entries.retain(|entry| entry.path != relative);
    manifest::save(&root, manifest_name, &loaded).await;

    LiveSync::Applied
}

#[tracing::instrument(level = "debug", skip(cluster, artifact), fields(cluster_id = cluster.id, hash = %artifact.hash))]
pub async fn try_link_materialized(
    cluster: &ClusterRow,
    artifact: &ArtifactRow,
    file_name: &str,
) -> LiveSync {
    let Some(content_type) = ContentType::from_repr(artifact.content_type as u8) else {
        return LiveSync::Skipped;
    };

    if !content_type.reloads_in_game() {
        return LiveSync::Skipped;
    }

    let Some((root, manifest_name)) = materialized_root(cluster, content_type).await else {
        return LiveSync::Deferred;
    };

    let Ok(src) = artifact_absolute_path(&artifact.path) else {
        return LiveSync::Deferred;
    };

    if !polyio::try_exists(&src).await.unwrap_or(false) {
        tracing::warn!(hash = %artifact.hash, "cached artifact missing; leaving it to the next launch");
        return LiveSync::Deferred;
    }

    let _guard = manifest::lock().await;

    // No manifest means nothing is playing out of this folder right now
    let Some(mut loaded) = manifest::load(&root, manifest_name).await else {
        return LiveSync::Skipped;
    };

    if !shares_content(cluster, content_type) && loaded.cluster_id != cluster.id {
        return LiveSync::Deferred;
    }

    let relative = manifest::entry_path(content_type.folder_name(), file_name);
    let dest = root.join(&relative);

    let ours = if shares_content(cluster, content_type) {
        loaded.contains(&relative)
    } else {
        loaded.owns(cluster.id, &relative)
    };

    // Same rule as the unlink path: never write over a file we did not place
    if !ours && polyio::symlink_metadata(&dest).await.is_ok() {
        tracing::debug!(
            file = file_name,
            "a file we do not own already sits in the game folder; leaving it to the next launch"
        );
        return LiveSync::Deferred;
    }

    if let Err(err) = link_or_copy(&src, &dest).await {
        tracing::debug!(
            file = file_name,
            error = %err,
            "could not add the pack to the running game; it goes in at the next launch"
        );
        return LiveSync::Deferred;
    }

    loaded.entries.retain(|entry| entry.path != relative);
    loaded.entries.push(manifest::ManifestEntry {
        path: relative,
        hash: artifact.hash.clone(),
    });
    manifest::save(&root, manifest_name, &loaded).await;

    LiveSync::Applied
}

#[cfg(test)]
mod tests {
    use super::*;

    fn cluster() -> ClusterRow {
        ClusterRow {
            id: 1,
            name: "Test".into(),
            folder_name: "test".into(),
            setting_profile_name: None,
            mc_version: "1.21.1".into(),
            mc_loader: 0,
            stage: 0,
            mc_loader_version: None,
            created_at: None,
            last_played: None,
            overall_played: None,
            linked_modpack_hash: None,
            kind: 0,
            user_created: 0,
            description: None,
            tags: "[]".into(),
            cover_path: None,
        }
    }

    fn artifact(content_type: ContentType) -> ArtifactRow {
        ArtifactRow {
            hash: "abc".into(),
            content_type: content_type as i64,
            path: "packages/whatever".into(),
            file_name: "thing".into(),
            size_bytes: None,
        }
    }

    #[tokio::test]
    async fn a_mod_is_never_added_to_a_running_game() {
        assert_eq!(
            try_link_materialized(&cluster(), &artifact(ContentType::Mod), "sodium.jar").await,
            LiveSync::Skipped
        );
        assert_eq!(
            try_link_materialized(&cluster(), &artifact(ContentType::World), "world.zip").await,
            LiveSync::Skipped
        );
    }

    #[tokio::test]
    async fn a_stale_staging_file_is_swept() {
        let root = polyio::testing::ScratchDir::new("sweep_staging");
        let dir = root.path();
        polyio::create_dir_all(dir).await.unwrap();

        let orphan = staging_path(&dir.join("pack.zip"));
        polyio::write(&orphan, b"half a copy".as_slice())
            .await
            .unwrap();
        polyio::write(dir.join("keep.zip"), b"pack".as_slice())
            .await
            .unwrap();

        sweep_staging_files(dir).await;

        assert!(polyio::symlink_metadata(&orphan).await.is_err());
        assert!(polyio::symlink_metadata(dir.join("keep.zip")).await.is_ok());

        std::fs::remove_dir_all(root.path()).ok();
    }

    #[cfg(not(windows))]
    #[tokio::test]
    async fn remove_entry_clears_a_dangling_link() {
        let root = polyio::testing::ScratchDir::new("dangling_link");
        let dir = root.path();
        polyio::create_dir_all(dir).await.unwrap();

        let target = dir.join("target.jar");
        let link = dir.join("link.jar");
        polyio::write(&target, b"jar".as_slice()).await.unwrap();
        polyio::symlink_file(&target, &link).await.unwrap();
        polyio::remove_file(&target).await.unwrap();

        assert!(!link.exists(), "the link resolves to nothing");
        assert!(
            polyio::symlink_metadata(&link).await.is_ok(),
            "but the link itself is still there"
        );

        remove_entry(&link).await.unwrap();
        assert!(polyio::symlink_metadata(&link).await.is_err());

        std::fs::remove_dir_all(root.path()).ok();
    }

    #[cfg(windows)]
    #[tokio::test]
    async fn remove_entry_clears_a_hard_link() {
        let root = polyio::testing::ScratchDir::new("hard_link");
        let dir = root.path();
        polyio::create_dir_all(dir).await.unwrap();

        let target = dir.join("target.jar");
        let link = dir.join("link.jar");
        polyio::write(&target, b"jar".as_slice()).await.unwrap();
        polyio::symlink_file(&target, &link).await.unwrap();
        polyio::remove_file(&target).await.unwrap();

        assert!(link.exists(), "the link is still holding the file");

        remove_entry(&link).await.unwrap();
        assert!(polyio::symlink_metadata(&link).await.is_err());

        std::fs::remove_dir_all(root.path()).ok();
    }

    #[tokio::test]
    async fn replacing_a_pack_leaves_only_the_pack() {
        let root = polyio::testing::ScratchDir::new("atomic_replace");
        let dir = root.path();
        polyio::create_dir_all(dir).await.unwrap();

        let old = dir.join("old.zip");
        let new = dir.join("new.zip");
        polyio::write(&old, b"old".as_slice()).await.unwrap();
        polyio::write(&new, b"new".as_slice()).await.unwrap();

        let packs = dir.join("resourcepacks");
        let dest = packs.join("pack.zip");

        link_or_copy(&old, &dest).await.unwrap();
        link_or_copy(&new, &dest).await.unwrap();

        assert_eq!(polyio::read_to_string(&dest).await.unwrap(), "new");

        let mut names = Vec::new();
        let mut entries = polyio::read_dir(&packs).await.unwrap();
        while let Ok(Some(entry)) = entries.next_entry().await {
            names.push(entry.file_name().to_string_lossy().into_owned());
        }

        assert_eq!(names, vec!["pack.zip".to_string()]);

        std::fs::remove_dir_all(root.path()).ok();
    }

    /// A crash between the write and the rename must not wedge the next attempt
    #[tokio::test]
    async fn a_stale_staging_file_is_cleared() {
        let root = polyio::testing::ScratchDir::new("stale_staging");
        let dir = root.path();
        polyio::create_dir_all(dir).await.unwrap();

        let src = dir.join("src.zip");
        let dest = dir.join("pack.zip");
        polyio::write(&src, b"real".as_slice()).await.unwrap();
        polyio::write(staging_path(&dest), b"junk".as_slice())
            .await
            .unwrap();

        link_or_copy(&src, &dest).await.unwrap();

        assert_eq!(polyio::read_to_string(&dest).await.unwrap(), "real");
        assert!(
            polyio::symlink_metadata(staging_path(&dest)).await.is_err(),
            "the staging file is consumed by the rename"
        );

        std::fs::remove_dir_all(root.path()).ok();
    }

    #[tokio::test]
    async fn remove_entry_is_fine_with_nothing_there() {
        let root = polyio::testing::ScratchDir::new("remove_missing");
        polyio::create_dir_all(root.path()).await.unwrap();

        remove_entry(&root.join("never_existed.jar")).await.unwrap();

        std::fs::remove_dir_all(root.path()).ok();
    }
}
