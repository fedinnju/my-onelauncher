use oneclient_cluster::profiles::list_named_profiles;
use oneclient_common::domain::GameLoader;
use oneclient_core::clusters::CreateClusterOptions;
use oneclient_core::dev;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    tracing_subscriber::fmt::init();

    let state = dev::ephemeral_state().await?;
    let global = state.settings.read().global_game_settings.clone();

    let cluster = state
        .clusters
        .create(
            &global,
            CreateClusterOptions::new("Example 1.21.1 Fabric", "1.21.1", GameLoader::Fabric)
                .mem_max(3072),
        )
        .await?;

    println!(
        "Created cluster #{} at folder '{}'",
        cluster.id, cluster.folder_name
    );
    println!("  setting profile: {:?}", cluster.setting_profile_name);
    println!("  created at: {:?}", cluster.created_at);

    let profile = state.clusters.resolve_settings(&global, &cluster).await?;
    println!(
        "  resolved mem_max: {:?}, force_fullscreen: {:?}",
        profile.mem_max, profile.force_fullscreen
    );

    for c in state.clusters.list().await? {
        println!("  - {} ({}, {})", c.name, c.mc_version, c.mc_loader);
    }

    for p in list_named_profiles(&state.services.db).await? {
        println!("Profile {} (mem_max: {:?})", p.name, p.mem_max);
    }

    state.clusters.delete(cluster.id, true).await?;
    println!("Deleted cluster #{}", cluster.id);

    Ok(())
}
