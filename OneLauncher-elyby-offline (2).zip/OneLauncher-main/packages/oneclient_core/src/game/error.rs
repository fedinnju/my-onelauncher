use thiserror::Error;

#[derive(Debug, Error)]
pub enum GameError {
    #[error("no client download exists for version {0}")]
    NoClientDownload(String),

    #[error("failed to resolve library artifact path for {0}")]
    LibraryPath(String),

    #[error("download hash mismatch for {path}: expected {expected}, got {actual}")]
    HashMismatch {
        path: String,
        expected: String,
        actual: String,
    },

    #[error("cluster is missing a required Java version")]
    MissingJavaVersion,

    #[error("forge processor failed: {0}")]
    ProcessorFailed(String),

    #[error("processor main class not found for {0}")]
    ProcessorMainClass(String),

    #[error("cluster {0} is already running")]
    AlreadyRunning(i64),

    #[error("another cluster ({0}) is already running in the same directory")]
    DirectoryInUse(i64),

    #[error(
        "{0} is already running in the shared game directory; close it before launching another cluster"
    )]
    SharedDirectoryBusy(String),

    #[error("this instance is being reset; wait for the reset to finish before launching it")]
    Resetting,

    #[error(
        "this instance's last reset didn't finish; run Reset Instance again from its settings before launching it"
    )]
    ResetUnfinished,

    #[error("this instance is syncing from the shared folder; wait for it to finish")]
    Syncing,

    #[error("{0} is syncing from the shared folder; wait for it to finish before launching")]
    SharedDirectorySyncing(String),

    #[error(
        "the shared folder {0} is missing; pick a folder for this instance in its settings before launching"
    )]
    SharedFolderMissing(String),

    #[error("failed to spawn the game process: {0}")]
    Spawn(String),

    #[error(
        "the wrapper command '{program}' could not be started: {reason}. Check the Wrapper Command setting."
    )]
    WrapperSpawn { program: String, reason: String },

    #[error("start the game once on this version before changing this setting")]
    OptionsOutdated,
}

impl GameError {
    pub(crate) fn wrapper_spawn(program: &str, err: &std::io::Error) -> Self {
        let reason = match err.kind() {
            std::io::ErrorKind::NotFound => "command not found".to_string(),
            std::io::ErrorKind::PermissionDenied => {
                "insufficient permissions or file is not an executable".to_string()
            }
            _ => err.to_string(),
        };

        Self::WrapperSpawn {
            program: program.to_string(),
            reason,
        }
    }
}
