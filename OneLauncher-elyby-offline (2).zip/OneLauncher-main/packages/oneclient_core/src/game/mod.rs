mod analytics;
mod authlib;
mod error;
pub mod fabric;
mod folder_packs;
mod game_options;
pub mod gpu;
mod heal;
mod launch;
mod log_replay;
pub(crate) mod natives;
mod process;
mod reattach;
mod session;
mod shared_dir;
mod tail;

pub use analytics::{
    Analytics, DayPlaytime, Persona, PlaytimeStats, ServerStat, WEEKDAY_LABELS, aggregate_servers,
    cluster_analytics, global_analytics,
};
pub use authlib::{ely_agent_jvm_arg, ensure_ely_agent};
pub use oneclient_mc::{
    append_profile_game_arguments, classpaths, download_to_path, fetch_bytes_verified,
    get_classpath_library, get_library, java_arguments, main_class, minecraft_arguments,
    processor_arguments,
};
pub mod crashdata;
pub mod diagnosis;
pub mod mod_problems;

pub use crashdata::CrashData;
pub use diagnosis::{CrashDiagnosis, diagnose, suspected_mods};
pub use error::GameError;
pub use fabric::{mods_folder_argument, uses_cluster_mods_folder};
pub use folder_packs::{
    FolderPack, list_folder_packs, remove_folder_pack, set_folder_pack_enabled,
};
pub use game_options::{read_graphics_backend, write_graphics_backend};
pub use heal::clear_zeroed_files;
pub use launch::{
    LaunchedGame, crash_mod_issues, is_running, launch_cluster, launch_cluster_with, repair_cluster,
};
pub use mod_problems::{ModProblem, ModProblemKind, ModRef};
pub use oneclient_mc::{
    DownloadPlan, GameVersionInfo, GameVersionKind, NativesMode, NativesReport, PlannedLibrary,
    check_natives, confirm_incomplete_install, download_minecraft, download_version_info,
    game_files_missing, get_game_versions, get_loader_version, get_loader_versions,
    get_loaders_for_version, get_version_ids, get_versions_for_loader, is_version_updated,
    libraries_missing, natives_missing, plan_downloads, resolve_minecraft_version, validate_rules,
    verify_game_files,
};
pub use process::{
    DirBusy, GameProcess, GameProcessManager, SyncBlock, SyncGuard, is_process_alive, kill_process,
    process_start_time,
};
pub use reattach::recover_sessions;
pub(crate) use shared_dir::lock_mods_sync;
pub use shared_dir::{
    DuplicateMods, dematerialize_content, import_manual_content, join_shared_folder,
    leave_shared_folder, link_cluster_logs, materialize_content, shadowed_bundle_mods,
    split_dedicated_packs, sync_cluster_mods, unlink_cluster_logs, write_allowed_symlinks,
};
