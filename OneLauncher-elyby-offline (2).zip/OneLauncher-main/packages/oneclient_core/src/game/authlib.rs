//! authlib-injector agent management
//! Ely.by sessions only work inside the game when a small Java agent reroutes
//! the game's session requests at Ely.by the agent is a pinned release that is
//! downloaded once into the libraries folder and then reused

use std::path::PathBuf;

use oneclient_common::{constants, paths};
use oneclient_events::EventBus;
use oneclient_net::{RequestClient, download_verified};

use crate::LauncherResult;

/// `-javaagent:{jar}={ely.by metadata root}` everything the agent needs rides
/// in this single JVM argument
pub fn ely_agent_jvm_arg(agent_path: &std::path::Path) -> String {
    format!(
        "-javaagent:{}={}",
        agent_path.display(),
        constants::ELY_BY_AUTHLIB_INJECTOR_URL
    )
}

/// The jar lives next to the real game libraries so a launcher reset keeps it
fn agent_jar_path() -> Result<PathBuf, oneclient_common::PathsError> {
    Ok(paths::libraries_dir()?.join(format!(
        "authlib-injector/authlib-injector-{}.jar",
        constants::AUTHLIB_INJECTOR_VERSION
    )))
}

/// Returns the agent jar downloading it first if this is the first Ely.by
/// launch the sha1 pins the download to the audited release
#[tracing::instrument(level = "debug", skip(requester, events))]
pub async fn ensure_ely_agent(
    requester: &RequestClient,
    events: &EventBus,
) -> LauncherResult<PathBuf> {
    let dest = agent_jar_path()?;

    if dest.is_file() {
        return Ok(dest);
    }

    tracing::info!(
        version = constants::AUTHLIB_INJECTOR_VERSION,
        dest = %dest.display(),
        "downloading authlib-injector agent"
    );

    let expected = polyio::Checksum::sha1(constants::AUTHLIB_INJECTOR_JAR_SHA1);
    download_verified(
        requester,
        events,
        constants::AUTHLIB_INJECTOR_JAR_URL,
        &dest,
        Some(&expected),
        constants::AUTHLIB_INJECTOR_JAR_SIZE,
        None,
    )
    .await?;

    Ok(dest)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_jvm_argument_carries_both_the_jar_and_the_metadata_root() {
        let arg = ely_agent_jvm_arg(std::path::Path::new("/tmp/lib/authlib-injector-1.2.8.jar"));

        assert_eq!(
            arg,
            "-javaagent:/tmp/lib/authlib-injector-1.2.8.jar=https://authserver.ely.by/api/authlib-injector"
        );
    }
}
