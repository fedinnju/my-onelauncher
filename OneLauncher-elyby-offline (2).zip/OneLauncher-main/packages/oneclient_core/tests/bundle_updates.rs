use std::collections::{HashMap, HashSet};
use std::sync::Arc;

use oneclient_common::domain::{ContentType, GameLoader, ProviderId};
use oneclient_content::ContentCtx;
use oneclient_content::bundles::{
    BundleFile, BundleFileKind, BundleFileType, BundleManifest, check_bundle_updates,
    get_bundles_with_update_status, install_cluster_bundles, on_user_disable_artifact,
    on_user_remove_artifact, set_bundle_package_enabled, wanted_bundle_files,
};
use oneclient_core::LauncherState;
use oneclient_core::clusters::CreateClusterOptions;
use oneclient_db::dao::cluster::ClusterMigration;
use oneclient_db::dao::{
    artifact as artifact_dao, cluster as cluster_dao, cluster_bisect as bisect_dao,
    cluster_bundle as bundle_dao,
};
use oneclient_db::models::OverrideType;

const BUNDLE: &str = "Test Bundle";
const MC_VERSION: &str = "1.21.1";
const PROJECT_ID: &str = "sodium";
const VERSION_ID: &str = "v1";
const HASH: &str = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
const SHARED_BUNDLE: &str = "Shared Bundle";
const FABRIC_API_HASH: &str = "dddddddddddddddddddddddddddddddddddddddd";
const HIDDEN_DEP_HASH: &str = "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee";

fn managed_file(enabled: bool) -> BundleFile {
    BundleFile {
        enabled,
        hidden: false,
        path: "mods/sodium.jar".to_string(),
        size: 1,
        file_type: BundleFileType::Normal,
        kind: BundleFileKind::Managed {
            provider: ProviderId::Modrinth,
            project_id: PROJECT_ID.to_string(),
            version_id: VERSION_ID.to_string(),
            sha1: HASH.to_string(),
        },
    }
}

/// Added by the catalog after the last sync untracked so it has no override
fn newly_shipped_file() -> BundleFile {
    BundleFile {
        enabled: true,
        hidden: false,
        path: "mods/newcomer.jar".to_string(),
        size: 1,
        file_type: BundleFileType::Normal,
        kind: BundleFileKind::Managed {
            provider: ProviderId::Modrinth,
            project_id: "newcomer".to_string(),
            version_id: "v1".to_string(),
            sha1: "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb".to_string(),
        },
    }
}

fn manifest(files: Vec<BundleFile>) -> BundleManifest {
    BundleManifest {
        name: BUNDLE.to_string(),
        version_id: "1".to_string(),
        category: "test".to_string(),
        mc_version: MC_VERSION.to_string(),
        loader: GameLoader::Fabric,
        loader_version: "0.16.0".to_string(),
        enabled: true,
        java_version_override: None,
        files,
    }
}

async fn cluster_with_tracked_mod(state: &LauncherState) -> i64 {
    let global = state.settings.read().global_game_settings.clone();
    let cluster = state
        .clusters
        .create(
            &global,
            CreateClusterOptions::new("Bundle Cluster", MC_VERSION, GameLoader::Fabric),
        )
        .await
        .unwrap();

    artifact_dao::insert_artifact(
        &state.services.db,
        HASH,
        ContentType::Mod as i64,
        "artifacts/sodium.jar",
        "sodium.jar",
        Some(1),
    )
    .await
    .unwrap();

    artifact_dao::link_cluster_artifact(&state.services.db, cluster.id, HASH, "sodium.jar")
        .await
        .unwrap();

    artifact_dao::upsert_provider_release(
        &state.services.db,
        ProviderId::Modrinth as i64,
        PROJECT_ID,
        VERSION_ID,
        HASH,
        "Sodium",
        "1.0.0",
        None,
        MC_VERSION,
        "fabric",
    )
    .await
    .unwrap();

    bundle_dao::track_bundle_artifact(
        &state.services.db,
        cluster.id,
        HASH,
        BUNDLE,
        VERSION_ID,
        PROJECT_ID,
    )
    .await
    .unwrap();

    cluster.id
}

#[tokio::test]
async fn mod_still_in_manifest_is_not_removed() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(&state, manifest(vec![managed_file(true)]))
        .await
        .unwrap();
    let cluster_id = cluster_with_tracked_mod(&state).await;

    let check = check_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();

    assert!(
        check.removals_available.is_empty(),
        "an unchanged tracked mod was flagged for removal: {:?}",
        check.removals_available
    );
    assert!(check.updates_available.is_empty());
}

#[tokio::test]
async fn mod_dropped_from_manifest_is_removed() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(&state, manifest(vec![]))
        .await
        .unwrap();
    let cluster_id = cluster_with_tracked_mod(&state).await;

    let check = check_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();

    assert_eq!(
        check.removals_available.len(),
        1,
        "a mod the bundle no longer ships should be removed"
    );
    assert_eq!(check.removals_available[0].package_id, PROJECT_ID);
}

#[tokio::test]
async fn disabled_mod_dropped_from_manifest_is_still_removed() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(&state, manifest(vec![]))
        .await
        .unwrap();
    let cluster_id = cluster_with_tracked_mod(&state).await;

    artifact_dao::update_cluster_artifact(&state.services.db, cluster_id, HASH, "sodium.jar", 0)
        .await
        .unwrap();
    bundle_dao::save_override(
        &state.services.db,
        cluster_id,
        BUNDLE,
        PROJECT_ID,
        OverrideType::Disabled,
    )
    .await
    .unwrap();

    let check = check_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();

    assert_eq!(
        check.removals_available.len(),
        1,
        "a disabled mod the bundle no longer ships should still be removed"
    );
}

#[tokio::test]
async fn user_disabled_mod_is_not_treated_as_a_removal() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(&state, manifest(vec![managed_file(true)]))
        .await
        .unwrap();
    let cluster_id = cluster_with_tracked_mod(&state).await;

    artifact_dao::update_cluster_artifact(&state.services.db, cluster_id, HASH, "sodium.jar", 0)
        .await
        .unwrap();
    bundle_dao::save_override(
        &state.services.db,
        cluster_id,
        BUNDLE,
        PROJECT_ID,
        OverrideType::Disabled,
    )
    .await
    .unwrap();

    let check = check_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();

    assert!(
        check.removals_available.is_empty(),
        "a user-disabled mod is still shipped by the bundle and must not be removed: {:?}",
        check.removals_available
    );
}

#[tokio::test]
async fn deleted_bundled_mod_is_not_treated_as_a_removal() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(&state, manifest(vec![managed_file(true)]))
        .await
        .unwrap();
    let cluster_id = cluster_with_tracked_mod(&state).await;

    artifact_dao::update_cluster_artifact(&state.services.db, cluster_id, HASH, "sodium.jar", 0)
        .await
        .unwrap();
    bundle_dao::save_override(
        &state.services.db,
        cluster_id,
        BUNDLE,
        PROJECT_ID,
        OverrideType::Removed,
    )
    .await
    .unwrap();

    let check = check_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();

    assert!(
        check.removals_available.is_empty(),
        "a deleted mod is still shipped by the bundle and must not be removed: {:?}",
        check.removals_available
    );
    assert!(check.updates_available.is_empty());
}

#[tokio::test]
async fn deleting_a_bundled_mod_leaves_only_the_removal() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    let cluster_id = cluster_with_tracked_mod(&state).await;
    let ctx = state.services.content();
    bundle_dao::save_override(
        &state.services.db,
        cluster_id,
        "Old Bundle",
        PROJECT_ID,
        OverrideType::Disabled,
    )
    .await
    .unwrap();

    on_user_disable_artifact(cluster_id, HASH, &ctx)
        .await
        .unwrap();
    on_user_remove_artifact(cluster_id, HASH, &ctx)
        .await
        .unwrap();

    let overrides: Vec<(String, String)> =
        bundle_dao::list_overrides(&state.services.db, cluster_id)
            .await
            .unwrap()
            .into_iter()
            .filter(|o| o.package_id == PROJECT_ID)
            .map(|o| (o.bundle_name, o.override_type))
            .collect();
    assert_eq!(overrides, [(BUNDLE.to_string(), "removed".to_string())]);
}

#[tokio::test]
async fn user_disabled_mod_still_takes_updates() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    let mut newer = managed_file(true);
    if let BundleFileKind::Managed {
        version_id, sha1, ..
    } = &mut newer.kind
    {
        *version_id = "v2".to_string();
        *sha1 = "cccccccccccccccccccccccccccccccccccccccc".to_string();
    }
    oneclient_core::dev::seed_bundle_archive(&state, manifest(vec![newer]))
        .await
        .unwrap();
    let cluster_id = cluster_with_tracked_mod(&state).await;

    artifact_dao::update_cluster_artifact(&state.services.db, cluster_id, HASH, "sodium.jar", 0)
        .await
        .unwrap();
    bundle_dao::save_override(
        &state.services.db,
        cluster_id,
        BUNDLE,
        PROJECT_ID,
        OverrideType::Disabled,
    )
    .await
    .unwrap();

    let check = check_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();

    assert_eq!(
        check
            .updates_available
            .iter()
            .map(|u| u.new_version_id.as_str())
            .collect::<Vec<_>>(),
        ["v2"],
        "a user-disabled mod must still be offered the newer version"
    );
    assert!(check.removals_available.is_empty());
    assert!(check.additions_available.is_empty());
}

#[tokio::test]
async fn live_bundle_takes_on_new_catalog_files() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        manifest(vec![managed_file(true), newly_shipped_file()]),
    )
    .await
    .unwrap();
    let cluster_id = cluster_with_tracked_mod(&state).await;

    let check = check_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();

    assert_eq!(
        check.additions_available.len(),
        1,
        "a bundle the user still has enabled should pick up newly shipped files"
    );
    assert_eq!(
        check.additions_available[0].new_file.kind.package_id(),
        "newcomer"
    );
}

#[tokio::test]
async fn emptied_bundle_does_not_take_on_new_catalog_files() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        manifest(vec![managed_file(true), newly_shipped_file()]),
    )
    .await
    .unwrap();
    let cluster_id = cluster_with_tracked_mod(&state).await;

    // Disabling everything is how you opt out
    // The newcomer lacks an override only
    // because it did not exist yet that absence must not read as consent
    artifact_dao::update_cluster_artifact(&state.services.db, cluster_id, HASH, "sodium.jar", 0)
        .await
        .unwrap();
    bundle_dao::save_override(
        &state.services.db,
        cluster_id,
        BUNDLE,
        PROJECT_ID,
        OverrideType::Disabled,
    )
    .await
    .unwrap();

    let check = check_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();

    assert!(
        check.additions_available.is_empty(),
        "a bundle whose content the user disabled must not reinstate itself: {:?}",
        check
            .additions_available
            .iter()
            .map(|a| a.new_file.kind.package_id())
            .collect::<Vec<_>>()
    );
}

#[tokio::test]
async fn removed_bundle_content_does_not_take_on_new_catalog_files() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        manifest(vec![managed_file(true), newly_shipped_file()]),
    )
    .await
    .unwrap();
    let cluster_id = cluster_with_tracked_mod(&state).await;

    oneclient_content::bundles::remove_artifact_from_cluster(
        cluster_id,
        HASH,
        true,
        &state.services.content(),
    )
    .await
    .unwrap();

    let check = check_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();

    assert!(
        check.additions_available.is_empty(),
        "a bundle the user emptied by removal must not reinstate itself: {:?}",
        check
            .additions_available
            .iter()
            .map(|a| a.new_file.kind.package_id())
            .collect::<Vec<_>>()
    );
}

#[tokio::test]
async fn opting_a_single_file_in_keeps_the_bundle_live() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        manifest(vec![managed_file(true), newly_shipped_file()]),
    )
    .await
    .unwrap();
    let cluster_id = cluster_with_tracked_mod(&state).await;

    artifact_dao::update_cluster_artifact(&state.services.db, cluster_id, HASH, "sodium.jar", 0)
        .await
        .unwrap();
    bundle_dao::save_override(
        &state.services.db,
        cluster_id,
        BUNDLE,
        PROJECT_ID,
        OverrideType::Disabled,
    )
    .await
    .unwrap();
    bundle_dao::save_override(
        &state.services.db,
        cluster_id,
        BUNDLE,
        "newcomer",
        OverrideType::Enabled,
    )
    .await
    .unwrap();

    let check = check_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();

    assert_eq!(
        check.additions_available.len(),
        1,
        "an explicit opt-in is consent, even with the rest of the bundle disabled"
    );
}

async fn seed_delisted_bundle(state: &LauncherState) {
    oneclient_db::dao::bundle::upsert_bundle(
        &state.services.db,
        oneclient_db::models::NewBundle {
            remote_path: "bundles/delisted.mrpack",
            mc_version: MC_VERSION,
            mc_loader: GameLoader::Fabric as i64,
            file_name: "delisted.mrpack",
            name: Some(BUNDLE),
            version_id: Some("1"),
            category: Some("test"),
            loader_version: Some("0.16.0"),
            disk_path: "bundles/delisted.mrpack",
            hidden: true,
            etag: None,
            synced_at: None,
        },
    )
    .await
    .unwrap();
}

#[tokio::test]
async fn delisted_bundle_content_is_removed() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    seed_delisted_bundle(&state).await;
    let cluster_id = cluster_with_tracked_mod(&state).await;

    let check = check_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();

    assert_eq!(
        check.removals_available.len(),
        1,
        "content exclusive to a bundle the catalog dropped should be removed"
    );
    assert_eq!(check.removals_available[0].package_id, PROJECT_ID);
}

#[tokio::test]
async fn delisted_bundle_content_another_bundle_still_ships_is_kept() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    seed_delisted_bundle(&state).await;
    let mut successor = manifest(vec![managed_file(true)]);
    successor.name = "Successor Bundle".to_string();
    oneclient_core::dev::seed_bundle_archive(&state, successor)
        .await
        .unwrap();
    let cluster_id = cluster_with_tracked_mod(&state).await;

    let check = check_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();

    assert!(
        check.removals_available.is_empty(),
        "a mod another live bundle still ships is not exclusive: {:?}",
        check.removals_available
    );
}

#[tokio::test]
async fn tracked_bundle_that_never_synced_is_not_removed() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    let cluster_id = cluster_with_tracked_mod(&state).await;

    let check = check_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();

    assert!(
        check.removals_available.is_empty(),
        "an absent catalog is not a delisting and must not take content down: {:?}",
        check.removals_available
    );
}

fn resource_pack_file() -> BundleFile {
    BundleFile {
        enabled: true,
        hidden: false,
        file_type: BundleFileType::Normal,
        path: "resourcepacks/looks.zip".to_string(),
        size: 1,
        kind: BundleFileKind::Managed {
            provider: ProviderId::Modrinth,
            project_id: "looks".to_string(),
            version_id: "v1".to_string(),
            sha1: "cccccccccccccccccccccccccccccccccccccccc".to_string(),
        },
    }
}

#[tokio::test]
async fn disabling_every_mod_stops_new_mods_while_a_resource_pack_stays_on() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        manifest(vec![
            managed_file(true),
            newly_shipped_file(),
            resource_pack_file(),
        ]),
    )
    .await
    .unwrap();
    let cluster_id = cluster_with_tracked_mod(&state).await;

    artifact_dao::update_cluster_artifact(&state.services.db, cluster_id, HASH, "sodium.jar", 0)
        .await
        .unwrap();
    bundle_dao::save_override(
        &state.services.db,
        cluster_id,
        BUNDLE,
        PROJECT_ID,
        OverrideType::Disabled,
    )
    .await
    .unwrap();
    bundle_dao::save_override(
        &state.services.db,
        cluster_id,
        BUNDLE,
        "looks",
        OverrideType::Enabled,
    )
    .await
    .unwrap();

    let check = check_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();

    let added: Vec<String> = check
        .additions_available
        .iter()
        .map(|a| a.new_file.kind.package_id())
        .collect();

    assert!(
        !added.iter().any(|id| id == "newcomer"),
        "mods were switched off for this bundle so a new mod must not arrive: {added:?}"
    );
    assert!(
        added.iter().any(|id| id == "looks"),
        "the resource pack side of the bundle is still live: {added:?}"
    );
    assert!(
        !check
            .optional_available
            .iter()
            .any(|o| o.package_id == "newcomer"),
        "mods were switched off for this bundle so a new mod must not be offered either"
    );

    let status = get_bundles_with_update_status(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();
    let types = &status
        .iter()
        .find(|b| b.archive.manifest.name == BUNDLE)
        .unwrap()
        .opted_in_types;
    assert!(
        !types.contains(&ContentType::Mod) && types.contains(&ContentType::ResourcePack),
        "the package list must agree with the update path on which side is opted out: {types:?}"
    );
}

fn fabric_api_file() -> BundleFile {
    BundleFile {
        enabled: true,
        hidden: false,
        file_type: BundleFileType::Normal,
        path: "mods/fabric-api.jar".to_string(),
        size: 1,
        kind: BundleFileKind::Managed {
            provider: ProviderId::Modrinth,
            project_id: "fabric-api".to_string(),
            version_id: "v1".to_string(),
            sha1: FABRIC_API_HASH.to_string(),
        },
    }
}

fn named_manifest(name: &str, files: Vec<BundleFile>) -> BundleManifest {
    let mut m = manifest(files);
    m.name = name.to_string();
    m
}

async fn install_fabric_api(state: &LauncherState, cluster_id: i64) {
    artifact_dao::insert_artifact(
        &state.services.db,
        FABRIC_API_HASH,
        ContentType::Mod as i64,
        "artifacts/fabric-api.jar",
        "fabric-api.jar",
        Some(1),
    )
    .await
    .unwrap();
    artifact_dao::link_cluster_artifact(
        &state.services.db,
        cluster_id,
        FABRIC_API_HASH,
        "fabric-api.jar",
    )
    .await
    .unwrap();
    artifact_dao::upsert_provider_release(
        &state.services.db,
        ProviderId::Modrinth as i64,
        "fabric-api",
        "v1",
        FABRIC_API_HASH,
        "Fabric API",
        "1.0.0",
        None,
        MC_VERSION,
        "fabric",
    )
    .await
    .unwrap();
    bundle_dao::track_bundle_artifact(
        &state.services.db,
        cluster_id,
        FABRIC_API_HASH,
        SHARED_BUNDLE,
        "v1",
        "fabric-api",
    )
    .await
    .unwrap();
}

#[tokio::test]
async fn a_mod_every_bundle_ships_does_not_keep_a_disabled_bundle_taking_new_mods() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        named_manifest(
            BUNDLE,
            vec![managed_file(true), newly_shipped_file(), fabric_api_file()],
        ),
    )
    .await
    .unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        named_manifest(SHARED_BUNDLE, vec![fabric_api_file()]),
    )
    .await
    .unwrap();

    let cluster_id = cluster_with_tracked_mod(&state).await;
    install_fabric_api(&state, cluster_id).await;

    artifact_dao::update_cluster_artifact(&state.services.db, cluster_id, HASH, "sodium.jar", 0)
        .await
        .unwrap();
    bundle_dao::save_override(
        &state.services.db,
        cluster_id,
        BUNDLE,
        PROJECT_ID,
        OverrideType::Disabled,
    )
    .await
    .unwrap();

    let check = check_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();

    let added: Vec<String> = check
        .additions_available
        .iter()
        .map(|a| a.new_file.kind.package_id())
        .collect();

    assert!(
        !added.iter().any(|id| id == "newcomer"),
        "a mod shared with another bundle must not hold this bundle open: {added:?}"
    );
}

fn hidden_dependency_file() -> BundleFile {
    BundleFile {
        enabled: true,
        hidden: true,
        file_type: BundleFileType::Normal,
        path: "mods/sodium-extra-lib.jar".to_string(),
        size: 1,
        kind: BundleFileKind::Managed {
            provider: ProviderId::Modrinth,
            project_id: "sodium-extra-lib".to_string(),
            version_id: "v1".to_string(),
            sha1: HIDDEN_DEP_HASH.to_string(),
        },
    }
}

#[tokio::test]
async fn a_hidden_dependency_only_this_bundle_ships_does_not_hold_it_open() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        manifest(vec![
            managed_file(true),
            newly_shipped_file(),
            hidden_dependency_file(),
        ]),
    )
    .await
    .unwrap();

    let cluster_id = cluster_with_tracked_mod(&state).await;

    artifact_dao::insert_artifact(
        &state.services.db,
        HIDDEN_DEP_HASH,
        ContentType::Mod as i64,
        "artifacts/sodium-extra-lib.jar",
        "sodium-extra-lib.jar",
        Some(1),
    )
    .await
    .unwrap();
    artifact_dao::link_cluster_artifact(
        &state.services.db,
        cluster_id,
        HIDDEN_DEP_HASH,
        "sodium-extra-lib.jar",
    )
    .await
    .unwrap();
    artifact_dao::upsert_provider_release(
        &state.services.db,
        ProviderId::Modrinth as i64,
        "sodium-extra-lib",
        "v1",
        HIDDEN_DEP_HASH,
        "Sodium Extra Lib",
        "1.0.0",
        None,
        MC_VERSION,
        "fabric",
    )
    .await
    .unwrap();
    bundle_dao::track_bundle_artifact(
        &state.services.db,
        cluster_id,
        HIDDEN_DEP_HASH,
        BUNDLE,
        "v1",
        "sodium-extra-lib",
    )
    .await
    .unwrap();

    artifact_dao::update_cluster_artifact(&state.services.db, cluster_id, HASH, "sodium.jar", 0)
        .await
        .unwrap();
    bundle_dao::save_override(
        &state.services.db,
        cluster_id,
        BUNDLE,
        PROJECT_ID,
        OverrideType::Disabled,
    )
    .await
    .unwrap();

    let check = check_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();

    let added: Vec<String> = check
        .additions_available
        .iter()
        .map(|a| a.new_file.kind.package_id())
        .collect();

    assert!(
        !added.iter().any(|id| id == "newcomer"),
        "a dependency the user was never shown must not read as wanting the bundle: {added:?}"
    );
}

#[tokio::test]
async fn an_unrelated_catalog_bundle_sharing_a_mod_does_not_undo_the_opt_out() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        named_manifest(
            BUNDLE,
            vec![
                managed_file(true),
                newly_shipped_file(),
                resource_pack_file(),
            ],
        ),
    )
    .await
    .unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        named_manifest("Unrelated Bundle", vec![managed_file(true)]),
    )
    .await
    .unwrap();

    let cluster_id = cluster_with_tracked_mod(&state).await;
    artifact_dao::update_cluster_artifact(&state.services.db, cluster_id, HASH, "sodium.jar", 0)
        .await
        .unwrap();
    bundle_dao::save_override(
        &state.services.db,
        cluster_id,
        BUNDLE,
        PROJECT_ID,
        OverrideType::Disabled,
    )
    .await
    .unwrap();
    bundle_dao::save_override(
        &state.services.db,
        cluster_id,
        BUNDLE,
        "looks",
        OverrideType::Enabled,
    )
    .await
    .unwrap();

    let check = check_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();

    let added: Vec<String> = check
        .additions_available
        .iter()
        .map(|a| a.new_file.kind.package_id())
        .collect();

    assert!(
        !added.iter().any(|id| id == "newcomer"),
        "a bundle the user never installed must not speak for this one: {added:?}"
    );
}

async fn opted_in(state: &LauncherState, cluster_id: i64, name: &str) -> HashSet<ContentType> {
    get_bundles_with_update_status(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap()
    .into_iter()
    .find(|b| b.archive.manifest.name == name)
    .unwrap_or_else(|| panic!("{name} missing from the package list"))
    .opted_in_types
}

#[tokio::test]
async fn a_bundle_not_installed_yet_counts_as_opted_in() {
    const NEW_BUNDLE: &str = "New Bundle";
    const DECLINED: &str = "Declined Bundle";
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    let db = &state.services.db;
    let mut retained = manifest(vec![managed_file(true)]);
    let mut added = named_manifest(NEW_BUNDLE, vec![newly_shipped_file()]);
    let mut declined = named_manifest(DECLINED, vec![fabric_api_file()]);
    declined.enabled = false;
    for m in [&mut retained, &mut added, &mut declined] {
        m.mc_version = "26.3".to_string();
    }
    for m in [retained, added, declined] {
        oneclient_core::dev::seed_bundle_archive(&state, m)
            .await
            .unwrap();
    }
    let cluster_id = cluster_with_tracked_mod(&state).await;
    oneclient_content::bundles::set_bundle_choices(
        cluster_id,
        &[(DECLINED.to_string(), false)],
        &state.services.content(),
    )
    .await
    .unwrap();
    assert!(
        bundle_dao::list_bundle_choices(db, cluster_id)
            .await
            .unwrap()
            .contains(&(DECLINED.to_string(), false))
    );
    let source = cluster_dao::get_by_id(db, cluster_id)
        .await
        .unwrap()
        .unwrap();
    cluster_dao::migrate_version_if_unchanged(
        db,
        &source,
        ClusterMigration {
            mc_version: "26.3",
            mc_loader: source.mc_loader,
            mc_loader_version: source.mc_loader_version.as_deref(),
            stage: source.stage,
            name: None,
            folder_name: &source.folder_name,
        },
    )
    .await
    .unwrap()
    .unwrap();

    let bundles = get_bundles_with_update_status(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();
    let opted_in = |name: &str| {
        &bundles
            .iter()
            .find(|b| b.archive.manifest.name == name)
            .unwrap_or_else(|| panic!("{name} missing from the package list"))
            .opted_in_types
    };

    assert!(opted_in(BUNDLE).contains(&ContentType::Mod));
    let new_bundle = bundles
        .iter()
        .find(|b| b.archive.manifest.name == NEW_BUNDLE)
        .unwrap();
    assert!(
        new_bundle.files.iter().any(|(file, _)| {
            file.kind.package_id() == "newcomer"
                && new_bundle.opted_in_types.contains(&file.content_type())
        }),
        "a bundle the migrated cluster has not installed yet still belongs in the All tab"
    );
    assert!(
        opted_in(DECLINED).is_empty(),
        "a declined bundle stays opted out"
    );
}

#[tokio::test]
async fn an_accepted_opt_in_bundle_not_installed_yet_counts_as_opted_in() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    let mut opt_in = named_manifest("Opt In", vec![newly_shipped_file()]);
    opt_in.enabled = false;
    oneclient_core::dev::seed_bundle_archive(&state, opt_in)
        .await
        .unwrap();
    let cluster_id = cluster_with_tracked_mod(&state).await;
    oneclient_content::bundles::set_bundle_choices(
        cluster_id,
        &[("Opt In".to_string(), true)],
        &state.services.content(),
    )
    .await
    .unwrap();

    assert!(
        opted_in(&state, cluster_id, "Opt In")
            .await
            .contains(&ContentType::Mod)
    );
}

#[tokio::test]
async fn a_bundle_not_installed_yet_with_nothing_switched_on_is_not_opted_in() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    let mut optional = newly_shipped_file();
    optional.enabled = false;
    let mut optional_pack = resource_pack_file();
    optional_pack.enabled = false;
    for m in [
        manifest(vec![managed_file(true)]),
        named_manifest("Optional Only", vec![optional]),
        named_manifest("Switched Off", vec![newly_shipped_file()]),
        named_manifest("Mixed", vec![newly_shipped_file(), optional_pack]),
    ] {
        oneclient_core::dev::seed_bundle_archive(&state, m)
            .await
            .unwrap();
    }
    let cluster_id = cluster_with_tracked_mod(&state).await;
    for bundle in ["Switched Off", "Mixed"] {
        bundle_dao::save_override(
            &state.services.db,
            cluster_id,
            bundle,
            "newcomer",
            OverrideType::Disabled,
        )
        .await
        .unwrap();
    }

    for name in ["Optional Only", "Switched Off", "Mixed"] {
        let types = opted_in(&state, cluster_id, name).await;
        assert!(types.is_empty(), "{name} has nothing to install: {types:?}");
    }
}

#[tokio::test]
async fn an_installed_bundle_does_not_lose_its_opt_out_to_one_not_installed_yet() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        manifest(vec![
            managed_file(true),
            newly_shipped_file(),
            resource_pack_file(),
        ]),
    )
    .await
    .unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        named_manifest("Unrelated Bundle", vec![managed_file(true)]),
    )
    .await
    .unwrap();
    let cluster_id = cluster_with_tracked_mod(&state).await;
    artifact_dao::update_cluster_artifact(&state.services.db, cluster_id, HASH, "sodium.jar", 0)
        .await
        .unwrap();
    for (package_id, choice) in [
        (PROJECT_ID, OverrideType::Disabled),
        ("looks", OverrideType::Enabled),
    ] {
        bundle_dao::save_override(&state.services.db, cluster_id, BUNDLE, package_id, choice)
            .await
            .unwrap();
    }

    let types = opted_in(&state, cluster_id, BUNDLE).await;
    assert!(
        !types.contains(&ContentType::Mod) && types.contains(&ContentType::ResourcePack),
        "the list must keep the opt-out the updater keeps: {types:?}"
    );
}

async fn cluster_with_every_copy_off(state: &LauncherState) -> i64 {
    oneclient_core::dev::seed_bundle_archive(
        state,
        manifest(vec![
            managed_file(true),
            newly_shipped_file(),
            resource_pack_file(),
        ]),
    )
    .await
    .unwrap();
    let cluster_id = cluster_with_tracked_mod(state).await;
    artifact_dao::update_cluster_artifact(&state.services.db, cluster_id, HASH, "sodium.jar", 0)
        .await
        .unwrap();
    cluster_id
}

#[tokio::test]
async fn a_bundle_with_every_copy_switched_off_by_accident_counts_as_opted_in() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    let cluster_id = cluster_with_every_copy_off(&state).await;

    let types = opted_in(&state, cluster_id, BUNDLE).await;
    assert!(
        types.contains(&ContentType::Mod),
        "launch switches these copies back on so the bundle is still live: {types:?}"
    );
    assert!(
        added_ids(&state, cluster_id)
            .await
            .contains(&"newcomer".to_string())
    );
}

async fn track_bundle_copy(state: &LauncherState, cluster_id: i64, file: &BundleFile) {
    let BundleFileKind::Managed {
        project_id,
        version_id,
        sha1,
        ..
    } = &file.kind
    else {
        unreachable!("only managed files are tracked here");
    };
    let db = &state.services.db;
    let file_name = file.path.rsplit('/').next().unwrap();
    artifact_dao::insert_artifact(
        db,
        sha1,
        file.content_type() as i64,
        &format!("artifacts/{file_name}"),
        file_name,
        Some(1),
    )
    .await
    .unwrap();
    artifact_dao::link_cluster_artifact(db, cluster_id, sha1, file_name)
        .await
        .unwrap();
    artifact_dao::upsert_provider_release(
        db,
        ProviderId::Modrinth as i64,
        project_id,
        version_id,
        sha1,
        file_name,
        "1.0.0",
        None,
        MC_VERSION,
        "fabric",
    )
    .await
    .unwrap();
    bundle_dao::track_bundle_artifact(db, cluster_id, sha1, BUNDLE, version_id, project_id)
        .await
        .unwrap();
}

#[tokio::test]
async fn a_hidden_dependency_switched_off_by_accident_keeps_the_bundle_live() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        manifest(vec![hidden_dependency_file(), newly_shipped_file()]),
    )
    .await
    .unwrap();
    let cluster_id = cluster_with_tracked_mod(&state).await;
    track_bundle_copy(&state, cluster_id, &hidden_dependency_file()).await;
    let db = &state.services.db;
    for (hash, file_name) in [
        (HASH, "sodium.jar"),
        (HIDDEN_DEP_HASH, "sodium-extra-lib.jar"),
    ] {
        artifact_dao::update_cluster_artifact(db, cluster_id, hash, file_name, 0)
            .await
            .unwrap();
    }

    let types = opted_in(&state, cluster_id, BUNDLE).await;
    assert!(types.contains(&ContentType::Mod), "{types:?}");
    assert!(
        added_ids(&state, cluster_id)
            .await
            .contains(&"newcomer".to_string())
    );
    heal(&state, cluster_id).await;
    let restored = artifact_dao::get_cluster_artifact(db, cluster_id, HIDDEN_DEP_HASH)
        .await
        .unwrap()
        .unwrap();
    assert_ne!(restored.enabled, 0);
}

#[tokio::test]
async fn a_bundle_with_every_copy_switched_off_on_purpose_stays_opted_out() {
    for (filed_under, choice) in [
        (BUNDLE, OverrideType::Disabled),
        (BUNDLE, OverrideType::Removed),
        ("Old Bundle", OverrideType::Disabled),
        ("Old Bundle", OverrideType::Removed),
    ] {
        let state = oneclient_core::dev::ephemeral_state().await.unwrap();
        let cluster_id = cluster_with_every_copy_off(&state).await;
        bundle_dao::save_override(
            &state.services.db,
            cluster_id,
            filed_under,
            PROJECT_ID,
            choice,
        )
        .await
        .unwrap();
        let case = format!("{filed_under} {choice:?}");

        assert_stays_opted_out(&state, cluster_id, &case).await;
        heal(&state, cluster_id).await;
        assert!(!cluster_mod_enabled(&state, cluster_id).await, "{case}");
    }
}

async fn assert_stays_opted_out(state: &LauncherState, cluster_id: i64, case: &str) {
    let types = opted_in(state, cluster_id, BUNDLE).await;
    assert!(types.is_empty(), "{case}: {types:?}");
    let added = added_ids(state, cluster_id).await;
    assert!(added.is_empty(), "{case}: {added:?}");
}

#[tokio::test]
async fn a_switched_off_copy_launch_leaves_off_keeps_the_bundle_opted_out() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        manifest(vec![newly_shipped_file(), resource_pack_file()]),
    )
    .await
    .unwrap();
    let cluster_id = cluster_with_tracked_mod(&state).await;
    artifact_dao::update_cluster_artifact(&state.services.db, cluster_id, HASH, "sodium.jar", 0)
        .await
        .unwrap();
    assert_stays_opted_out(&state, cluster_id, "no longer shipped").await;

    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    let cluster_id = cluster_with_every_copy_off(&state).await;
    bisect_dao::start(
        &state.services.db,
        cluster_id,
        &[("other".to_string(), "Other".to_string())],
    )
    .await
    .unwrap();
    assert_stays_opted_out(&state, cluster_id, "bisect running").await;

    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    let cluster_id = cluster_with_every_copy_off(&state).await;
    track_other_sodium_copy(&state, cluster_id, "Other Bundle").await;
    assert_stays_opted_out(&state, cluster_id, "another copy live").await;
}

const OTHER_COPY: &str = "ffffffffffffffffffffffffffffffffffffffff";

async fn track_other_sodium_copy(state: &LauncherState, cluster_id: i64, bundle: &str) {
    let db = &state.services.db;
    artifact_dao::insert_artifact(
        db,
        OTHER_COPY,
        ContentType::Mod as i64,
        "artifacts/sodium-other.jar",
        "sodium-other.jar",
        Some(1),
    )
    .await
    .unwrap();
    artifact_dao::link_cluster_artifact(db, cluster_id, OTHER_COPY, "sodium-other.jar")
        .await
        .unwrap();
    bundle_dao::track_bundle_artifact(db, cluster_id, OTHER_COPY, bundle, VERSION_ID, PROJECT_ID)
        .await
        .unwrap();
}

async fn reverse_unordered_selects(state: &LauncherState) {
    let db = &state.services.db;
    let mut held = Vec::new();
    for _ in 0..db.options().get_max_connections() {
        let mut conn = db.acquire().await.unwrap();
        sqlx::query("PRAGMA reverse_unordered_selects = ON")
            .execute(&mut *conn)
            .await
            .unwrap();
        held.push(conn);
    }
}

#[tokio::test]
async fn the_bundle_launch_heals_first_takes_a_shared_switched_off_mod() {
    // Tracked rows come back in bundle name order through an index, the same order launch visits archives, so the scan is reversed to catch a prediction that follows row order
    for other in ["A Bundle", "Z Bundle"] {
        let state = oneclient_core::dev::ephemeral_state().await.unwrap();
        reverse_unordered_selects(&state).await;
        for name in [BUNDLE, other] {
            seed_bundle_with_pack(&state, named_manifest(name, vec![managed_file(true)])).await;
        }
        let cluster_id = cluster_with_tracked_mod(&state).await;
        track_other_sodium_copy(&state, cluster_id, other).await;
        let db = &state.services.db;
        for (hash, file_name) in [(HASH, "sodium.jar"), (OTHER_COPY, "sodium-other.jar")] {
            artifact_dao::update_cluster_artifact(db, cluster_id, hash, file_name, 0)
                .await
                .unwrap();
        }

        let mut predicted = Vec::new();
        for name in [BUNDLE, other] {
            if opted_in(&state, cluster_id, name)
                .await
                .contains(&ContentType::Mod)
            {
                predicted.push(name.to_string());
            }
        }
        install_cluster_bundles(
            cluster_id,
            state.bundles.as_ref(),
            None,
            &state.services.content(),
        )
        .await
        .unwrap();
        let healed: Vec<String> = bundle_dao::list_bundle_tracked(db, cluster_id)
            .await
            .unwrap()
            .into_iter()
            .filter(|row| row.enabled != 0)
            .filter_map(|row| row.bundle_name)
            .collect();

        assert_eq!(healed, [BUNDLE.min(other)], "{other}");
        assert_eq!(predicted, healed, "{other}");
    }
}

#[tokio::test]
async fn a_bundle_on_a_cluster_with_nothing_installed_counts_as_opted_in() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(&state, manifest(vec![newly_shipped_file()]))
        .await
        .unwrap();
    let global = state.settings.read().global_game_settings.clone();
    let cluster = state
        .clusters
        .create(
            &global,
            CreateClusterOptions::new("Fresh Cluster", MC_VERSION, GameLoader::Fabric),
        )
        .await
        .unwrap();

    assert!(
        opted_in(&state, cluster.id, BUNDLE)
            .await
            .contains(&ContentType::Mod)
    );
}

/// Package ids launch installs, picked from the same choices and overrides launch reads
async fn launch_installs(state: &LauncherState, cluster_id: i64) -> Vec<String> {
    let db = &state.services.db;
    let bundles = get_bundles_with_update_status(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();
    let accepted: HashSet<String> = bundle_dao::list_bundle_choices(db, cluster_id)
        .await
        .unwrap()
        .into_iter()
        .filter_map(|(name, accepted)| accepted.then_some(name))
        .collect();
    let overrides = bundle_dao::list_overrides(db, cluster_id).await.unwrap();
    wanted_bundle_files(
        bundles.iter().map(|b| &b.archive.manifest),
        &accepted,
        |bundle, package| {
            overrides
                .iter()
                .find(|o| o.bundle_name == bundle && o.package_id == package)
                .and_then(|o| OverrideType::parse(&o.override_type))
        },
    )
    .into_iter()
    .map(|file| file.kind.package_id())
    .collect()
}

#[tokio::test]
async fn a_mod_unticked_at_onboarding_keeps_the_rest_of_the_bundle_opted_in() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        manifest(vec![
            managed_file(true),
            newly_shipped_file(),
            resource_pack_file(),
        ]),
    )
    .await
    .unwrap();
    let global = state.settings.read().global_game_settings.clone();
    let cluster = state
        .clusters
        .create(
            &global,
            CreateClusterOptions::new("Fresh Cluster", MC_VERSION, GameLoader::Fabric),
        )
        .await
        .unwrap();
    oneclient_core::set_bundle_package_overrides(
        cluster.id,
        &[(
            BUNDLE.to_string(),
            "newcomer".to_string(),
            OverrideType::Removed,
        )],
        &state.services.content(),
    )
    .await
    .unwrap();

    let bundles = get_bundles_with_update_status(
        cluster.id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();
    let bundle = bundles
        .iter()
        .find(|b| b.archive.manifest.name == BUNDLE)
        .unwrap();

    assert!(
        bundle.opted_in_types.contains(&ContentType::Mod),
        "launch still installs the mods left ticked: {:?}",
        bundle.opted_in_types
    );
    assert_eq!(
        launch_installs(&state, cluster.id).await,
        [PROJECT_ID, "looks"]
    );
}

#[tokio::test]
async fn every_mod_unticked_at_onboarding_keeps_the_bundle_out_of_mods() {
    let optional_mod = BundleFile {
        enabled: false,
        path: "mods/optional.jar".to_string(),
        kind: BundleFileKind::Managed {
            provider: ProviderId::Modrinth,
            project_id: "optional".to_string(),
            version_id: "v1".to_string(),
            sha1: "ffffffffffffffffffffffffffffffffffffffff".to_string(),
        },
        ..newly_shipped_file()
    };
    for extra in [None, Some(optional_mod)] {
        let state = oneclient_core::dev::ephemeral_state().await.unwrap();
        let mut files = vec![
            managed_file(true),
            newly_shipped_file(),
            resource_pack_file(),
        ];
        files.extend(extra.clone());
        oneclient_core::dev::seed_bundle_archive(&state, manifest(files))
            .await
            .unwrap();
        let global = state.settings.read().global_game_settings.clone();
        let cluster = state
            .clusters
            .create(
                &global,
                CreateClusterOptions::new("Fresh Cluster", MC_VERSION, GameLoader::Fabric),
            )
            .await
            .unwrap();
        let unticked: Vec<_> = [PROJECT_ID, "newcomer"]
            .map(|id| (BUNDLE.to_string(), id.to_string(), OverrideType::Removed))
            .into();
        oneclient_core::set_bundle_package_overrides(
            cluster.id,
            &unticked,
            &state.services.content(),
        )
        .await
        .unwrap();

        let types = opted_in(&state, cluster.id, BUNDLE).await;
        assert!(
            !types.contains(&ContentType::Mod) && types.contains(&ContentType::ResourcePack),
            "{extra:?}: {types:?}"
        );
        assert_eq!(
            launch_installs(&state, cluster.id).await,
            ["looks"],
            "{extra:?}"
        );
    }
}

#[tokio::test]
async fn a_mod_type_not_installed_yet_ignores_the_resource_pack_already_installed() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        manifest(vec![
            managed_file(true),
            newly_shipped_file(),
            resource_pack_file(),
        ]),
    )
    .await
    .unwrap();
    let global = state.settings.read().global_game_settings.clone();
    let cluster = state
        .clusters
        .create(
            &global,
            CreateClusterOptions::new("Fresh Cluster", MC_VERSION, GameLoader::Fabric),
        )
        .await
        .unwrap();
    oneclient_core::set_bundle_package_overrides(
        cluster.id,
        &[(
            BUNDLE.to_string(),
            PROJECT_ID.to_string(),
            OverrideType::Removed,
        )],
        &state.services.content(),
    )
    .await
    .unwrap();
    track_bundle_copy(&state, cluster.id, &resource_pack_file()).await;

    let types = opted_in(&state, cluster.id, BUNDLE).await;
    assert!(
        types.contains(&ContentType::Mod),
        "launch still installs the mod left ticked: {types:?}"
    );
    assert_eq!(
        launch_installs(&state, cluster.id).await,
        ["newcomer", "looks"]
    );
}

#[tokio::test]
async fn an_installed_bundle_opted_out_of_mods_stays_out_when_a_mod_is_shipped() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        manifest(vec![
            managed_file(true),
            newly_shipped_file(),
            resource_pack_file(),
        ]),
    )
    .await
    .unwrap();
    let cluster_id = cluster_with_tracked_mod(&state).await;
    artifact_dao::update_cluster_artifact(&state.services.db, cluster_id, HASH, "sodium.jar", 0)
        .await
        .unwrap();
    for (package_id, choice) in [
        (PROJECT_ID, OverrideType::Disabled),
        ("looks", OverrideType::Enabled),
    ] {
        bundle_dao::save_override(&state.services.db, cluster_id, BUNDLE, package_id, choice)
            .await
            .unwrap();
    }

    let types = opted_in(&state, cluster_id, BUNDLE).await;
    assert!(
        !types.contains(&ContentType::Mod) && types.contains(&ContentType::ResourcePack),
        "{types:?}"
    );
    let check = check_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();
    assert!(
        !check
            .additions_available
            .iter()
            .any(|a| a.new_file.kind.package_id() == "newcomer")
    );
}

#[tokio::test]
async fn untracked_older_install_counts_as_opted_in() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        manifest(vec![managed_file(true), newly_shipped_file()]),
    )
    .await
    .unwrap();
    let cluster_id = cluster_with_tracked_mod(&state).await;
    bundle_dao::clear_bundle_tracking(&state.services.db, cluster_id, HASH)
        .await
        .unwrap();

    let bundles = get_bundles_with_update_status(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();

    assert!(
        bundles
            .iter()
            .all(|b| b.opted_in_types.contains(&ContentType::Mod)),
        "a bundle the updater infers from its installed mods must not have its files hidden from the All tab"
    );
}

#[tokio::test]
async fn package_list_and_updater_infer_the_same_bundle_through_overrides() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        named_manifest(BUNDLE, vec![managed_file(true), newly_shipped_file()]),
    )
    .await
    .unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        named_manifest(SHARED_BUNDLE, vec![managed_file(true)]),
    )
    .await
    .unwrap();

    let cluster_id = cluster_with_tracked_mod(&state).await;
    bundle_dao::clear_bundle_tracking(&state.services.db, cluster_id, HASH)
        .await
        .unwrap();
    bundle_dao::save_override(
        &state.services.db,
        cluster_id,
        SHARED_BUNDLE,
        PROJECT_ID,
        OverrideType::Disabled,
    )
    .await
    .unwrap();

    let check = check_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();
    assert!(
        check
            .additions_available
            .iter()
            .any(|a| a.new_file.kind.package_id() == "newcomer"),
        "the updater infers this bundle from its uniquely installed mod"
    );

    let status = get_bundles_with_update_status(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();
    let types = &status
        .iter()
        .find(|b| b.archive.manifest.name == BUNDLE)
        .unwrap()
        .opted_in_types;
    assert!(
        types.contains(&ContentType::Mod),
        "the package list must infer the same bundle the updater does: {types:?}"
    );
}

const GITHUB_MOD_ID: &str = "github-mod";
const GITHUB_OLD_HASH: &str = "1111111111111111111111111111111111111111";

/// The catalog has moved on to a newer release than the one installed
fn github_mod_file() -> BundleFile {
    BundleFile {
        enabled: true,
        hidden: false,
        file_type: BundleFileType::Normal,
        path: "mods/github-mod.jar".to_string(),
        size: 1,
        kind: BundleFileKind::External {
            file: oneclient_content::packages::types::ExternalFile {
                name: "github-mod.jar".to_string(),
                url: "https://github.com/example/github-mod/releases/download/v2/github-mod.jar"
                    .to_string(),
                sha1: "2222222222222222222222222222222222222222".to_string(),
                size: 1,
                content_type: ContentType::Mod,
            },
            id: Some(GITHUB_MOD_ID.to_string()),
            meta: None,
        },
    }
}

#[tokio::test]
async fn an_outdated_github_mod_left_on_keeps_the_bundle_taking_mods() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        manifest(vec![
            managed_file(true),
            github_mod_file(),
            newly_shipped_file(),
        ]),
    )
    .await
    .unwrap();
    let cluster_id = cluster_with_tracked_mod(&state).await;

    let db = &state.services.db;
    artifact_dao::update_cluster_artifact(db, cluster_id, HASH, "sodium.jar", 0)
        .await
        .unwrap();
    bundle_dao::save_override(db, cluster_id, BUNDLE, PROJECT_ID, OverrideType::Disabled)
        .await
        .unwrap();
    artifact_dao::insert_artifact(
        db,
        GITHUB_OLD_HASH,
        ContentType::Mod as i64,
        "artifacts/github-mod.jar",
        "github-mod.jar",
        Some(1),
    )
    .await
    .unwrap();
    artifact_dao::link_cluster_artifact(db, cluster_id, GITHUB_OLD_HASH, "github-mod.jar")
        .await
        .unwrap();
    bundle_dao::track_bundle_artifact(
        db,
        cluster_id,
        GITHUB_OLD_HASH,
        BUNDLE,
        GITHUB_OLD_HASH,
        GITHUB_MOD_ID,
    )
    .await
    .unwrap();

    let check = check_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();
    assert!(
        check
            .additions_available
            .iter()
            .any(|a| a.new_file.kind.package_id() == "newcomer"),
        "the GitHub mod is still on even though its installed release is older than the catalog's"
    );

    let status = get_bundles_with_update_status(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();
    let types = &status
        .iter()
        .find(|b| b.archive.manifest.name == BUNDLE)
        .unwrap()
        .opted_in_types;
    assert!(types.contains(&ContentType::Mod), "{types:?}");
}

async fn cluster_with_mods_opted_out(state: &LauncherState, disabled_under: &str) -> i64 {
    let cluster_id = cluster_with_tracked_mod(state).await;
    artifact_dao::update_cluster_artifact(&state.services.db, cluster_id, HASH, "sodium.jar", 0)
        .await
        .unwrap();
    bundle_dao::save_override(
        &state.services.db,
        cluster_id,
        disabled_under,
        PROJECT_ID,
        OverrideType::Disabled,
    )
    .await
    .unwrap();
    bundle_dao::save_override(
        &state.services.db,
        cluster_id,
        BUNDLE,
        "looks",
        OverrideType::Enabled,
    )
    .await
    .unwrap();
    cluster_id
}

async fn added_ids(state: &LauncherState, cluster_id: i64) -> Vec<String> {
    check_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap()
    .additions_available
    .iter()
    .map(|a| a.new_file.kind.package_id())
    .collect()
}

#[tokio::test]
async fn a_disable_filed_under_another_bundle_still_opts_the_mods_out() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        manifest(vec![
            managed_file(true),
            newly_shipped_file(),
            resource_pack_file(),
        ]),
    )
    .await
    .unwrap();
    let cluster_id = cluster_with_mods_opted_out(&state, "Old Bundle").await;

    let added = added_ids(&state, cluster_id).await;
    assert!(
        !added.iter().any(|id| id == "newcomer"),
        "the user switched sodium off while it was filed under another bundle: {added:?}"
    );
}

#[tokio::test]
async fn the_catalog_dropping_every_switched_off_mod_keeps_the_opt_out() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        manifest(vec![managed_file(true), resource_pack_file()]),
    )
    .await
    .unwrap();
    let cluster_id = cluster_with_mods_opted_out(&state, BUNDLE).await;
    added_ids(&state, cluster_id).await;

    oneclient_core::dev::seed_bundle_archive(
        &state,
        manifest(vec![newly_shipped_file(), resource_pack_file()]),
    )
    .await
    .unwrap();

    let added = added_ids(&state, cluster_id).await;
    assert!(
        !added.iter().any(|id| id == "newcomer"),
        "mods stay opted out after the catalog replaces them: {added:?}"
    );
    let status = get_bundles_with_update_status(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();
    let types = &status
        .iter()
        .find(|b| b.archive.manifest.name == BUNDLE)
        .unwrap()
        .opted_in_types;
    assert!(
        !types.contains(&ContentType::Mod),
        "the package list must remember the opt-out too: {types:?}"
    );

    set_bundle_package_enabled(
        cluster_id,
        BUNDLE,
        "looks",
        true,
        true,
        &state.services.content(),
    )
    .await
    .unwrap();
    let added = added_ids(&state, cluster_id).await;
    assert!(
        !added.iter().any(|id| id == "newcomer"),
        "switching a resource pack on must not opt the mods back in: {added:?}"
    );

    set_bundle_package_enabled(
        cluster_id,
        BUNDLE,
        "newcomer",
        true,
        true,
        &state.services.content(),
    )
    .await
    .unwrap();
    let added = added_ids(&state, cluster_id).await;
    assert!(
        added.iter().any(|id| id == "newcomer"),
        "switching a mod back on opts the mods back in: {added:?}"
    );
}

#[tokio::test]
async fn switching_a_new_mod_on_beside_switched_off_ones_installs_it() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        manifest(vec![
            managed_file(true),
            newly_shipped_file(),
            resource_pack_file(),
        ]),
    )
    .await
    .unwrap();
    let cluster_id = cluster_with_mods_opted_out(&state, BUNDLE).await;
    added_ids(&state, cluster_id).await;

    set_bundle_package_enabled(
        cluster_id,
        BUNDLE,
        "newcomer",
        true,
        true,
        &state.services.content(),
    )
    .await
    .unwrap();
    let added = added_ids(&state, cluster_id).await;
    assert!(
        added.iter().any(|id| id == "newcomer"),
        "sodium staying off must not swallow the user switching newcomer on: {added:?}"
    );
}

#[tokio::test]
async fn the_package_list_does_not_save_the_opt_out() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(
        &state,
        manifest(vec![managed_file(true), resource_pack_file()]),
    )
    .await
    .unwrap();
    let cluster_id = cluster_with_mods_opted_out(&state, BUNDLE).await;

    let status = get_bundles_with_update_status(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();
    let types = &status
        .iter()
        .find(|b| b.archive.manifest.name == BUNDLE)
        .unwrap()
        .opted_in_types;
    assert!(!types.contains(&ContentType::Mod), "{types:?}");
    assert!(
        bundle_dao::list_type_opt_outs(&state.services.db, cluster_id)
            .await
            .unwrap()
            .is_empty(),
        "only the updater saves the opt-out"
    );

    added_ids(&state, cluster_id).await;
    assert!(
        !bundle_dao::list_type_opt_outs(&state.services.db, cluster_id)
            .await
            .unwrap()
            .is_empty()
    );
}

async fn seed_opt_in_bundle(state: &LauncherState, name: &str) {
    let mut m = named_manifest(name, vec![managed_file(true)]);
    m.enabled = false;
    seed_bundle_with_pack(state, m).await;
}

async fn seed_bundle_with_pack(state: &LauncherState, m: BundleManifest) {
    let name = &m.name.clone();
    oneclient_core::dev::seed_bundle_archive(state, m)
        .await
        .unwrap();

    let dir = oneclient_common::paths::data_dir().unwrap().join("bundles");
    std::fs::create_dir_all(&dir).unwrap();
    let mut empty_zip = b"PK\x05\x06".to_vec();
    empty_zip.extend([0u8; 18]);
    std::fs::write(dir.join(format!("{name}.mrpack")), empty_zip).unwrap();
}

#[tokio::test]
async fn taking_a_bundle_at_the_prompt_records_the_choice() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    seed_opt_in_bundle(&state, "Opt In").await;
    let cluster_id = cluster_with_tracked_mod(&state).await;
    let ctx = state.services.content();
    let pending = || async {
        oneclient_content::bundles::pending_bundle_choices(cluster_id, state.bundles.as_ref(), &ctx)
            .await
            .unwrap()
            .into_iter()
            .map(|archive| archive.manifest.name)
            .collect::<Vec<_>>()
    };

    assert_eq!(pending().await, ["Opt In".to_string()]);

    oneclient_content::bundles::set_bundle_choices(
        cluster_id,
        &[("Opt In".to_string(), false)],
        &ctx,
    )
    .await
    .unwrap();
    assert!(pending().await.is_empty());
}

#[tokio::test]
async fn turning_a_bundle_down_removes_what_it_installed() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    seed_opt_in_bundle(&state, BUNDLE).await;
    let cluster_id = cluster_with_tracked_mod(&state).await;
    let ctx = state.services.content();

    oneclient_content::bundles::set_bundle_choices(cluster_id, &[(BUNDLE.to_string(), true)], &ctx)
        .await
        .unwrap();
    let tracked = bundle_dao::list_bundle_tracked(&state.services.db, cluster_id)
        .await
        .unwrap();
    assert_eq!(tracked.len(), 1, "taking the bundle keeps its mods");
    bundle_dao::save_override(
        &state.services.db,
        cluster_id,
        BUNDLE,
        PROJECT_ID,
        OverrideType::Disabled,
    )
    .await
    .unwrap();

    oneclient_content::bundles::set_bundle_choices(
        cluster_id,
        &[(BUNDLE.to_string(), false)],
        &ctx,
    )
    .await
    .unwrap();
    let tracked = bundle_dao::list_bundle_tracked(&state.services.db, cluster_id)
        .await
        .unwrap();
    assert!(tracked.is_empty());
    let overrides = bundle_dao::list_overrides(&state.services.db, cluster_id)
        .await
        .unwrap();
    assert_eq!(overrides.len(), 1, "a mod the user switched off stays off");
}

#[tokio::test]
async fn skyblock_nobody_asked_for_is_taken_out_of_an_old_26_3_cluster_once() {
    const SKYBLOCK: &str = "Test [SkyBlock]";
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    let db = &state.services.db;
    let mut m = named_manifest(SKYBLOCK, vec![managed_file(true)]);
    m.enabled = false;
    m.category = "SkyBlock".to_string();
    m.mc_version = "26.3".to_string();
    seed_bundle_with_pack(&state, m).await;
    let cluster_id = cluster_with_tracked_mod(&state).await;
    let ctx = state.services.content();
    let track = || {
        bundle_dao::track_bundle_artifact(db, cluster_id, HASH, SKYBLOCK, VERSION_ID, PROJECT_ID)
    };
    let apply = || {
        oneclient_content::bundles::apply_bundle_updates(
            cluster_id,
            state.bundles.as_ref(),
            &ctx,
            None,
        )
    };
    track().await.unwrap();
    bundle_dao::save_bundle_choices(db, cluster_id, &[(SKYBLOCK.to_string(), true)])
        .await
        .unwrap();

    sqlx::query("UPDATE clusters SET mc_version = '26.3' WHERE id = ?")
        .bind(cluster_id)
        .execute(db)
        .await
        .unwrap();
    apply().await.unwrap();
    assert_eq!(
        bundle_dao::list_bundle_tracked(db, cluster_id)
            .await
            .unwrap()
            .len(),
        1,
        "a cluster made after bundles started asking is left alone"
    );

    sqlx::query("DELETE FROM applied_migrations")
        .execute(db)
        .await
        .unwrap();
    sqlx::query("UPDATE clusters SET created_at = '2020-01-01T00:00:00+00:00' WHERE id = ?")
        .bind(cluster_id)
        .execute(db)
        .await
        .unwrap();
    apply().await.unwrap();
    assert!(
        bundle_dao::list_bundle_tracked(db, cluster_id)
            .await
            .unwrap()
            .is_empty()
    );

    artifact_dao::insert_artifact(
        db,
        HASH,
        ContentType::Mod as i64,
        "artifacts/sodium.jar",
        "sodium.jar",
        Some(1),
    )
    .await
    .unwrap();
    artifact_dao::link_cluster_artifact(db, cluster_id, HASH, "sodium.jar")
        .await
        .unwrap();
    track().await.unwrap();
    apply().await.unwrap();
    assert_eq!(
        bundle_dao::list_bundle_tracked(db, cluster_id)
            .await
            .unwrap()
            .len(),
        1,
        "taking SkyBlock again later is not undone"
    );
}

#[tokio::test]
async fn an_opt_in_bundle_switched_off_by_accident_is_repaired_at_install() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    seed_opt_in_bundle(&state, BUNDLE).await;
    let cluster_id = cluster_with_tracked_mod(&state).await;
    artifact_dao::update_cluster_artifact(&state.services.db, cluster_id, HASH, "sodium.jar", 0)
        .await
        .unwrap();

    install_cluster_bundles(
        cluster_id,
        state.bundles.as_ref(),
        None,
        &state.services.content(),
    )
    .await
    .unwrap();

    let tracked = bundle_dao::list_bundle_tracked(&state.services.db, cluster_id)
        .await
        .unwrap();
    assert!(
        tracked.iter().all(|row| row.enabled != 0),
        "nothing recorded the disable so the install should undo it"
    );
}

async fn cluster_mod_enabled(state: &LauncherState, cluster_id: i64) -> bool {
    artifact_dao::get_cluster_artifact(&state.services.db, cluster_id, HASH)
        .await
        .unwrap()
        .unwrap()
        .enabled
        != 0
}

async fn heal(state: &LauncherState, cluster_id: i64) {
    let ctx = state.services.content();
    let archives = state
        .bundles
        .archives_for(&ctx, MC_VERSION, GameLoader::Fabric)
        .await
        .unwrap();
    oneclient_content::bundles::heal_bundle_activity(cluster_id, &archives, &ctx)
        .await
        .unwrap();
}

#[tokio::test]
async fn a_mod_left_out_of_a_running_search_is_not_switched_back_on() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    seed_opt_in_bundle(&state, BUNDLE).await;
    let cluster_id = cluster_with_tracked_mod(&state).await;
    let db = &state.services.db;

    artifact_dao::update_cluster_artifact(db, cluster_id, HASH, "sodium.jar", 0)
        .await
        .unwrap();
    bisect_dao::start(
        db,
        cluster_id,
        &[("other".to_string(), "Other".to_string())],
    )
    .await
    .unwrap();

    heal(&state, cluster_id).await;

    assert!(
        !cluster_mod_enabled(&state, cluster_id).await,
        "turning it on would add a mod the search never tested"
    );
}

#[tokio::test]
async fn a_mod_held_from_a_declined_bundle_stays_off_once_the_user_switches_it_off() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    seed_opt_in_bundle(&state, BUNDLE).await;
    let cluster_id = cluster_with_tracked_mod(&state).await;
    let db = &state.services.db;

    artifact_dao::update_cluster_artifact(db, cluster_id, HASH, "sodium.jar", 0)
        .await
        .unwrap();
    bundle_dao::save_override(db, cluster_id, BUNDLE, PROJECT_ID, OverrideType::Disabled)
        .await
        .unwrap();

    for _ in 0..2 {
        oneclient_content::bundles::apply_bundle_updates(
            cluster_id,
            state.bundles.as_ref(),
            &state.services.content(),
            None,
        )
        .await
        .unwrap();
        assert!(
            !cluster_mod_enabled(&state, cluster_id).await,
            "the launch must not switch the mod back on"
        );
    }

    let overrides = bundle_dao::list_overrides(db, cluster_id).await.unwrap();
    assert_eq!(overrides.len(), 1, "the user's choice is kept");
}

#[tokio::test]
async fn a_removal_filed_by_declining_a_bundle_does_not_hold_a_held_mod_off() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    seed_opt_in_bundle(&state, BUNDLE).await;
    let cluster_id = cluster_with_tracked_mod(&state).await;
    let db = &state.services.db;

    artifact_dao::update_cluster_artifact(db, cluster_id, HASH, "sodium.jar", 0)
        .await
        .unwrap();
    bundle_dao::save_override(db, cluster_id, BUNDLE, PROJECT_ID, OverrideType::Removed)
        .await
        .unwrap();

    heal(&state, cluster_id).await;

    assert!(
        cluster_mod_enabled(&state, cluster_id).await,
        "declining the bundle is not a choice about a mod the user holds"
    );
}

#[tokio::test]
async fn a_disable_left_on_a_mod_that_came_back_on_is_cleared_once() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    seed_opt_in_bundle(&state, BUNDLE).await;
    let cluster_id = cluster_with_tracked_mod(&state).await;
    let db = &state.services.db;

    bundle_dao::save_override(db, cluster_id, BUNDLE, PROJECT_ID, OverrideType::Disabled)
        .await
        .unwrap();

    heal(&state, cluster_id).await;
    assert!(
        cluster_mod_enabled(&state, cluster_id).await,
        "the mod stays on the way the user last saw it"
    );
    assert!(
        bundle_dao::list_overrides(db, cluster_id)
            .await
            .unwrap()
            .is_empty(),
        "the leftover choice is cleared so a later update cannot switch it off"
    );

    artifact_dao::update_cluster_artifact(db, cluster_id, HASH, "sodium.jar", 0)
        .await
        .unwrap();
    bundle_dao::save_override(db, cluster_id, BUNDLE, PROJECT_ID, OverrideType::Disabled)
        .await
        .unwrap();

    heal(&state, cluster_id).await;
    assert!(
        !cluster_mod_enabled(&state, cluster_id).await,
        "a choice made after the cleanup is honoured"
    );
    assert_eq!(
        bundle_dao::list_overrides(db, cluster_id)
            .await
            .unwrap()
            .len(),
        1
    );
}

#[tokio::test]
async fn an_opt_in_bundle_counts_as_taken_only_on_a_recorded_choice() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    seed_opt_in_bundle(&state, "Opt In").await;
    let cluster_id = cluster_with_tracked_mod(&state).await;
    let ctx = state.services.content();
    let taken = || async {
        let archives = state
            .bundles
            .archives_for(&ctx, MC_VERSION, GameLoader::Fabric)
            .await
            .unwrap();
        oneclient_content::bundles::taken_bundle_names(cluster_id, &archives, &ctx)
            .await
            .unwrap()
    };

    assert!(!taken().await.contains("Opt In"));

    oneclient_content::bundles::set_bundle_choices(
        cluster_id,
        &[("Opt In".to_string(), true)],
        &ctx,
    )
    .await
    .unwrap();
    assert!(taken().await.contains("Opt In"));
}

#[tokio::test]
async fn holding_one_mod_of_an_opt_in_bundle_does_not_bring_the_rest() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    let mut m = named_manifest("Opt In", vec![managed_file(true), fabric_api_file()]);
    m.enabled = false;
    seed_bundle_with_pack(&state, m).await;
    let cluster_id = cluster_with_tracked_mod(&state).await;

    let check = check_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &state.services.content(),
    )
    .await
    .unwrap();

    assert!(
        check.additions_available.is_empty(),
        "an opt-in bundle nobody took should add nothing"
    );
}

/// Offline, or any other failed download, must leave the cluster exactly as it
/// was so it still launches: applying the removal while the new mod is missing
/// is the half-updated set that stops a game loading
#[tokio::test]
async fn a_failed_download_applies_nothing() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    let mut unreachable = github_mod_file();
    if let BundleFileKind::External { file, .. } = &mut unreachable.kind {
        file.url = "unsupported://example.invalid/github-mod.jar".to_string();
    }
    oneclient_core::dev::seed_bundle_archive(&state, manifest(vec![unreachable]))
        .await
        .unwrap();
    let cluster_id = cluster_with_tracked_mod(&state).await;
    let ctx = state.services.content();

    let check = check_bundle_updates(cluster_id, state.bundles.as_ref(), &ctx)
        .await
        .unwrap();
    assert_eq!(check.removals_available.len(), 1);
    assert_eq!(check.additions_available.len(), 1);

    let result = oneclient_content::bundles::apply_bundle_updates(
        cluster_id,
        state.bundles.as_ref(),
        &ctx,
        None,
    )
    .await
    .unwrap();

    assert!(
        result.stopped_early,
        "an unfinished batch must not count as settled"
    );
    assert_eq!(
        result.failures().count(),
        0,
        "nothing was applied so there is nothing to block a launch over"
    );
    assert_eq!(result.downloads_failed.len(), 1);
    assert!(result.removals_applied.is_empty());
    assert!(
        artifact_dao::get_cluster_artifact(&state.services.db, cluster_id, HASH)
            .await
            .unwrap()
            .is_some(),
        "the mod due for removal stays until the whole batch can be applied"
    );
}

fn pinned_to(version_id: &str) -> BundleFile {
    BundleFile {
        kind: BundleFileKind::Managed {
            provider: ProviderId::Modrinth,
            project_id: PROJECT_ID.to_string(),
            version_id: version_id.to_string(),
            sha1: "cccccccccccccccccccccccccccccccccccccccc".to_string(),
        },
        ..managed_file(true)
    }
}

async fn mrpack(scratch: &str) -> Vec<u8> {
    let scratch = polyio::testing::ScratchDir::new(scratch);
    let path = scratch.path().join("served.mrpack");
    let index = serde_json::json!({
        "category": "test",
        "enabled": true,
        "versionId": "1",
        "name": "Served",
        "dependencies": { "minecraft": MC_VERSION, "fabric-loader": "0.16.0" },
    });

    let file = tokio::fs::File::create(&path).await.unwrap();
    let mut writer = async_zip::tokio::write::ZipFileWriter::with_tokio(file);
    let entry = async_zip::ZipEntryBuilder::new(
        "modrinth.index.json".to_string().into(),
        async_zip::Compression::Stored,
    );
    writer
        .write_entry_whole(entry, &serde_json::to_vec(&index).unwrap())
        .await
        .unwrap();
    writer.close().await.unwrap();

    tokio::fs::read(&path).await.unwrap()
}

async fn content_serving(
    state: &LauncherState,
    entries: Vec<(&'static str, &'static str, Vec<u8>)>,
) -> ContentCtx {
    use tokio::io::{AsyncReadExt, AsyncWriteExt};

    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let port = listener.local_addr().unwrap().port();

    let mut loaders: HashMap<&str, Vec<serde_json::Value>> = HashMap::new();
    for (loader, path, archive) in &entries {
        loaders.entry(loader).or_default().push(serde_json::json!({
            "path": path,
            "sha1": polyio::sha1_bytes(archive),
        }));
    }
    let catalog = serde_json::json!({ "versions": { MC_VERSION: loaders } })
        .to_string()
        .into_bytes();

    tokio::spawn(async move {
        while let Ok((mut stream, _)) = listener.accept().await {
            let mut request = [0u8; 1024];
            let read = stream.read(&mut request).await.unwrap_or(0);
            let request = String::from_utf8_lossy(&request[..read]).to_string();
            let body = entries
                .iter()
                .find(|(_, path, _)| request.starts_with(&format!("GET {path} ")))
                .map_or(&catalog, |(_, _, archive)| archive);
            let head = format!("HTTP/1.1 200 OK\r\nContent-Length: {}\r\n\r\n", body.len());
            let _ = stream.write_all(head.as_bytes()).await;
            let _ = stream.write_all(body).await;
        }
    });

    let mut content = state.services.content();
    content.net = oneclient_net::RequestClient::new(oneclient_net::NetConfig {
        meta_url_base: format!("http://127.0.0.1:{port}"),
        ..oneclient_net::NetConfig::default()
    })
    .unwrap();
    content
}

async fn listed_bundles(state: &LauncherState, content: &ContentCtx) -> Vec<String> {
    state
        .bundles
        .list_for(content, MC_VERSION, GameLoader::Fabric)
        .await
        .unwrap()
        .into_iter()
        .map(|bundle| bundle.name)
        .collect()
}

#[tokio::test]
async fn an_archive_that_fails_to_stage_keeps_the_previous_catalog() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    oneclient_core::dev::seed_bundle_archive(&state, manifest(vec![pinned_to("v2")]))
        .await
        .unwrap();
    let content = content_serving(
        &state,
        vec![
            ("fabric", "/stages-fine.mrpack", mrpack("stages-fine").await),
            ("fabric", "/not-a-zip.mrpack", b"junk".to_vec()),
        ],
    )
    .await;

    let before = state.bundles.catalog_revision();
    assert!(!state.bundles.sync(&content).await.unwrap());

    let root = oneclient_common::paths::bundles_dir().unwrap();
    assert_eq!(state.bundles.catalog_revision(), before);
    assert_eq!(listed_bundles(&state, &content).await, [BUNDLE]);
    assert!(!root.join("bundles/stages-fine.mrpack").exists());
}

#[tokio::test]
async fn an_unknown_loader_does_not_hold_the_catalog_back() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    let content = content_serving(
        &state,
        vec![
            ("fabric", "/runnable.mrpack", mrpack("runnable").await),
            ("loader-from-the-future", "/future.mrpack", b"junk".to_vec()),
        ],
    )
    .await;

    assert!(state.bundles.sync(&content).await.unwrap());
    assert_eq!(listed_bundles(&state, &content).await, ["Served"]);
}

#[tokio::test]
async fn entries_named_alike_publish_their_own_archives() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    let archive = mrpack("named-alike").await;
    let content = content_serving(
        &state,
        vec![
            ("fabric", "/a/named-alike.mrpack", archive.clone()),
            ("fabric", "/b/named-alike.mrpack", archive),
        ],
    )
    .await;

    assert!(state.bundles.sync(&content).await.unwrap());

    let bundles = state
        .bundles
        .list_for(&content, MC_VERSION, GameLoader::Fabric)
        .await
        .unwrap();
    assert_eq!(bundles.len(), 2);
    assert_ne!(bundles[0].path, bundles[1].path);
    assert!(bundles.iter().all(|bundle| bundle.path.exists()));
}

async fn serve_catalog(
    arrived: Arc<tokio::sync::Notify>,
    release: Arc<tokio::sync::Notify>,
) -> String {
    use tokio::io::{AsyncReadExt, AsyncWriteExt};

    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let port = listener.local_addr().unwrap().port();
    let archive = mrpack("revision").await;
    let catalog = serde_json::json!({ "versions": { MC_VERSION: { "fabric": [{
        "path": "/archive.mrpack",
        "sha1": polyio::sha1_bytes(&archive),
    }]}}})
    .to_string()
    .into_bytes();

    tokio::spawn(async move {
        while let Ok((mut stream, _)) = listener.accept().await {
            let (archive, catalog) = (archive.clone(), catalog.clone());
            let (arrived, release) = (arrived.clone(), release.clone());
            tokio::spawn(async move {
                let mut request = [0u8; 1024];
                let read = stream.read(&mut request).await.unwrap_or(0);
                let is_archive =
                    String::from_utf8_lossy(&request[..read]).starts_with("GET /archive.mrpack");
                let body = if is_archive {
                    arrived.notify_one();
                    release.notified().await;
                    archive
                } else {
                    catalog
                };
                let head = format!("HTTP/1.1 200 OK\r\nContent-Length: {}\r\n\r\n", body.len());
                let _ = stream.write_all(head.as_bytes()).await;
                let _ = stream.write_all(&body).await;
            });
        }
    });

    format!("http://127.0.0.1:{port}")
}

#[tokio::test]
async fn a_revision_moves_only_once_the_archives_are_in() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    let arrived = Arc::new(tokio::sync::Notify::new());
    let release = Arc::new(tokio::sync::Notify::new());
    let meta_url_base = serve_catalog(arrived.clone(), release.clone()).await;

    let mut content = state.services.content();
    content.net = oneclient_net::RequestClient::new(oneclient_net::NetConfig {
        meta_url_base,
        ..oneclient_net::NetConfig::default()
    })
    .unwrap();

    let before = state.bundles.catalog_revision();
    let (synced, ()) = tokio::join!(state.bundles.sync(&content), async {
        arrived.notified().await;
        assert_eq!(
            state.bundles.catalog_revision(),
            before,
            "a check now would read the old archives"
        );
        release.notify_one();
    });

    assert!(synced.unwrap());
    assert_eq!(state.bundles.catalog_revision(), before + 1);
}

async fn serve_stalling_catalog() -> String {
    use tokio::io::{AsyncReadExt, AsyncWriteExt};

    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let port = listener.local_addr().unwrap().port();
    let archive = b"archive".to_vec();
    let catalog = serde_json::json!({ "versions": { MC_VERSION: { "fabric": [
        { "path": "/first-of-two.mrpack", "sha1": polyio::sha1_bytes(&archive) },
        { "path": "/stalled.mrpack", "sha1": polyio::sha1_bytes(b"never sent") },
    ]}}})
    .to_string()
    .into_bytes();

    tokio::spawn(async move {
        while let Ok((mut stream, _)) = listener.accept().await {
            let (archive, catalog) = (archive.clone(), catalog.clone());
            tokio::spawn(async move {
                let mut request = [0u8; 1024];
                let read = stream.read(&mut request).await.unwrap_or(0);
                let request = String::from_utf8_lossy(&request[..read]).to_string();
                if request.starts_with("GET /stalled.mrpack") {
                    std::future::pending::<()>().await;
                }
                let body = if request.starts_with("GET /first-of-two.mrpack") {
                    archive
                } else {
                    catalog
                };
                let head = format!("HTTP/1.1 200 OK\r\nContent-Length: {}\r\n\r\n", body.len());
                let _ = stream.write_all(head.as_bytes()).await;
                let _ = stream.write_all(&body).await;
            });
        }
    });

    format!("http://127.0.0.1:{port}")
}

#[tokio::test]
async fn a_timed_out_sync_publishes_no_archive() {
    let state = oneclient_core::dev::ephemeral_state().await.unwrap();
    let mut content = state.services.content();
    content.net = oneclient_net::RequestClient::new(oneclient_net::NetConfig {
        meta_url_base: serve_stalling_catalog().await,
        ..oneclient_net::NetConfig::default()
    })
    .unwrap();

    let before = state.bundles.catalog_revision();
    let budget = std::time::Duration::from_millis(500);
    tokio::time::timeout(budget, state.bundles.sync(&content))
        .await
        .expect_err("the second archive never arrives");

    let root = oneclient_common::paths::bundles_dir().unwrap();
    assert_eq!(state.bundles.catalog_revision(), before);
    assert!(!root.join("bundles/first-of-two.mrpack").exists());
    assert!(
        root.join("bundles/first-of-two.mrpack.staged").exists(),
        "the next sync resumes from it"
    );
}
