use freya::prelude::*;

use crate::components::{Icon, IconType, ScrollArea, TooltipPlacement, use_tooltip_anchor};
use crate::hooks::use_overlay_claim_when;
use crate::theme::{colors, rounded, text_size};
use crate::ui::{border_all_color, window_logical_size};

const OPTION_HEIGHT: f32 = 28.;
const OPTION_SPACING: f32 = 2.;
const MAX_VISIBLE_OPTIONS: usize = 8;

#[derive(Clone, PartialEq)]
pub struct Dropdown {
    selected: String,
    options: Vec<String>,
    on_select: Option<EventHandler<usize>>,
    leading: Option<Element>,
    width: Size,
    height: Size,
    outlined: bool,
    checked: Option<Vec<bool>>,
    tooltip: Option<Box<str>>,
    key: DiffKey,
}

impl Dropdown {
    pub fn new(selected: impl Into<String>, options: Vec<String>) -> Self {
        Self {
            selected: selected.into(),
            options,
            on_select: None,
            leading: None,
            width: Size::px(72.),
            height: Size::px(24.),
            outlined: false,
            checked: None,
            tooltip: None,
            key: DiffKey::None,
        }
    }

    #[allow(dead_code)]
    pub fn width(mut self, width: impl Into<Size>) -> Self {
        self.width = width.into();
        self
    }

    #[allow(dead_code)]
    pub fn height(mut self, height: impl Into<Size>) -> Self {
        self.height = height.into();
        self
    }

    pub fn outlined(mut self) -> Self {
        self.outlined = true;
        self
    }

    pub fn checked(mut self, checked: Vec<bool>) -> Self {
        self.checked = Some(checked);
        self
    }

    pub fn leading(mut self, leading: impl IntoElement) -> Self {
        self.leading = Some(leading.into_element());
        self
    }

    pub fn on_select(mut self, handler: impl Into<EventHandler<usize>>) -> Self {
        self.on_select = Some(handler.into());
        self
    }

    pub fn tooltip(mut self, tooltip: impl Into<Box<str>>) -> Self {
        self.tooltip = Some(tooltip.into());
        self
    }
}

impl KeyExt for Dropdown {
    fn key_mut(&mut self) -> &mut DiffKey {
        &mut self.key
    }
}

impl Component for Dropdown {
    fn render(&self) -> impl IntoElement {
        let mut open = use_state(|| false);
        let mut hovering = use_state(|| false);

        let a11y_id = use_a11y();
        let focus = use_focus(a11y_id);
        let tooltip = use_tooltip_anchor(self.tooltip.clone(), TooltipPlacement::Top);

        let mut button_area = use_state(|| None::<Area>);
        let mut list_area = use_state(|| None::<Area>);

        let selected = self.selected.clone();
        let leading = self.leading.clone();
        let options = self.options.clone();
        let on_select = self.on_select.clone();
        let outlined = self.outlined;
        let checked = self.checked.clone();
        let multi = checked.is_some();
        let is_open = open();

        use_overlay_claim_when(is_open);

        if !is_open && list_area().is_some() {
            let _ = list_area.take();
        }

        let trigger_bg = if hovering() {
            colors::ghost_overlay_hover()
        } else {
            colors::ghost_overlay()
        };

        let visible = options.len().min(MAX_VISIBLE_OPTIONS);
        let list_h =
            visible as f32 * OPTION_HEIGHT + visible.saturating_sub(1) as f32 * OPTION_SPACING;

        let offset_y = match (button_area(), list_area()) {
            (Some(button), Some(list)) => {
                let root_height = window_logical_size().height;
                let space_below = root_height - button.max_y();
                let space_above = button.min_y();
                if list.height() > space_below && list.height() <= space_above {
                    -(button.height() + list.height() + 8.)
                } else {
                    0.
                }
            }
            _ => 0.,
        };

        let list_width = button_area()
            .map(|b| Size::px(b.width()))
            .unwrap_or_else(|| self.width.clone());

        let on_global_pointer_up = move |e: Event<PointerEventData>| {
            let loc = e.global_location();
            let inside = list_area().is_some_and(|area| {
                area.translate((0., offset_y).into())
                    .contains((loc.x as f32, loc.y as f32).into())
            });
            if !(multi && inside) {
                open.set_if_modified(false);
            }
        };

        rect()
            .width(self.width.clone())
            .on_global_key_down(move |e: Event<KeyboardEventData>| {
                if e.key == Key::Named(NamedKey::Escape) {
                    open.set_if_modified(false);
                }
            })
            .child(
                tooltip
                    .attach(rect())
                    .width(Size::fill())
                    .height(self.height.clone())
                    .horizontal()
                    .center()
                    .spacing(4.)
                    .padding(Gaps::new_symmetric(0., if outlined { 12. } else { 8. }))
                    .corner_radius(rounded(if outlined { 8. } else { 6. }))
                    .background(trigger_bg)
                    .maybe(outlined, |el| {
                        el.main_align(Alignment::SpaceBetween)
                            .border(border_all_color(1., colors::component_border()))
                    })
                    .a11y_id(a11y_id)
                    .a11y_focusable(true)
                    .a11y_role(AccessibilityRole::Button)
                    .maybe(focus().is_focused(), |el| {
                        el.border(border_all_color(1., colors::brand()))
                    })
                    .on_pointer_over(move |_| hovering.set(true))
                    .on_pointer_out(move |_| hovering.set(false))
                    .on_global_pointer_up(on_global_pointer_up)
                    .on_sized(move |e: Event<SizedEventData>| {
                        button_area.set_if_modified(Some(e.area));
                    })
                    .on_press(move |e: Event<PressEventData>| {
                        e.prevent_default();
                        e.stop_propagation();
                        open.toggle();
                    })
                    .maybe_child(leading)
                    .child(
                        label()
                            .text(selected)
                            .font_size(text_size(if outlined { 13. } else { 12. }))
                            .color(colors::fg_primary()),
                    )
                    .child(
                        Icon::new(IconType::ChevronDown)
                            .size(14.)
                            .color(colors::fg_secondary()),
                    ),
            )
            .maybe_child(is_open.then(|| {
                rect().width(Size::px(0.)).height(Size::px(0.)).child(
                    rect()
                        .layer(Layer::Overlay)
                        .width(list_width)
                        .margin(Gaps::new(4., 0., 0., 0.))
                        .offset_y(offset_y)
                        .content(Content::Fit)
                        .on_sized(move |e: Event<SizedEventData>| {
                            list_area.set_if_modified(Some(e.area));
                        })
                        .child(
                            rect()
                                .width(Size::fill())
                                .padding(4.)
                                .corner_radius(rounded(8.))
                                .border(border_all_color(1., colors::component_border()))
                                .background(colors::page_elevated())
                                .overflow(Overflow::Clip)
                                .child(
                                    ScrollArea::new()
                                        .height(Size::px(list_h))
                                        .spacing(OPTION_SPACING)
                                        .children(options.into_iter().enumerate().map(
                                            |(idx, option)| {
                                                let on_select = on_select.clone();
                                                let checked = checked
                                                    .as_ref()
                                                    .map(|c| c.get(idx).copied().unwrap_or(false));
                                                DropdownOption::new(option, checked, move |_| {
                                                    if let Some(handler) = &on_select {
                                                        handler.call(idx);
                                                    }
                                                    if !multi {
                                                        open.set(false);
                                                    }
                                                })
                                                .into_element()
                                            },
                                        )),
                                ),
                        ),
                )
            }))
    }

    fn render_key(&self) -> DiffKey {
        self.key.clone().or(self.default_key())
    }
}

struct DropdownOption {
    text: String,
    checked: Option<bool>,
    on_press: EventHandler<Event<PressEventData>>,
}

impl DropdownOption {
    pub fn new(
        text: impl Into<String>,
        checked: Option<bool>,
        on_press: impl Into<EventHandler<Event<PressEventData>>>,
    ) -> Self {
        Self {
            text: text.into(),
            checked,
            on_press: on_press.into(),
        }
    }
}

impl PartialEq for DropdownOption {
    fn eq(&self, other: &Self) -> bool {
        self.text == other.text && self.checked == other.checked
    }
}

impl Component for DropdownOption {
    fn render(&self) -> impl IntoElement {
        let mut hovering = use_state(|| false);

        let a11y_id = use_a11y();
        let focus = use_focus(a11y_id);

        rect()
            .width(Size::fill())
            .height(Size::px(OPTION_HEIGHT))
            .padding(Gaps::new_symmetric(0., 8.))
            .corner_radius(rounded(6.))
            .a11y_id(a11y_id)
            .a11y_focusable(true)
            .a11y_role(AccessibilityRole::Button)
            .background(if hovering() || focus().is_focused() {
                colors::ghost_overlay_hover()
            } else {
                Color::TRANSPARENT
            })
            .on_pointer_enter(move |_| hovering.set(true))
            .on_pointer_leave(move |_| hovering.set(false))
            .on_press(self.on_press.clone())
            .horizontal()
            .content(Content::Flex)
            .cross_align(Alignment::Center)
            .child(
                label()
                    .text(self.text.clone())
                    .width(Size::flex(1.))
                    .font_size(text_size(12.))
                    .color(colors::fg_primary()),
            )
            .maybe_child(self.checked.map(|checked| {
                rect()
                    .width(Size::px(14.))
                    .height(Size::px(14.))
                    .maybe_child(checked.then(|| {
                        Icon::new(IconType::Check)
                            .size(14.)
                            .color(colors::brand())
                            .into_element()
                    }))
                    .into_element()
            }))
    }
}
