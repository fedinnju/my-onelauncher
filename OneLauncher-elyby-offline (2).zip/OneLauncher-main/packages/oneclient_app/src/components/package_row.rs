use freya::prelude::*;
use freya::router::RouterContext;
use oneclient_content::packages::ProviderId;
use oneclient_core::{BisectRole, SeenStatus};

use crate::components::{ContextMenu, Icon, IconType, toggle_controlled};
use crate::disable::{self, BundlePackage, DisableRequest, DisableRoot};
use crate::essential::EssentialPackage;
use freya::query::UseMutation;

use crate::hooks::{
    Actions, ClusterAction, ClusterMutation, EssentialGuardKind, Guarded, PendingEssential,
    disable_warnings, loaded_image, use_cached_image, use_cluster_mutation, use_disable_confirm,
    use_disable_warnings, use_dispatch, use_essential_guard,
};
use crate::i18n::{t, tf};
use crate::routes::Route;
use crate::theme::{colors, rounded, text_size};
use crate::ui::{ImageFallbackExt, border_all_color};
use crate::utils::format_size;

pub(crate) const CARD_H: f32 = 84.;
pub(crate) const CARD_GRID_H: f32 = 112.;
pub(crate) const GRID_GAP: f32 = 12.;
pub(crate) const GRID_MIN_W: f32 = 290.;
const GRID_CARD_PADDING: f32 = 14.;
const BADGE_STRIP_H: f32 = 20.;
const BADGE_STRIP_LIFT: f32 = 2.;
/// Tint and outline of a selected card
const SELECTION_LAYER: i16 = 16;
/// The grid card's floating badges straddle its bottom edge, so they paint over
/// the selection outline and cover it the way they cover the card's own border
const BADGE_STRIP_LAYER: i16 = SELECTION_LAYER + 1;
/// Catches clicks while selecting, above the badges and everything nested in them,
/// so clicking a badge still selects the card instead of toggling it
const SELECTION_INPUT_LAYER: i16 = BADGE_STRIP_LAYER + 16;

#[derive(Clone, Copy, PartialEq)]
pub enum CardLayout {
    List,
    Grid,
}

impl From<oneclient_core::settings::ViewLayout> for CardLayout {
    fn from(layout: oneclient_core::settings::ViewLayout) -> Self {
        match layout {
            oneclient_core::settings::ViewLayout::Grid => CardLayout::Grid,
            oneclient_core::settings::ViewLayout::List => CardLayout::List,
        }
    }
}

#[derive(Clone, Copy, PartialEq)]
pub enum CopyStatus {
    Loaded,
    Skipped,
}

#[derive(Clone, PartialEq)]
pub struct PackageEntry {
    pub package_id: String,
    pub bundle_name: Option<String>,
    pub provider: ProviderId,
    pub github_hosted: bool,
    pub github_url: Option<String>,
    pub name: String,
    pub file_name: String,
    pub author: String,
    pub version: Option<String>,
    pub description: String,
    pub icon_url: Option<String>,
    pub size: u64,
    pub categories: Vec<String>,
    pub enabled: bool,
    pub installed: bool,
    pub hash: Option<String>,
    pub manifest_default: bool,
    /// Private bundle dependency only set for bundle rows
    pub hidden: bool,
    /// False for uninstalled rows of bundles the cluster never took keeps them out of the All tab
    pub opted_in: bool,
    pub advanced: bool,
    pub deleted: bool,
    /// Only set for browser-installed content bundle packages use the bundle update flow
    pub update_available: bool,
    pub copy_status: Option<CopyStatus>,
    /// Other copies of this mod the loader ignores, folded into this row
    pub copies: Vec<PackageEntry>,
    /// Recency badge state cleared once the user views the list
    pub seen_status: SeenStatus,
    pub essential: Option<&'static EssentialPackage>,
    pub bisect_role: Option<BisectRole>,
    pub locked: bool,
    pub modpack: Option<String>,
    /// RFC 3339 so string order matches time order
    pub added_at: Option<String>,
    /// When the installed version was released RFC 3339
    pub published_at: Option<String>,
}

pub fn folder_pack_id(name: &str, enabled: bool) -> String {
    let state = if enabled { "on" } else { "off" };
    format!("folder:{state}:{name}")
}

pub fn parse_folder_pack_id(id: &str) -> Option<(&str, bool)> {
    let (state, name) = id.strip_prefix("folder:")?.split_once(':')?;
    match state {
        "on" => Some((name, true)),
        "off" => Some((name, false)),
        _ => None,
    }
}

impl PackageEntry {
    pub fn folder_pack(&self) -> Option<(&str, bool)> {
        (self.package_id.starts_with("folder:") && self.hash.is_none() && !self.is_remote())
            .then_some((self.file_name.as_str(), self.enabled))
    }

    pub fn is_remote(&self) -> bool {
        self.provider != ProviderId::Local
    }

    pub fn in_bundle(&self) -> bool {
        self.bundle_name.is_some()
    }

    /// Bundle packages are never marked here so the two update flows cannot contradict
    pub fn is_outdated(&self) -> bool {
        self.update_available && self.is_remote() && !self.in_bundle()
    }

    pub fn recency_badge(&self) -> Option<Element> {
        match self.seen_status {
            SeenStatus::New => Some(new_badge()),
            SeenStatus::Updated => Some(updated_badge()),
            SeenStatus::Seen => None,
        }
    }

    pub fn added_label(&self) -> Option<String> {
        self.copy_status?;
        let added = chrono::DateTime::parse_from_rfc3339(self.added_at.as_deref()?).ok()?;
        Some(tf(
            "oneclient.components.package_row.added",
            &[&crate::ui::fmt_local_datetime(added)],
        ))
    }

    pub fn copy_badge(&self) -> Option<Element> {
        match self.copy_status? {
            CopyStatus::Loaded => Some(status_tag(
                t("oneclient.components.package_row.loaded"),
                colors::success(),
            )),
            CopyStatus::Skipped => Some(pill(
                None,
                t("oneclient.components.package_row.skipped").to_string(),
                colors::fg_secondary(),
            )),
        }
    }

    pub fn bisect_badge(&self) -> Option<Element> {
        let role = self.bisect_role?;
        let accent = match role {
            BisectRole::Testing | BisectRole::Helper => colors::brand(),
            BisectRole::Waiting => colors::fg_secondary(),
            BisectRole::Cleared => colors::success(),
            BisectRole::Found => colors::danger(),
        };
        Some(status_tag(role.label(), accent))
    }
}

#[derive(PartialEq)]
pub struct PackageRow {
    item: PackageEntry,
    cluster_id: i64,
    package_type: &'static str,
    layout: CardLayout,
    on_context: EventHandler<(f32, f32)>,
    selected: bool,
    selecting: bool,
    on_select: EventHandler<()>,
    on_copies: Option<EventHandler<()>>,
    key: DiffKey,
}

impl PackageRow {
    pub fn new(item: PackageEntry, cluster_id: i64, package_type: &'static str) -> Self {
        Self {
            item,
            cluster_id,
            package_type,
            layout: CardLayout::List,
            on_context: (|_| {}).into(),
            selected: false,
            selecting: false,
            on_select: (|()| {}).into(),
            on_copies: None,
            key: DiffKey::None,
        }
    }

    pub fn layout(mut self, layout: CardLayout) -> Self {
        self.layout = layout;
        self
    }

    pub fn on_context(mut self, on_context: impl Into<EventHandler<(f32, f32)>>) -> Self {
        self.on_context = on_context.into();
        self
    }

    pub fn on_copies(mut self, on_copies: impl Into<EventHandler<()>>) -> Self {
        self.on_copies = Some(on_copies.into());
        self
    }

    pub fn selection(
        mut self,
        selected: bool,
        selecting: bool,
        on_select: impl Into<EventHandler<()>>,
    ) -> Self {
        self.selected = selected;
        self.selecting = selecting;
        self.on_select = on_select.into();
        self
    }
}

impl KeyExt for PackageRow {
    fn key_mut(&mut self) -> &mut DiffKey {
        &mut self.key
    }
}

impl Component for PackageRow {
    fn render(&self) -> impl IntoElement {
        let item = self.item.clone();
        let cluster_id = self.cluster_id;
        let package_type = self.package_type;
        let layout = self.layout;
        let cluster = use_cluster_mutation();
        let guard = use_essential_guard();
        let warnings_query = use_disable_warnings();
        let hovered = use_state(|| false);

        let icon_size = match layout {
            CardLayout::List => 44.,
            CardLayout::Grid => 40.,
        };
        let icon_query = use_cached_image(item.icon_url.clone(), 256);
        let icon = package_icon(&item, &icon_query, icon_size);

        let on_toggle: EventHandler<()> = {
            let action = toggle_action(&item, cluster_id, !item.enabled).filter(|_| !item.locked);
            let item = item.clone();
            let warnings = disable_warnings(&warnings_query);
            let pending_disable = use_disable_confirm();
            let dispatch = use_dispatch();
            (move |()| {
                let Some(action) = action.clone() else {
                    return;
                };
                // Switching one off can take other packages with it, so it goes
                // through the impact check rather than straight to the flag.
                // Switching one on never does.
                if item.enabled && item.folder_pack().is_none() {
                    guard_disable(
                        disable_request(&[&item], cluster_id, item.name.clone()),
                        &[&item],
                        warnings.clone(),
                        guard,
                        pending_disable,
                        dispatch.clone(),
                    );
                    return;
                }
                cluster.mutate(action);
            })
            .into()
        };

        let on_context = Some(self.on_context.clone());
        let on_copies = self.on_copies.clone().filter(|_| !item.copies.is_empty());

        let (card, radius) = match layout {
            CardLayout::List => (
                list_card(
                    &item,
                    package_type,
                    cluster_id,
                    icon,
                    on_toggle,
                    on_context.clone(),
                    on_copies,
                ),
                8.,
            ),
            CardLayout::Grid => (
                grid_card(
                    &item,
                    package_type,
                    cluster_id,
                    icon,
                    on_toggle,
                    true,
                    on_context.clone(),
                    on_copies,
                    hovered,
                ),
                6.,
            ),
        };

        let on_select = self.on_select.clone();
        let highlight = (self.selecting && self.selected).then(|| {
            rect()
                .position(Position::new_absolute().top(0.).left(0.))
                .width(Size::percent(100.))
                .height(Size::percent(100.))
                .layer(Layer::Relative(SELECTION_LAYER))
                .corner_radius(rounded(radius))
                .background(colors::brand().with_a(28))
                .border(border_all_color(2., colors::brand()).alignment(BorderAlignment::Inner))
                .into_element()
        });
        let overlay = self.selecting.then(|| {
            rect()
                .position(Position::new_absolute().top(0.).left(0.))
                .width(Size::percent(100.))
                .height(Size::percent(100.))
                .layer(Layer::Relative(SELECTION_INPUT_LAYER))
                .corner_radius(rounded(radius))
                .cursor(CursorIcon::Pointer)
                .on_press(move |_| on_select.call(()))
                .on_secondary_down(on_secondary(on_context))
                .into_element()
        });

        rect()
            .width(Size::fill())
            .height(Size::fill())
            .child(card)
            .maybe_child(highlight)
            .maybe_child(overlay)
    }
}

pub(crate) fn toggle_action(
    item: &PackageEntry,
    cluster_id: i64,
    enabled: bool,
) -> Option<ClusterAction> {
    if let Some((name, _)) = item.folder_pack() {
        return Some(ClusterAction::SetFolderPackEnabled {
            cluster_id,
            name: name.to_string(),
            enabled,
        });
    }
    set_enabled_action(
        cluster_id,
        item.hash.as_deref(),
        item.bundle_name.as_deref(),
        &item.package_id,
        item.manifest_default,
        enabled,
    )
}

pub(crate) fn disable_request(
    items: &[&PackageEntry],
    cluster_id: i64,
    name: String,
) -> DisableRequest {
    let roots = items
        .iter()
        .map(|item| match &item.hash {
            Some(hash) => DisableRoot::Artifact(hash.clone()),
            None => DisableRoot::Package(item.provider, item.package_id.clone()),
        })
        .collect();
    let bundles = items
        .iter()
        .filter(|item| item.hash.is_none())
        .filter_map(|item| {
            Some(BundlePackage {
                bundle_name: item.bundle_name.clone()?,
                package_id: item.package_id.clone(),
            })
        })
        .collect();

    DisableRequest {
        cluster_id,
        name,
        roots,
        bundles,
        warned: Vec::new(),
    }
}

pub(crate) fn set_enabled_action(
    cluster_id: i64,
    hash: Option<&str>,
    bundle_name: Option<&str>,
    package_id: &str,
    manifest_default: bool,
    enabled: bool,
) -> Option<ClusterAction> {
    if let Some(hash) = hash {
        Some(ClusterAction::SetArtifactEnabled {
            cluster_id,
            hash: hash.to_string(),
            enabled,
        })
    } else {
        bundle_name.map(|bundle_name| ClusterAction::SetBundlePackageEnabled {
            cluster_id,
            bundle_name: bundle_name.to_string(),
            package_id: package_id.to_string(),
            enabled,
            manifest_default,
        })
    }
}

pub(crate) fn bundled_delete_action(item: &PackageEntry, cluster_id: i64) -> Option<ClusterAction> {
    let hash = item.hash.clone()?;
    Some(if item.deleted {
        ClusterAction::SetArtifactEnabled {
            cluster_id,
            hash,
            enabled: true,
        }
    } else {
        ClusterAction::DeleteBundledArtifact { cluster_id, hash }
    })
}

pub(crate) fn disable_warning_body(
    item: &PackageEntry,
    warnings: Option<oneclient_core::DisableWarnings>,
) -> Option<String> {
    let bundled = item.in_bundle() && item.provider == ProviderId::Modrinth;

    match warnings {
        Some(warnings) if bundled => warnings.body_for(&item.package_id).map(str::to_string),
        _ => item
            .essential
            .map(|package| (package.disable_body)().to_string()),
    }
}

pub(crate) fn run_guarded(
    action: ClusterAction,
    targets: &[&PackageEntry],
    name: String,
    kind: EssentialGuardKind,
    warnings: Option<oneclient_core::DisableWarnings>,
    cluster: UseMutation<ClusterMutation>,
    mut guard: State<Option<PendingEssential>>,
) {
    let Some((body, _)) = guard_body(targets, &name, warnings) else {
        cluster.mutate(action);
        return;
    };
    guard.set(Some(PendingEssential {
        name,
        body,
        kind,
        then: Guarded::Mutate(action),
    }));
}

pub(crate) fn guard_disable(
    mut request: DisableRequest,
    targets: &[&PackageEntry],
    warnings: Option<oneclient_core::DisableWarnings>,
    mut guard: State<Option<PendingEssential>>,
    pending_disable: State<Option<disable::PendingDisable>>,
    dispatch: Actions,
) {
    let acknowledged = crate::launcher::state()
        .map(|state| state.settings.read().acknowledged_disable_warnings.clone())
        .unwrap_or_default();
    let targets: Vec<&PackageEntry> = targets
        .iter()
        .copied()
        .filter(|p| !acknowledged.contains(&p.package_id))
        .collect();
    let Some((body, warned)) = guard_body(&targets, &request.name, warnings) else {
        disable::request(request, pending_disable, dispatch);
        return;
    };
    request.warned = warned;
    guard.set(Some(PendingEssential {
        name: request.name.clone(),
        body,
        kind: EssentialGuardKind::Disable,
        then: Guarded::Disable(request),
    }));
}

fn guard_body(
    targets: &[&PackageEntry],
    name: &str,
    warnings: Option<oneclient_core::DisableWarnings>,
) -> Option<(String, Vec<String>)> {
    let warned: Vec<(&PackageEntry, String)> = targets
        .iter()
        .filter_map(|p| Some((*p, disable_warning_body(p, warnings.clone())?)))
        .collect();
    let body = match warned.as_slice() {
        [] => return None,
        [(p, body)] if p.name == name => body.clone(),
        _ => warned
            .iter()
            .map(|(p, body)| format!("**{}**\n\n{body}", p.name))
            .collect::<Vec<_>>()
            .join("\n\n"),
    };
    let ids = warned.iter().map(|(p, _)| p.package_id.clone()).collect();
    Some((body, ids))
}

#[allow(clippy::too_many_arguments)]
pub fn package_context_menu(
    x: f32,
    y: f32,
    item: &PackageEntry,
    cluster_id: i64,
    package_type: &'static str,
    on_delete: EventHandler<(String, String)>,
    on_bundled: Option<EventHandler<()>>,
    on_select: EventHandler<()>,
) -> ContextMenu {
    let mut menu = ContextMenu::new(x, y).title(item.name.clone()).action(
        IconType::Check,
        t("oneclient.components.package_row.select"),
        on_select,
    );

    if item.is_remote() {
        let provider = item.provider;
        let package_id = item.package_id.clone();
        let package_type = package_type.to_string();
        menu = menu.action(
            IconType::LinkExternal01,
            t("oneclient.components.package_row.view_in_browser"),
            move |()| {
                let _ = RouterContext::get().push(Route::BrowserPackage {
                    cluster_id,
                    package_type: package_type.clone(),
                    package_id: format!("{}:{}", provider as u8, package_id),
                    add_to_cluster: false,
                });
            },
        );
    }

    if let Some(url) = item.github_url.clone() {
        menu = menu.action(
            IconType::LinkExternal01,
            t("oneclient.components.package_row.view_in_browser"),
            move |()| {
                crate::platform::open_url(&url);
            },
        );
    }

    if let Some(hash) = item.hash.clone() {
        menu = menu.action(
            IconType::Folder,
            t("oneclient.components.package_row.view_in_folder"),
            EventHandler::new_current(move |()| reveal_in_store(hash.clone())),
        );
    }

    if let Some(on_bundled) = on_bundled.filter(|_| item.in_bundle() && item.installed) {
        menu = if item.deleted {
            menu.separator().action(
                IconType::RefreshCcw02,
                t("oneclient.components.package_row.restore"),
                on_bundled,
            )
        } else {
            menu.separator().danger_action(
                IconType::Trash01,
                t("oneclient.common.delete"),
                on_bundled,
            )
        };
    }

    let delete_key = item.hash.clone().or_else(|| {
        item.folder_pack()
            .map(|(name, enabled)| folder_pack_id(name, enabled))
    });
    if item.installed
        && !item.in_bundle()
        && let Some(hash) = delete_key
    {
        let name = item.name.clone();
        menu = menu.separator().danger_action(
            IconType::Trash01,
            t("oneclient.common.delete"),
            move |()| on_delete.call((name.clone(), hash.clone())),
        );
    }

    menu
}

pub(crate) fn on_secondary(
    handler: Option<EventHandler<(f32, f32)>>,
) -> impl FnMut(Event<PressEventData>) {
    move |e: Event<PressEventData>| {
        if let (Some(handler), PressEventData::Mouse(m)) = (handler.as_ref(), e.data()) {
            e.stop_propagation();
            handler.call((m.global_location.x as f32, m.global_location.y as f32));
        }
    }
}

fn list_card(
    item: &PackageEntry,
    package_type: &'static str,
    cluster_id: i64,
    icon: impl IntoElement,
    on_toggle: EventHandler<()>,
    on_context: Option<EventHandler<(f32, f32)>>,
    on_copies: Option<EventHandler<()>>,
) -> Element {
    let copies = item.copies.len();
    rect()
        .horizontal()
        .width(Size::fill())
        .height(Size::px(CARD_H))
        .cross_align(Alignment::Center)
        .spacing(12.)
        .padding(Gaps::new_all(10.))
        .corner_radius(rounded(8.))
        .background(colors::card())
        .content(Content::Flex)
        .maybe(item.copy_status == Some(CopyStatus::Skipped), |el| {
            el.opacity(0.5)
        })
        .on_secondary_down(on_secondary(on_context.clone()))
        .child(package_info(item, package_type, cluster_id, icon))
        .maybe_child(on_copies.map(|on_press| copies_button(copies, on_press)))
        .child(meta_size(item.size))
        .child(toggle_controlled(item.enabled, on_toggle).disabled(item.locked))
        .maybe_child(on_context.map(kebab_button))
        .into_element()
}

#[allow(clippy::too_many_arguments)]
pub(crate) fn grid_card(
    item: &PackageEntry,
    package_type: &'static str,
    cluster_id: i64,
    icon: impl IntoElement,
    on_toggle: EventHandler<()>,
    navigable: bool, // if true, it takes the user to the mod page
    on_context: Option<EventHandler<(f32, f32)>>,
    on_copies: Option<EventHandler<()>>,
    mut hovered: State<bool>,
) -> Element {
    let enabled = item.enabled;
    let title = item.name.clone();
    let hovering = *hovered.read();

    let bg = match (enabled, hovering) {
        (_, true) => colors::component_bg_hover(),
        (true, false) => colors::component_bg(),
        (false, false) => colors::component_bg_disabled(),
    };

    let alpha = if enabled && item.copy_status != Some(CopyStatus::Skipped) {
        255u8
    } else {
        115u8
    };

    let border = if !hovering {
        colors::component_border()
    } else {
        colors::component_border_hover()
    };

    let header = rect()
        .horizontal()
        .width(Size::fill())
        // .cross_align(Alignment::Center)
        .spacing(11.)
        .content(Content::Flex)
        .child(rect().opacity(alpha as f32 / 255.).child(icon))
        .child(
            rect()
                .vertical()
                .width(Size::flex(1.0))
                .spacing(3.)
                .child(
                    label()
                        .text(title)
                        .font_size(text_size(14.))
                        .font_weight(FontWeight::SEMI_BOLD)
                        .max_lines(1)
                        .text_overflow(TextOverflow::Ellipsis)
                        .width(Size::fill())
                        .color(if enabled {
                            colors::fg_strong()
                        } else {
                            colors::fg_primary().with_a(alpha)
                        }),
                )
                .child(grid_meta(item, package_type, cluster_id, navigable, alpha)),
        )
        .maybe_child(on_context.clone().map(kebab_button))
        .into_element();

    let description = (!item.description.is_empty()).then(|| {
        label()
            .text(item.description.clone())
            .font_size(text_size(11.))
            .line_height(1.45)
            .max_lines(2)
            .text_overflow(TextOverflow::Ellipsis)
            .width(Size::fill())
            .color(colors::fg_primary().with_a(scale_a(alpha, 0.72)))
            .into_element()
    });

    let badged = item.is_outdated()
        || item.copy_status.is_some()
        || item.bisect_role.is_some()
        || item.modpack.is_some()
        || item.recency_badge().is_some()
        || on_copies.is_some();
    let copies = item.copies.len();
    let floating = badged.then(|| {
        rect()
            .horizontal()
            .width(Size::fill())
            .height(Size::px(BADGE_STRIP_H))
            .position(
                Position::new_absolute()
                    .bottom(-(GRID_CARD_PADDING + BADGE_STRIP_H / 2.) + BADGE_STRIP_LIFT),
            )
            .layer(Layer::Relative(BADGE_STRIP_LAYER))
            .main_align(Alignment::End)
            .cross_align(Alignment::Center)
            .spacing(4.)
            .maybe_child(on_copies.map(|on_press| copies_button(copies, on_press)))
            .maybe_child(item.modpack.as_deref().map(modpack_badge))
            .maybe_child(item.is_outdated().then(outdated_badge))
            .maybe_child(item.copy_badge())
            .maybe_child(item.bisect_badge())
            .maybe_child(item.recency_badge())
            .into_element()
    });

    rect()
        .vertical()
        .width(Size::fill())
        .height(Size::fill())
        .spacing(9.)
        .padding(Gaps::new_all(GRID_CARD_PADDING))
        .corner_radius(rounded(6.))
        .background(bg.with_a(alpha))
        .border(border_all_color(1., border))
        .content(Content::Flex)
        .cursor(CursorIcon::Pointer)
        .on_pointer_enter(move |_| hovered.set(true))
        .on_pointer_leave(move |_| hovered.set(false))
        .on_secondary_down(on_secondary(on_context))
        .on_press(move |_| on_toggle.call(()))
        .child(header)
        .child(
            rect()
                .vertical()
                .width(Size::fill())
                .height(Size::flex(1.0))
                .overflow(Overflow::Clip)
                .maybe_child(description),
        )
        .maybe_child(floating)
        .into_element()
}

fn scale_a(alpha: u8, factor: f32) -> u8 {
    (alpha as f32 * factor) as u8
}

fn grid_meta(
    item: &PackageEntry,
    package_type: &'static str,
    cluster_id: i64,
    navigable: bool,
    alpha: u8,
) -> Element {
    let muted = colors::fg_primary().with_a(scale_a(alpha, 0.5));

    let source = if let Some(url) = item.github_url.clone() {
        SourceLink {
            text: "GitHub".to_string(),
            on_press: EventHandler::new(move |()| crate::platform::open_url(&url)),
            alpha,
        }
        .into_element()
    } else if item.github_hosted {
        meta_text("GitHub".to_string(), muted)
    } else if item.is_remote() && navigable {
        let provider = item.provider;
        let package_id = item.package_id.clone();
        SourceLink {
            text: provider.to_string(),
            on_press: EventHandler::new(move |()| {
                let _ = RouterContext::get().push(Route::BrowserPackage {
                    cluster_id,
                    package_type: package_type.to_string(),
                    package_id: format!("{}:{}", provider as u8, package_id),
                    add_to_cluster: false,
                });
            }),
            alpha,
        }
        .into_element()
    } else if item.is_remote() {
        meta_text(item.provider.to_string(), muted)
    } else {
        meta_text(
            t("oneclient.components.package_row.local_file").to_string(),
            muted,
        )
    };

    let mut parts: Vec<Element> = Vec::new();
    if !item.author.is_empty() {
        parts.push(meta_text(
            tf(
                "oneclient.components.package_row.by_author",
                &[&item.author],
            ),
            muted,
        ));
    }
    if let Some(added) = item.added_label() {
        parts.push(meta_text(added, muted));
    }
    if let Some(version) = &item.version {
        parts.push(meta_text(version.clone(), muted));
    }
    parts.push(source);

    let mut row = rect()
        .horizontal()
        .width(Size::fill())
        .cross_align(Alignment::Center)
        .spacing(5.)
        .overflow(Overflow::Clip);

    for (i, part) in parts.into_iter().enumerate() {
        if i > 0 {
            row = row.child(meta_text("\u{b7}".to_string(), muted));
        }
        row = row.child(part);
    }

    row.into_element()
}

#[derive(PartialEq)]
struct SourceLink {
    text: String,
    on_press: EventHandler<()>,
    alpha: u8,
}

impl Component for SourceLink {
    fn render(&self) -> impl IntoElement {
        let mut hovered = use_state(|| false);
        let mut pressed = use_state(|| false);

        let color = if *pressed.read() {
            colors::fg_primary_pressed()
        } else if *hovered.read() {
            colors::fg_primary_hover()
        } else {
            colors::fg_primary().with_a(scale_a(self.alpha, 0.68))
        };

        let on_press = self.on_press.clone();

        rect()
            .cursor(CursorIcon::Pointer)
            .on_pointer_enter(move |_| hovered.set(true))
            .on_pointer_leave(move |_| {
                hovered.set(false);
                pressed.set(false);
            })
            .on_pointer_down(move |_| pressed.set(true))
            .on_press(move |e: Event<PressEventData>| {
                e.stop_propagation();
                pressed.set(false);
                on_press.call(());
            })
            .child(meta_text(self.text.clone(), color))
    }
}

pub(crate) fn meta_text(text: String, color: Color) -> Element {
    label()
        .text(text)
        .font_size(text_size(11.))
        .max_lines(1)
        .color(color)
        .into_element()
}

pub(crate) fn kebab_button(on_context: EventHandler<(f32, f32)>) -> Element {
    KebabButton { on_context }.into_element()
}

#[derive(PartialEq)]
struct KebabButton {
    on_context: EventHandler<(f32, f32)>,
}

impl Component for KebabButton {
    fn render(&self) -> impl IntoElement {
        let mut hovered = use_state(|| false);
        let on_context = self.on_context.clone();

        rect()
            .center()
            .width(Size::px(26.))
            .height(Size::px(26.))
            .corner_radius(rounded(6.))
            .background(if *hovered.read() {
                colors::ghost_overlay_hover()
            } else {
                Color::TRANSPARENT
            })
            .cursor(CursorIcon::Pointer)
            .a11y_role(AccessibilityRole::Button)
            .on_pointer_enter(move |_| hovered.set(true))
            .on_pointer_leave(move |_| hovered.set(false))
            .on_press(move |e: Event<PressEventData>| {
                e.stop_propagation();
                if let PressEventData::Mouse(m) = e.data() {
                    on_context.call((m.global_location.x as f32, m.global_location.y as f32));
                }
            })
            .child(
                Icon::new(IconType::DotsVertical)
                    .size(16.)
                    .color(if *hovered.read() {
                        colors::fg_primary()
                    } else {
                        colors::fg_secondary()
                    }),
            )
    }
}

fn reveal_in_store(hash: String) {
    spawn(async move {
        let Ok(state) = crate::launcher::state() else {
            return;
        };
        let row = match oneclient_db::dao::artifact::get_artifact_by_hash(&state.services.db, &hash)
            .await
        {
            Ok(Some(row)) => row,
            Ok(None) => return,
            Err(err) => {
                tracing::warn!(%err, "failed to look up artifact for reveal");
                return;
            }
        };
        let Ok(path) = oneclient_content::packages::store::artifact_absolute_path(&row.path) else {
            return;
        };
        if let Some(dir) = path.parent() {
            crate::platform::open_path(&dir.to_string_lossy());
        }
    });
}

fn package_info(
    item: &PackageEntry,
    package_type: &'static str,
    cluster_id: i64,
    icon: impl IntoElement,
) -> impl IntoElement {
    let remote = item.is_remote();
    let provider = item.provider;
    let package_id = item.package_id.clone();
    let package_type = package_type.to_string();
    let title = item.name.clone();
    let author = (!item.author.is_empty()).then(|| {
        tf(
            "oneclient.components.package_row.by_author",
            &[&item.author],
        )
    });
    let byline = author
        .into_iter()
        .chain(item.added_label())
        .collect::<Vec<_>>()
        .join(" \u{b7} ");

    rect()
        .horizontal()
        .width(Size::flex(1.0))
        .cross_align(Alignment::Center)
        .spacing(12.)
        .content(Content::Flex)
        .maybe(remote, |el| {
            el.cursor(CursorIcon::Pointer).on_press(move |_| {
                let _ = RouterContext::get().push(Route::BrowserPackage {
                    cluster_id,
                    package_type: package_type.clone(),
                    package_id: format!("{}:{}", provider as u8, package_id),
                    add_to_cluster: false,
                });
            })
        })
        .child(icon)
        .child(
            rect()
                .vertical()
                .width(Size::flex(1.0))
                .spacing(3.)
                .child(
                    rect()
                        .horizontal()
                        .width(Size::fill())
                        .cross_align(Alignment::Center)
                        .spacing(8.)
                        .child(
                            label()
                                .text(title)
                                .font_size(text_size(15.))
                                .font_weight(FontWeight::MEDIUM)
                                .max_lines(1)
                                .text_overflow(TextOverflow::Ellipsis)
                                .max_width(Size::percent(60.))
                                .color(colors::fg_primary()),
                        )
                        .child(if let Some(url) = item.github_url.clone() {
                            rect()
                                .cursor(CursorIcon::Pointer)
                                .on_press(move |e: Event<PressEventData>| {
                                    e.stop_propagation();
                                    crate::platform::open_url(&url);
                                })
                                .child(github_badge())
                                .into_element()
                        } else if item.github_hosted {
                            github_badge()
                        } else if remote {
                            provider_badge(item.provider)
                        } else {
                            local_badge()
                        })
                        .maybe_child(item.modpack.as_deref().map(modpack_badge))
                        .maybe_child(item.is_outdated().then(outdated_badge))
                        .maybe_child(item.copy_badge())
                        .maybe_child(item.bisect_badge())
                        .maybe_child(item.recency_badge()),
                )
                .maybe(!byline.is_empty(), |el| {
                    el.child(
                        label()
                            .text(byline)
                            .font_size(text_size(10.))
                            .max_lines(1)
                            .text_overflow(TextOverflow::Ellipsis)
                            .width(Size::fill())
                            .color(colors::fg_secondary()),
                    )
                })
                .maybe(!item.description.is_empty(), |el| {
                    el.child(
                        label()
                            .text(item.description.clone())
                            .font_size(text_size(11.))
                            .max_lines(2)
                            .text_overflow(TextOverflow::Ellipsis)
                            .width(Size::fill())
                            .color(colors::fg_secondary()),
                    )
                }),
        )
        .into_element()
}

pub(crate) fn package_icon(
    item: &PackageEntry,
    icon_query: &freya::query::UseQuery<crate::hooks::CachedImageQuery>,
    size: f32,
) -> Element {
    remote_icon(item.icon_url.as_deref(), icon_query, size)
}

pub(crate) fn remote_icon(
    icon_url: Option<&str>,
    icon_query: &freya::query::UseQuery<crate::hooks::CachedImageQuery>,
    size: f32,
) -> Element {
    let loaded = loaded_image(icon_url, icon_query);

    match loaded {
        Some((url, bytes)) => ImageViewer::new((url, bytes))
            .width(Size::px(size))
            .height(Size::px(size))
            .aspect_ratio(AspectRatio::Min)
            .corner_radius(rounded(8.))
            .fallback(icon_box(IconType::DotsGrid, size))
            .into_element(),

        None if icon_url.is_some() => icon_box(IconType::DotsGrid, size),
        None => icon_box(IconType::HelpCircle, size),
    }
}

pub(crate) fn icon_box(icon: IconType, size: f32) -> Element {
    rect()
        .center()
        .width(Size::px(size))
        .height(Size::px(size))
        .corner_radius(rounded(8.))
        .background(colors::component_bg())
        .child(
            Icon::new(icon)
                .size(size * 0.4)
                .color(colors::fg_secondary()),
        )
        .into_element()
}

pub(crate) fn meta_size(size: u64) -> impl IntoElement {
    rect()
        .maybe_child((size > 0).then(|| {
            label()
                .text(format_size(size))
                .font_size(text_size(11.))
                .color(colors::fg_secondary())
        }))
        .into_element()
}

pub fn provider_badge(provider: ProviderId) -> Element {
    badge(
        Icon::new(provider).size(12.).into_element(),
        provider.to_string(),
    )
}

pub fn github_badge() -> Element {
    badge(
        Icon::new(IconType::Github).size(12.).into_element(),
        "GitHub".to_string(),
    )
}

fn outdated_badge() -> Element {
    status_tag(
        t("oneclient.components.package_row.update_available"),
        colors::brand(),
    )
}

fn copies_button(ignored: usize, on_press: EventHandler<()>) -> Element {
    rect()
        .cursor(CursorIcon::Pointer)
        .on_press(move |e: Event<PressEventData>| {
            e.stop_propagation();
            on_press.call(());
        })
        .child(accent_badge(
            Icon::new(IconType::Copy01)
                .size(12.)
                .color(colors::brand())
                .into_element(),
            tf("oneclient.components.package_row.copies", &[&(ignored + 1)]),
            colors::brand(),
        ))
        .into_element()
}

fn new_badge() -> Element {
    status_tag(t("oneclient.components.package_row.new"), colors::success())
}

fn updated_badge() -> Element {
    status_tag(
        t("oneclient.components.package_row.updated"),
        colors::success(),
    )
}

fn status_tag(text: impl Into<String>, accent: Color) -> Element {
    rect()
        .corner_radius(rounded(4.))
        .background(colors::component_bg())
        .child(
            rect()
                .padding(Gaps::new(1., 6., 2., 6.))
                .corner_radius(rounded(4.))
                .background(accent.with_a(38))
                .border(border_all_color(1., accent.with_a(96)))
                .child(
                    label()
                        .text(text.into())
                        .font_size(text_size(10.))
                        .font_weight(FontWeight::SEMI_BOLD)
                        .color(accent),
                ),
        )
        .into_element()
}

const MODPACK_TAG_CHARS: usize = 10;
const MODPACK_TAG_ELLIPSIS: &str = "...";

fn modpack_badge(name: &str) -> Element {
    status_tag(
        crate::utils::shorten(name, MODPACK_TAG_CHARS, MODPACK_TAG_ELLIPSIS),
        colors::code_info(),
    )
}

fn local_badge() -> Element {
    badge(
        Icon::new(IconType::File02)
            .size(12.)
            .color(colors::fg_secondary())
            .into_element(),
        t("oneclient.components.package_row.local_file").to_string(),
    )
}

pub(crate) fn badge(icon: impl IntoElement, text: String) -> Element {
    accent_badge(icon, text, colors::fg_secondary())
}

fn accent_badge(icon: impl IntoElement, text: String, accent: Color) -> Element {
    pill(Some(icon.into_element()), text, accent)
}

pub(crate) fn pill(icon: Option<Element>, text: String, accent: Color) -> Element {
    rect()
        .horizontal()
        .cross_align(Alignment::Center)
        .spacing(4.)
        .padding(Gaps::new_symmetric(2., 8.))
        .corner_radius(rounded(999.))
        .border(border_all_color(1., colors::component_border()))
        .background(colors::component_bg())
        .maybe_child(icon)
        .child(
            label()
                .text(text)
                .font_size(text_size(10.))
                .font_weight(FontWeight::MEDIUM)
                .color(accent),
        )
        .into_element()
}

