mod app_navbar;
mod onboarding_navbar;

pub use app_navbar::Navbar as AppNavbar;
pub use onboarding_navbar::OnboardingNavbar;

use freya::prelude::*;

use crate::components::{Button, Icon, IconType};
use crate::i18n::t;

pub(crate) fn navbar_button(foreground: Option<Color>) -> Button {
    Button::new()
        .ghost()
        .foreground(foreground)
        .icon()
        .width(Size::px(36.))
        .height(Size::px(36.))
}

pub fn window_controls() -> impl IntoElement {
    window_controls_with(None, close_launcher)
}

pub(crate) fn close_launcher() {
    crate::view::chat::close_chat_window();
    crate::platform::close();
}

pub fn window_controls_with(foreground: Option<Color>, on_close: fn()) -> impl IntoElement {
    let minimize = |_| {
        Platform::get().with_window(Platform::window_id(), |win| {
            win.set_minimized(true);
        });
    };

    let maximize = |_| {
        Platform::get().with_window(Platform::window_id(), |win| {
            win.set_maximized(!win.is_maximized());
        });
    };

    let close = move |_| on_close();

    rect()
        .horizontal()
        .main_align(Alignment::End)
        .cross_align(Alignment::Center)
        .spacing(8.)
        .layer(Layer::OverlayLevel(15))
        .child(
            navbar_button(foreground)
                .tooltip(t("oneclient.components.navbar.minimize"))
                .child(Icon::new(IconType::Minus))
                .on_press(minimize),
        )
        .child(
            navbar_button(foreground)
                .tooltip(t("oneclient.components.navbar.maximize"))
                .child(Icon::new(IconType::Maximize01).size(20.))
                .on_press(maximize),
        )
        .child(
            navbar_button(foreground)
                .tooltip(t("oneclient.common.close"))
                .child(Icon::new(IconType::X))
                .on_press(close),
        )
}
