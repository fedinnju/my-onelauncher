use freya::prelude::*;

use crate::components::{
    Button, CodeBlock, Icon, IconType, OVERLAY_BASE_LEVEL, OverlayPopup, copy_button,
};
use crate::hooks::{use_dispatch, use_link_confirm};
use crate::i18n::t;
use crate::theme::{colors, rounded, text_size};
use crate::ui::border_all_color;

#[derive(PartialEq)]
pub struct ConfirmLinkOverlay;

impl Component for ConfirmLinkOverlay {
    fn render(&self) -> impl IntoElement {
        let mut pending = use_link_confirm();
        let dispatch = use_dispatch();
        let Some(url) = pending.read().clone() else {
            return rect().into_element();
        };

        let open_url = url.clone();
        let (title, body) = if is_first_party(&url) {
            (
                t("oneclient.components.link_confirm.first_party.title"),
                t("oneclient.components.link_confirm.first_party.body"),
            )
        } else {
            (
                t("oneclient.components.link_confirm.external.title"),
                t("oneclient.components.link_confirm.external.body"),
            )
        };

        OverlayPopup::new()
            .overlay_level(OVERLAY_BASE_LEVEL + 3)
            .on_close(move |_| pending.set(None))
            .child(
                rect()
                    .width(Size::window_percent(100.))
                    .height(Size::window_percent(100.))
                    .center()
                    .child(
                        rect()
                            .vertical()
                            .width(Size::px(440.))
                            .max_width(Size::window_percent(90.))
                            .spacing(14.)
                            .padding(Gaps::new_all(20.))
                            .corner_radius(rounded(14.))
                            .background(colors::card())
                            .border(border_all_color(1., colors::component_border()))
                            .child(
                                rect()
                                    .horizontal()
                                    .cross_align(Alignment::Center)
                                    .spacing(10.)
                                    .child(
                                        Icon::new(IconType::AlertTriangle)
                                            .size(20.)
                                            .color(colors::code_warn()),
                                    )
                                    .child(
                                        label()
                                            .text(title)
                                            .font_size(text_size(16.))
                                            .font_weight(FontWeight::SEMI_BOLD)
                                            .color(colors::fg_primary()),
                                    ),
                            )
                            .child(
                                label()
                                    .text(body)
                                    .font_size(text_size(12.))
                                    .color(colors::fg_secondary()),
                            )
                            .child(
                                CodeBlock::new(url.clone())
                                    .color(colors::code_info())
                                    .max_lines(4),
                            )
                            .child(
                                rect()
                                    .horizontal()
                                    .width(Size::fill())
                                    .main_align(Alignment::End)
                                    .spacing(8.)
                                    .child(copy_button(
                                        url.clone(),
                                        t("oneclient.components.link_confirm.copied"),
                                        dispatch,
                                    ))
                                    .child(
                                        Button::new()
                                            .secondary()
                                            .on_press(move |_| pending.set(None))
                                            .text(t("oneclient.common.cancel")),
                                    )
                                    .child(
                                        Button::new()
                                            .primary()
                                            .on_press(move |_| {
                                                crate::platform::open_url(&open_url);
                                                pending.set(None);
                                            })
                                            .child(Icon::new(IconType::LinkExternal01).size(14.))
                                            .text(t("oneclient.components.link_confirm.open")),
                                    ),
                            ),
                    ),
            )
            .into_element()
    }
}

fn is_first_party(url: &str) -> bool {
    let host = url
        .split_once("://")
        .map_or(url, |(_, rest)| rest)
        .split(['/', '?', '#', ':'])
        .next()
        .unwrap_or_default();
    host == "polyfrost.org" || host.ends_with(".polyfrost.org")
}
