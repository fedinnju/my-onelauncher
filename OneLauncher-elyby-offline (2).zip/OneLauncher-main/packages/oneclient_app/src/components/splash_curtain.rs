use std::time::Duration;

use freya::animation::{AnimNum, Ease, Function, use_animation};
use freya::prelude::*;

use crate::hooks::use_splash;
use crate::theme::colors;

const FADE_MS: u64 = 460;
/// Safety net reveal the app even if the "ready" signal never arrives
const FALLBACK_MS: u64 = 8000;

#[derive(PartialEq)]
pub struct SplashCurtain;

impl Component for SplashCurtain {
    fn render(&self) -> impl IntoElement {
        let splash = use_splash();

        if !*splash.active.read() {
            return rect().into_element();
        }

        // Fresh mount so `CurtainFade`'s animation and timers restart each time
        CurtainFade.into_element()
    }
}

#[derive(PartialEq)]
struct CurtainFade;

impl Component for CurtainFade {
    fn render(&self) -> impl IntoElement {
        let splash = use_splash();
        let ready = *splash.home_ready.read();

        let fade = use_animation(|_| {
            AnimNum::new(1.0, 0.0)
                .time(FADE_MS)
                .ease(Ease::Out)
                .function(Function::Cubic)
        });

        // Force-reveal after a while if home never reports ready
        use_hook(move || {
            let mut home_ready = splash.home_ready;
            spawn(async move {
                tokio::time::sleep(Duration::from_millis(FALLBACK_MS)).await;
                if !*home_ready.peek() {
                    home_ready.set(true);
                }
            });
        });

        use_side_effect_with_deps(&ready, move |&ready| {
            if !ready {
                return;
            }
            let mut fade = fade;
            fade.start();
            let mut active = splash.active;
            spawn(async move {
                tokio::time::sleep(Duration::from_millis(FADE_MS + 40)).await;
                active.set(false);
            });
        });

        let alpha = fade.get().value().clamp(0., 1.);

        rect()
            .width(Size::fill())
            .height(Size::fill())
            .position(Position::new_global().top(0.).left(0.))
            .layer(Layer::Overlay)
            .background(colors::page().with_a((255. * alpha).round() as u8))
            .window_drag()
            .into_element()
    }
}
