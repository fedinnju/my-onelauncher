//! The Ely.by sign-in dialog both the settings page and onboarding raise it
//! the same way [`super::MicrosoftLogin`] does for the Microsoft flow

use crate::i18n::t;
use freya::prelude::*;
use freya::query::{MutationCapability, MutationStateData, UseMutation};
use oneclient_core::LauncherError;

use crate::components::{Button, Icon, IconType, OverlayPopup, TextInput};
use crate::hooks::{AddElyAccountKeys, is_two_factor_error, use_add_ely_account};
use crate::theme::{colors, rounded, text_size};
use crate::ui::border_all_color;

#[derive(Clone)]
pub struct ElyLogin {
    add: UseMutation<crate::hooks::AddElyAccountMutation>,
    open: State<bool>,
    needs_totp: State<bool>,
    login: State<String>,
    password: State<String>,
    totp: State<String>,
    pub pending: bool,
    pub error: Option<String>,
}

impl ElyLogin {
    /// Opens the dialog the sign-in itself starts once the user confirms
    pub fn start(&self) {
        let mut open = self.open;
        open.set(true);
    }

    pub fn popup(&self) -> Option<impl IntoElement> {
        if !*self.open.read() {
            return None;
        }
        Some(ely_dialog(self.clone()))
    }
}

pub fn use_ely_login() -> ElyLogin {
    let add = use_add_ely_account();
    let mut open = use_state(|| false);
    let mut needs_totp = use_state(|| false);
    let mut login = use_state(String::new);
    let mut password = use_state(String::new);
    let mut totp = use_state(String::new);

    // A settled sign-in closes the dialog on success a two-factor rejection
    // keeps it open and reveals the one-time-code field every other error
    // stays visible so the user can retry
    use_side_effect(move || match &*add.read().state() {
        MutationStateData::Settled { res: Ok(_), .. } => {
            open.set(false);
            needs_totp.set(false);
            login.set(String::new());
            password.set(String::new());
            totp.set(String::new());
        }
        MutationStateData::Settled {
            res: Err(err),
            ..
        } => {
            needs_totp.set(is_two_factor_error(err));
        }
        _ => {}
    });

    let pending = add.read().state().is_loading();
    let error = mutation_err_text(&add);

    ElyLogin {
        add,
        open,
        needs_totp,
        login,
        password,
        totp,
        pending,
        error,
    }
}

/// Hooks live in [`use_ely_login`] this only renders so the popup can appear
/// and disappear without reshuffling the hook order
fn ely_dialog(handle: ElyLogin) -> impl IntoElement {
    let needs_totp = *handle.needs_totp.read();
    let error = handle.error.clone();
    let pending = handle.pending;

    let confirm = handle.clone();
    let on_confirm = move |_: Event<PressEventData>| {
        let login_name = confirm.login.peek().trim().to_string();
        let password_value = confirm.password.peek().to_string();
        if login_name.is_empty() || password_value.is_empty() {
            return;
        }
        let code = confirm.totp.peek().trim().to_string();
        confirm.add.mutate(AddElyAccountKeys {
            username: login_name,
            password: password_value,
            totp: (!code.is_empty()).then_some(code),
        });
    };

    let mut close = handle.clone();
    let mut cancel = handle.clone();
    OverlayPopup::new()
        .on_close(move |()| {
            close.open.set(false);
            close.needs_totp.set(false);
        })
        .child(
            rect()
                .width(Size::window_percent(100.))
                .height(Size::window_percent(100.))
                .center()
                .child(
                    rect()
                        .vertical()
                        .width(Size::px(380.))
                        .max_width(Size::window_percent(90.))
                        .spacing(16.)
                        .padding(Gaps::new_all(20.))
                        .corner_radius(rounded(16.))
                        .background(colors::page_elevated())
                        .border(border_all_color(1., colors::component_border()))
                        .child(
                            label()
                                .text(t("oneclient.settings.accounts.ely.title"))
                                .font_size(text_size(18.))
                                .font_weight(FontWeight::SEMI_BOLD)
                                .color(colors::fg_primary()),
                        )
                        .child(
                            rect()
                                .vertical()
                                .width(Size::fill())
                                .spacing(6.)
                                .child(field_label(t(
                                    "oneclient.settings.accounts.ely.login",
                                )))
                                .child(TextInput::new(handle.login).placeholder(t(
                                    "oneclient.settings.accounts.ely.login_placeholder",
                                ))),
                        )
                        .child(
                            rect()
                                .vertical()
                                .width(Size::fill())
                                .spacing(6.)
                                .child(field_label(t(
                                    "oneclient.settings.accounts.ely.password",
                                )))
                                .child(TextInput::new(handle.password)),
                        )
                        .child(
                            rect()
                                .vertical()
                                .width(Size::fill())
                                .spacing(6.)
                                .child(field_label(t(
                                    "oneclient.settings.accounts.ely.totp",
                                )))
                                .child(TextInput::new(handle.totp)),
                        )
                        .maybe_child(needs_totp.then(|| {
                            hint_line(
                                IconType::InfoCircle,
                                t("oneclient.settings.accounts.ely.totp_hint").to_string(),
                                colors::brand(),
                            )
                        }))
                        .map(error, |el, msg| {
                            el.child(hint_line(IconType::AlertTriangle, msg, colors::danger()))
                        })
                        .child(
                            rect()
                                .horizontal()
                                .width(Size::fill())
                                .main_align(Alignment::End)
                                .spacing(8.)
                                .child(
                                    Button::new()
                                        .ghost()
                                        .on_press(move |_| cancel.open.set(false))
                                        .text(t("oneclient.common.cancel")),
                                )
                                .child(
                                    Button::new()
                                        .primary()
                                        .enabled(!pending)
                                        .on_press(on_confirm)
                                        .text(if pending {
                                            t("oneclient.settings.accounts.signing_in")
                                        } else {
                                            t("oneclient.settings.accounts.ely.confirm")
                                        }),
                                ),
                        ),
                ),
        )
        .into_element()
}

fn field_label(text: &str) -> impl IntoElement {
    label()
        .text(text.to_string())
        .font_size(text_size(11.))
        .font_weight(FontWeight::MEDIUM)
        .color(colors::fg_secondary())
        .into_element()
}

fn hint_line(icon: IconType, text: String, color: Color) -> impl IntoElement {
    rect()
        .horizontal()
        .width(Size::fill())
        .content(Content::Flex)
        .cross_align(Alignment::Center)
        .spacing(6.)
        .child(Icon::new(icon).size(13.).color(color))
        .child(
            label()
                .text(text)
                .font_size(text_size(12.))
                .width(Size::flex(1.0))
                .color(color),
        )
        .into_element()
}

fn mutation_err_text<M>(mutation: &UseMutation<M>) -> Option<String>
where
    M: MutationCapability<Err = LauncherError>,
{
    match &*mutation.read().state() {
        MutationStateData::Settled { res: Err(err), .. }
        | MutationStateData::Loading {
            res: Some(Err(err)),
        } => Some(err.to_string()),
        _ => None,
    }
}
