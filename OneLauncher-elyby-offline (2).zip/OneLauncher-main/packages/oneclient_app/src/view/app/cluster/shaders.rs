use freya::prelude::*;
use oneclient_content::packages::ContentType;

use crate::hooks::{
    bundle_overrides_map, bundles_with_status_items, cluster_content_items, stale_hashes,
    use_bundle_overrides, use_bundles_with_status, use_cluster_content, use_package_updates,
};
use crate::i18n::t;
use crate::layout::cluster_content;

use super::cluster_not_found;
use super::package_manager::{
    PackageManager, bundle_categories, bundle_packages, use_content_meta,
};
use crate::hooks::use_cluster;

#[derive(PartialEq)]
pub struct ClusterShaders {
    pub cluster_id: i64,
}

impl Component for ClusterShaders {
    fn render(&self) -> impl IntoElement {
        let content = use_cluster_content(self.cluster_id, ContentType::Shader);
        let bundles = use_bundles_with_status(self.cluster_id);
        let overrides = use_bundle_overrides(self.cluster_id);
        let updates = use_package_updates(self.cluster_id);
        let bundle_items = bundles_with_status_items(&bundles);
        let content_items = cluster_content_items(&content);
        let meta = use_content_meta(&content_items, &bundle_items, ContentType::Shader);

        let Some(_cluster) = use_cluster(self.cluster_id) else {
            return cluster_not_found();
        };

        let all_categories = bundle_categories(&bundle_items);
        let items = bundle_packages(
            content_items,
            &bundle_items,
            &bundle_overrides_map(&overrides),
            &meta,
            &stale_hashes(&updates),
            ContentType::Shader,
        );

        cluster_content()
            .child(
                PackageManager::new(
                    t("oneclient.cluster.shaders.title"),
                    t("oneclient.cluster.package_manager.noun.shader.other"),
                    "shader",
                    ContentType::Shader,
                    self.cluster_id,
                    items,
                    all_categories,
                )
                .into_element(),
            )
            .into_element()
    }
}
