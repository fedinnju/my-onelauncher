use freya::prelude::*;
use freya::router::RouterContext;
use oneclient_core::clusters::{ImportedModpack, ModpackSource};

use super::folder_list::dialog;
use crate::components::{Button, Icon, IconType, remote_icon};
use crate::hooks::{
    imported_modpacks_list, use_cached_image, use_dispatch, use_imported_modpacks,
    use_installs_snapshot,
};
use crate::i18n::{t, tf};
use crate::routes::Route;
use crate::theme::{colors, rounded, text_size};
use crate::view::app::settings::{section_header, settings_row};

const MODPACK_EXTENSIONS: [&str; 2] = ["mrpack", "zip"];
const MODPACK_BROWSE_TYPE: &str = "modpack";
const PACK_ICON: f32 = 32.;

fn pick_modpack(cluster_id: i64, dispatch: crate::Actions) {
    spawn(async move {
        let Some(handle) = rfd::AsyncFileDialog::new()
            .set_title(t("oneclient.cluster.imported_modpacks.picker.title"))
            .add_filter(
                t("oneclient.cluster.imported_modpacks.picker.filter"),
                &MODPACK_EXTENSIONS,
            )
            .pick_file()
            .await
        else {
            return;
        };
        dispatch.import_modpack(cluster_id, ModpackSource::File(handle.path().to_path_buf()));
    });
}

fn browse_modpacks(cluster_id: i64) {
    let _ = RouterContext::get().push(Route::Browser {
        cluster_id,
        package_type: MODPACK_BROWSE_TYPE.to_string(),
        pick_cluster: false,
    });
}

#[derive(PartialEq)]
pub struct ImportedModpacksSection {
    pub cluster_id: i64,
}

impl Component for ImportedModpacksSection {
    fn render(&self) -> impl IntoElement {
        let cluster_id = self.cluster_id;
        let dispatch = use_dispatch();
        let installs = use_installs_snapshot();
        let packs = imported_modpacks_list(&use_imported_modpacks(cluster_id));
        let pending_remove = use_state(|| None::<ImportedModpack>);
        let busy = installs.modpack_busy;

        use_side_effect_with_deps(&cluster_id, move |_| {
            let mut pending = pending_remove;
            pending.set(None);
        });

        let import = dispatch.clone();
        let add_button = Button::new()
            .small()
            .secondary()
            .enabled(!busy)
            .maybe(!busy, |el| {
                el.on_press(move |_| pick_modpack(cluster_id, import.clone()))
            })
            .text(if busy {
                t("oneclient.cluster.imported_modpacks.working")
            } else {
                t("oneclient.cluster.imported_modpacks.choose_file")
            });
        let add_buttons = rect()
            .horizontal()
            .cross_align(Alignment::Center)
            .spacing(8.)
            .child(
                Button::new()
                    .small()
                    .secondary()
                    .on_press(move |_| browse_modpacks(cluster_id))
                    .text(t("oneclient.common.browse")),
            )
            .child(add_button);

        let rows: Vec<Element> = packs
            .iter()
            .map(|pack| {
                PackRow {
                    pack: pack.clone(),
                    busy,
                    pending_remove,
                }
                .into_element()
            })
            .collect();

        let confirm = pending_remove.read().clone().map(|pack| {
            let mut cancel = pending_remove;
            let mut close = pending_remove;
            let mut done = pending_remove;
            let dispatch = dispatch.clone();
            let name = pack.name.clone();
            dialog(
                tf("oneclient.cluster.imported_modpacks.remove.title", &[&name]),
                t("oneclient.cluster.imported_modpacks.remove.body").to_string(),
                None,
                move || close.set(None),
                [
                    Button::new()
                        .secondary()
                        .on_press(move |_| cancel.set(None))
                        .text(t("oneclient.common.cancel"))
                        .into_element(),
                    Button::new()
                        .danger()
                        .on_press(move |_| {
                            done.set(None);
                            dispatch.remove_imported_modpack(
                                cluster_id,
                                pack.bundle_name.clone(),
                                pack.name.clone(),
                            );
                        })
                        .child(Icon::new(IconType::Trash01).size(14.))
                        .text(t("oneclient.cluster.imported_modpacks.remove.confirm"))
                        .into_element(),
                ],
            )
        });

        rect()
            .vertical()
            .width(Size::fill())
            .spacing(4.)
            .child(section_header(t(
                "oneclient.cluster.imported_modpacks.section",
            )))
            .child(settings_row(
                IconType::FilePlus02,
                t("oneclient.cluster.imported_modpacks.add.title"),
                t("oneclient.cluster.imported_modpacks.add.description"),
                add_buttons,
            ))
            .children(rows)
            .maybe_child(confirm)
    }
}

#[derive(PartialEq)]
struct PackRow {
    pack: ImportedModpack,
    busy: bool,
    pending_remove: State<Option<ImportedModpack>>,
}

impl Component for PackRow {
    fn render(&self) -> impl IntoElement {
        let icon_query = use_cached_image(self.pack.icon_url.clone(), 256);
        let icon = remote_icon(self.pack.icon_url.as_deref(), &icon_query, PACK_ICON);
        let description = match &self.pack.provider {
            Some(provider) if !self.pack.version.trim().is_empty() => tf(
                "oneclient.cluster.imported_modpacks.source.provider_version",
                &[&self.pack.version, &provider],
            ),
            Some(provider) => tf(
                "oneclient.cluster.imported_modpacks.source.provider",
                &[&provider],
            ),
            None if !self.pack.version.trim().is_empty() => tf(
                "oneclient.cluster.imported_modpacks.source.file_version",
                &[&self.pack.version],
            ),
            None => t("oneclient.cluster.imported_modpacks.source.file").to_string(),
        };

        let mut pending = self.pending_remove;
        let pack = self.pack.clone();
        let busy = self.busy;

        rect()
            .horizontal()
            .width(Size::fill())
            .content(Content::Flex)
            .cross_align(Alignment::Center)
            .spacing(16.)
            .padding(Gaps::new_symmetric(12., 16.))
            .corner_radius(rounded(12.))
            .background(colors::page_elevated())
            .child(icon)
            .child(
                rect()
                    .vertical()
                    .width(Size::flex(1.0))
                    .spacing(2.)
                    .child(
                        label()
                            .text(self.pack.name.clone())
                            .font_size(text_size(16.))
                            .font_weight(FontWeight::MEDIUM)
                            .max_lines(1)
                            .color(colors::fg_primary()),
                    )
                    .child(
                        label()
                            .text(description)
                            .font_size(text_size(12.))
                            .color(colors::fg_secondary()),
                    ),
            )
            .child(
                Button::new()
                    .small()
                    .secondary()
                    .enabled(!busy)
                    .maybe(!busy, |el| {
                        el.on_press(move |_| pending.set(Some(pack.clone())))
                    })
                    .child(Icon::new(IconType::Trash01).size(14.))
                    .text(t("oneclient.cluster.imported_modpacks.remove.confirm")),
            )
    }
}
