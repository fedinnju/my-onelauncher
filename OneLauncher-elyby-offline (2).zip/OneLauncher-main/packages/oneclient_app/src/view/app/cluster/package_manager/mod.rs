use std::collections::{HashMap, HashSet};

use freya::prelude::*;
use oneclient_common::search::{MatchScore, SearchQuery};
use oneclient_content::packages::{CachedPackageMeta, ContentType, ProviderId};
use oneclient_core::clusters::Cluster;
use oneclient_core::{
    BundleFileKind, BundleFileType, BundleWithUpdateStatus, FileUpdateStatus, LinkedArtifactInfo,
};
use oneclient_db::models::OverrideType;

use crate::components::{
    CARD_GRID_H, CardLayout, GRID_GAP, GRID_MIN_W, PackageEntry, bundled_delete_action,
    disable_request, guard_disable, run_guarded, toggle_action,
};
use crate::hooks::{
    ClusterAction, EssentialGuardKind, disable_warnings, package_meta_batch, use_cluster_mutation,
    use_disable_confirm, use_disable_warnings, use_dispatch, use_essential_guard,
    use_game_snapshot, use_package_meta_batch, use_selection, use_view_state,
};
use crate::i18n::{t, tf};

use super::folder_list::confirm_dialog;

mod views;
use views::{
    AdvancedSection, Bulk, ContentBox, ContentKind, EnabledFilter, HiddenFilter, SortMode,
    toolbar_bar,
};
pub(super) use views::{copy_list_button, empty_hint, empty_shell, empty_title, notice_bar};

const CARD_H: f32 = 84.;
pub(super) const CARD_SPACING: f32 = 8.;
pub(super) const GRID_MAX_COLS: usize = 5;

pub type PackageMetaMap = HashMap<(ProviderId, String), CachedPackageMeta>;

fn provider_project_ids(
    content: &[LinkedArtifactInfo],
    bundles: &[BundleWithUpdateStatus],
    content_type: ContentType,
    provider: ProviderId,
) -> Vec<String> {
    let mut ids = Vec::new();
    for bundle in bundles {
        for (file, _status) in &bundle.files {
            if file.content_type() != content_type {
                continue;
            }
            if let BundleFileKind::Managed {
                project_id,
                provider: file_provider,
                ..
            } = &file.kind
                && *file_provider == provider
            {
                ids.push(project_id.clone());
            }
        }
    }
    for info in content {
        if info.content_type != content_type || info.provider != Some(provider) {
            continue;
        }
        if let Some(project_id) = &info.project_id {
            ids.push(project_id.clone());
        }
    }
    ids
}

fn local_project_ids(
    content: &[LinkedArtifactInfo],
    bundles: &[BundleWithUpdateStatus],
    content_type: ContentType,
) -> Vec<String> {
    let bundled = bundles
        .iter()
        .flat_map(|bundle| &bundle.files)
        .filter(|(file, _status)| file.content_type() == content_type)
        .filter(|(file, _status)| matches!(file.kind, BundleFileKind::External { .. }))
        .map(|(file, _status)| file.kind.metadata_id());
    content
        .iter()
        .filter(|info| info.content_type == content_type && info.provider.is_none())
        .map(|info| info.hash.clone())
        .chain(bundled)
        .collect()
}

pub fn use_content_meta(
    content: &[LinkedArtifactInfo],
    bundles: &[BundleWithUpdateStatus],
    content_type: ContentType,
) -> PackageMetaMap {
    let mut out = PackageMetaMap::new();
    for provider in ProviderId::REMOTE_PROVIDERS.iter().copied() {
        let ids = provider_project_ids(content, bundles, content_type, provider);
        let query = use_package_meta_batch(provider, ids);
        for (project_id, meta) in package_meta_batch(&query) {
            out.insert((provider, project_id), meta);
        }
    }

    let local = use_package_meta_batch(
        ProviderId::Local,
        local_project_ids(content, bundles, content_type),
    );
    for (hash, meta) in package_meta_batch(&local) {
        out.insert((ProviderId::Local, hash), meta);
    }

    out
}

/// `stale` is the artifact hashes with a newer version bundle rows never carry it so the two update flows cannot both claim a package
/// Hidden bundle files get flagged rows [`HiddenFilter`] decides whether they show
pub fn bundle_packages(
    content: Vec<LinkedArtifactInfo>,
    bundles: &[BundleWithUpdateStatus],
    overrides: &HashMap<(String, String), String>,
    meta: &PackageMetaMap,
    stale: &HashSet<String>,
    content_type: ContentType,
) -> Vec<PackageEntry> {
    let mut by_project: HashMap<&str, &LinkedArtifactInfo> = HashMap::new();
    let mut by_hash: HashMap<&str, &LinkedArtifactInfo> = HashMap::new();
    for info in &content {
        if let Some(pid) = &info.project_id {
            by_project.insert(pid.as_str(), info);
        }
        by_hash.insert(info.hash.as_str(), info);
    }

    // Hidden is per-bundle so one bundle carrying a mod as a private dependency must not suppress a bundle that offers it openly
    let mut shown_elsewhere: HashSet<String> = HashSet::new();
    let mut normal_elsewhere: HashSet<String> = HashSet::new();
    for bundle in bundles {
        for (file, _status) in &bundle.files {
            if !file.hidden && file.content_type() == content_type {
                shown_elsewhere.insert(file.kind.package_id());
                if file.file_type == BundleFileType::Normal {
                    normal_elsewhere.insert(file.kind.package_id());
                }
            }
        }
    }

    let pids_with = |wanted: OverrideType| -> HashSet<&str> {
        overrides
            .iter()
            .filter(|(_, ty)| OverrideType::parse(ty) == Some(wanted))
            .map(|((_, pid), _)| pid.as_str())
            .collect()
    };
    let disabled = pids_with(OverrideType::Disabled);
    let removed: HashSet<&str> = pids_with(OverrideType::Removed)
        .into_iter()
        .filter(|pid| !disabled.contains(pid))
        .collect();

    let mut ordered: Vec<&BundleWithUpdateStatus> = bundles.iter().collect();
    ordered.sort_by_key(|b| !b.opted_in_types.contains(&content_type));

    let mut rows = Vec::new();
    let mut seen: HashSet<String> = HashSet::new();

    for bundle in ordered {
        let bundle_name = &bundle.archive.manifest.name;
        let category = bundle.archive.manifest.category.clone();
        for (file, status) in &bundle.files {
            if file.content_type() != content_type {
                continue;
            }
            let pid = file.kind.package_id();
            // Let the bundle that lists it openly own the row whatever the iteration order
            if file.hidden && shown_elsewhere.contains(&pid) {
                continue;
            }
            if !seen.insert(pid.clone()) {
                continue;
            }

            let provider = file.kind.metadata_provider();
            let installed_info = match &file.kind {
                BundleFileKind::Managed { .. } => by_project
                    .get(pid.as_str())
                    .or_else(|| by_hash.get(pid.as_str())),
                BundleFileKind::External { file: ext, .. } => {
                    let hash = match status {
                        FileUpdateStatus::UpdateAvailable {
                            installed_version_id,
                            ..
                        } => installed_version_id,
                        _ => &ext.sha1,
                    };
                    seen.insert(hash.clone());
                    by_hash.get(hash.as_str())
                }
            }
            .copied();
            let ov = overrides
                .get(&(bundle_name.clone(), pid.clone()))
                .map(String::as_str);
            let enabled = match installed_info {
                Some(info) => info.enabled,
                None => {
                    let ov = ov.and_then(OverrideType::parse);
                    ov == Some(OverrideType::Enabled)
                        || (bundle.opted_in_types.contains(&content_type)
                            && oneclient_core::effective_enabled(file, ov))
                }
            };

            let advanced = content_type == ContentType::Mod
                && file.file_type == BundleFileType::Advanced
                && !normal_elsewhere.contains(&pid);

            let categories = if category.is_empty() {
                Vec::new()
            } else {
                vec![category.clone()]
            };

            let opted_in =
                installed_info.is_some() || bundle.opted_in_types.contains(&content_type);
            let mut row = make_row(
                pid,
                Some(bundle_name.clone()),
                provider,
                file.size,
                categories,
                enabled,
                file.enabled,
                file.is_github_hosted(),
                installed_info,
                meta.get(&(provider, file.kind.metadata_id())),
                file.display_name(),
                false,
                // Flagged rather than dropped `HiddenFilter` filters on the row and the seen id stops the loose-content pass resurrecting it as a local file
                file.hidden,
                opted_in,
            );
            row.advanced = advanced;
            row.deleted = installed_info.is_some_and(|info| !info.enabled)
                && removed.contains(row.package_id.as_str());
            row.github_url = file.github_repo_url();
            rows.push(row);
        }
    }

    for info in &content {
        let in_bundle = info.project_id.as_deref().is_some_and(|p| seen.contains(p))
            || seen.contains(&info.hash);
        if in_bundle {
            continue;
        }
        let provider = info.provider.unwrap_or(ProviderId::Local);
        let pid = info.project_id.clone().unwrap_or_else(|| info.hash.clone());
        let outdated = stale.contains(&info.hash);
        let row_meta = meta.get(&(provider, pid.clone()));
        rows.push(make_row(
            pid,
            None,
            provider,
            info.size_bytes.unwrap_or(0),
            Vec::new(),
            info.enabled,
            true,
            false,
            Some(info),
            row_meta,
            info.display_name
                .clone()
                .unwrap_or_else(|| info.file_name.clone()),
            outdated,
            false,
            true,
        ));
    }

    rows
}

pub fn folder_pack_rows(
    packs: Vec<oneclient_core::game::FolderPack>,
) -> impl Iterator<Item = PackageEntry> {
    let enabled: std::collections::HashSet<String> = packs
        .iter()
        .filter(|pack| pack.enabled)
        .map(|pack| pack.name.clone())
        .collect();
    packs.into_iter().map(move |pack| {
        let id = if !pack.enabled && enabled.contains(&pack.name) {
            format!("folder:{}/off", pack.name)
        } else {
            format!("folder:{}", pack.name)
        };
        let mut row = make_row(
            id,
            None,
            ProviderId::Local,
            0,
            Vec::new(),
            pack.enabled,
            false,
            false,
            None,
            None,
            pack.name,
            false,
            false,
            true,
        );
        row.installed = true;
        row.version = Some(t("oneclient.cluster.package_manager.folder_pack").to_string());
        row.description = pack.description.unwrap_or_default();
        row
    })
}

#[allow(clippy::too_many_arguments)]
fn make_row(
    package_id: String,
    bundle_name: Option<String>,
    provider: ProviderId,
    size: u64,
    categories: Vec<String>,
    enabled: bool,
    manifest_default: bool,
    github_hosted: bool,
    installed_info: Option<&LinkedArtifactInfo>,
    m: Option<&CachedPackageMeta>,
    fallback_name: String,
    update_available: bool,
    hidden: bool,
    opted_in: bool,
) -> PackageEntry {
    let name = m
        .map(|p| p.name.clone())
        .filter(|s| !s.is_empty())
        .unwrap_or_else(|| fallback_name.clone());
    let file_name = installed_info
        .map(|i| i.file_name.clone())
        .unwrap_or(fallback_name);
    let author = m
        .map(|p| p.author.clone())
        .filter(|s| !s.is_empty())
        .unwrap_or_default();
    let version = installed_info.and_then(|i| i.display_version.clone());
    let description = m
        .map(|p| p.summary.clone())
        .filter(|s| !s.is_empty())
        .unwrap_or_default();

    PackageEntry {
        essential: crate::essential::lookup(provider, &package_id),
        package_id,
        bundle_name,
        provider,
        github_hosted,
        github_url: None,
        name,
        file_name,
        author,
        version,
        description,
        icon_url: m.and_then(|p| p.icon_url.clone()),
        size,
        categories,
        enabled,
        manifest_default,
        installed: installed_info.is_some(),
        hash: installed_info.map(|i| i.hash.clone()),
        update_available,
        hidden,
        opted_in,
        copy_status: None,
        copies: Vec::new(),
        advanced: false,
        deleted: false,
        seen_status: installed_info.map(|i| i.seen_status).unwrap_or_default(),
        bisect_role: None,
        locked: false,
        modpack: None,
        added_at: installed_info.and_then(|i| i.added_at.clone()),
        published_at: installed_info.and_then(|i| i.published_at.clone()),
    }
}

pub(super) fn noun_one(content_type: ContentType) -> &'static str {
    match content_type {
        ContentType::Shader => t("oneclient.cluster.package_manager.noun.shader.one"),
        ContentType::ResourcePack => t("oneclient.cluster.package_manager.noun.resource_pack.one"),
        _ => t("oneclient.cluster.package_manager.noun.mod.one"),
    }
}

fn package_url(item: &PackageEntry, content_type: ContentType) -> Option<String> {
    match item.provider {
        ProviderId::Modrinth => Some(format!(
            "https://modrinth.com/{}/{}",
            content_type.modrinth_type(),
            item.package_id
        )),
        ProviderId::CurseForge => Some(format!(
            "https://www.curseforge.com/projects/{}",
            item.package_id
        )),
        ProviderId::Local => None,
    }
}

fn export_line(item: &PackageEntry, content_type: ContentType) -> String {
    let version = item
        .version
        .clone()
        .filter(|version| !version.is_empty())
        .map(|version| {
            if item.in_bundle() {
                tf(
                    "oneclient.cluster.package_manager.export.bundled",
                    &[&version],
                )
            } else {
                version
            }
        })
        .or_else(|| item.bundle_name.clone())
        .filter(|version| !version.is_empty());

    let mut segments = vec![item.name.clone()];
    segments.extend(package_url(item, content_type).or_else(|| item.github_url.clone()));
    segments.extend(version);
    if !item.author.is_empty() {
        segments.push(tf(
            "oneclient.cluster.package_manager.export.author",
            &[&item.author],
        ));
    }
    segments.push(
        if item.enabled {
            t("oneclient.cluster.package_manager.export.enabled")
        } else {
            t("oneclient.cluster.package_manager.export.disabled")
        }
        .to_string(),
    );

    format!("- {}", segments.join(" | "))
}

fn export_rows(items: &[PackageEntry], hidden: HiddenFilter) -> Vec<PackageEntry> {
    items
        .iter()
        .filter(|p| hidden.keep(p) && Tab::All.matches(p))
        .cloned()
        .collect()
}

fn list_header(cluster: &Cluster) -> String {
    let loader = if cluster.mc_loader.is_modded() {
        cluster.mc_loader.to_string()
    } else {
        "Vanilla".to_string()
    };
    let loader_version = cluster
        .mc_loader_version
        .as_deref()
        .map_or_else(String::new, |version| format!(" {version}"));
    format!("Minecraft {} · {loader}{loader_version}", cluster.mc_version)
}

fn package_list_text(
    rows: &[PackageEntry],
    content_type: ContentType,
    header: Option<&str>,
) -> String {
    let mut rows: Vec<&PackageEntry> = rows.iter().collect();
    rows.sort_by_key(|p| p.name.to_lowercase());
    let list = rows
        .iter()
        .map(|row| export_line(row, content_type))
        .collect::<Vec<_>>()
        .join("\n");
    match header {
        Some(header) => format!("{header}\n\n{list}"),
        None => list,
    }
}

#[derive(Clone)]
pub(super) enum Tab {
    All,
    Category(String),
    Browser,
    Local,
    Deleted,
}

impl Tab {
    pub(super) fn label(&self) -> String {
        match self {
            Tab::All => t("oneclient.cluster.package_manager.tab.all").to_string(),
            Tab::Category(c) => c.clone(),
            Tab::Browser => t("oneclient.cluster.package_manager.tab.browser").to_string(),
            Tab::Local => t("oneclient.cluster.package_manager.tab.local").to_string(),
            Tab::Deleted => t("oneclient.cluster.package_manager.tab.deleted").to_string(),
        }
    }

    pub(super) fn matches(&self, p: &PackageEntry) -> bool {
        if p.deleted {
            return matches!(self, Tab::Deleted);
        }
        match self {
            Tab::All => p.opted_in,
            Tab::Category(c) => p.categories.iter().any(|pc| pc == c),
            Tab::Browser => (p.is_remote() || p.github_hosted) && !p.in_bundle(),
            Tab::Local => !p.is_remote() && !p.github_hosted,
            Tab::Deleted => false,
        }
    }
}

fn query_score(p: &PackageEntry, query: &SearchQuery) -> Option<MatchScore> {
    query.best_score([p.name.as_str(), p.file_name.as_str()])
}

/// Search is scoped to the active tab a package must match the tab *and* the query
/// `Tab::All` searches the whole cluster
fn visible_packages(
    items: &[PackageEntry],
    tab: Option<&Tab>,
    query: &SearchQuery,
    show: EnabledFilter,
    hidden: HiddenFilter,
) -> Vec<PackageEntry> {
    items
        .iter()
        .filter(|p| tab.is_none_or(|t| t.matches(p)) && query_score(p, query).is_some())
        .filter(|p| show.keep(p) && hidden.keep(p))
        .cloned()
        .collect()
}

/// Stable so the toolbar's sort survives as the tie-break between equally good matches
fn rank_by_query(rows: &mut [PackageEntry], query: &SearchQuery) {
    rows.sort_by_key(|p| std::cmp::Reverse(query_score(p, query)));
}

pub fn bundle_categories(bundles: &[BundleWithUpdateStatus]) -> Vec<String> {
    let mut cats: Vec<String> = Vec::new();
    for bundle in bundles {
        let category = &bundle.archive.manifest.category;
        if !category.is_empty() && !cats.contains(category) {
            cats.push(category.clone());
        }
    }
    cats
}

/// `hidden` applies here too so a category of only hidden dependencies offers no tab
fn build_tabs(categories: &[String], items: &[PackageEntry], hidden: HiddenFilter) -> Vec<Tab> {
    let mut cats: Vec<String> = categories.to_vec();
    for item in items.iter().filter(|p| hidden.keep(p)) {
        for c in &item.categories {
            if !cats.contains(c) {
                cats.push(c.clone());
            }
        }
    }

    // Category tabs are hidden when empty All + Online + Local are always shown
    let mut tabs: Vec<Tab> = vec![Tab::All];
    tabs.extend(
        cats.into_iter()
            .map(Tab::Category)
            .filter(|t| items.iter().any(|p| hidden.keep(p) && t.matches(p))),
    );

    tabs.push(Tab::Browser);
    tabs.push(Tab::Local);
    if items.iter().any(|p| hidden.keep(p) && p.deleted) {
        tabs.push(Tab::Deleted);
    }
    tabs
}

/// Records the dependency lists of anything installed before the launcher kept
/// them, once per visit to the list.
///
/// Disabling a package consults them, and would otherwise pay for the whole
/// cluster's backfill while the user waits on a toggle. Failures are silent:
/// the disable path re-runs this and can proceed without it.
fn warm_dependencies(cluster_id: i64) {
    use_hook(move || {
        spawn_in_window(async move {
            let Ok(state) = crate::launcher::state() else {
                return;
            };

            if let Err(err) =
                oneclient_core::ensure_cluster_dependencies(cluster_id, &state.services.content())
                    .await
            {
                tracing::debug!(%err, "could not record the cluster's package dependencies");
            }
        });
    });
}

#[derive(PartialEq)]
pub struct PackageManager {
    title: &'static str,
    noun_plural: &'static str,
    package_type: &'static str,
    content_type: ContentType,
    cluster_id: i64,
    items: Vec<PackageEntry>,
    categories: Vec<String>,
    bisecting: bool,
}

impl PackageManager {
    pub fn new(
        title: &'static str,
        noun_plural: &'static str,
        package_type: &'static str,
        content_type: ContentType,
        cluster_id: i64,
        items: Vec<PackageEntry>,
        categories: Vec<String>,
    ) -> Self {
        Self {
            title,
            noun_plural,
            package_type,
            content_type,
            cluster_id,
            items,
            categories,
            bisecting: false,
        }
    }

    pub fn bisecting(mut self, active: bool) -> Self {
        self.bisecting = active;
        self
    }
}

impl Component for PackageManager {
    fn render(&self) -> impl IntoElement {
        let items = self.items.clone();
        let noun_plural = self.noun_plural;
        let package_type = self.package_type;
        let cluster_id = self.cluster_id;
        let content_type = self.content_type;

        warm_dependencies(cluster_id);

        // Cleared once on mount so the rows already rendered keep their badges for this visit
        use_hook(|| {
            spawn_in_window(async move {
                let Ok(state) = crate::launcher::state() else {
                    return;
                };
                match oneclient_content::packages::PackageStore::retire_seen_badges(
                    &state.services.content(),
                )
                .await
                {
                    Ok(cleared) if cleared > 0 => {
                        tracing::debug!(
                            cleared,
                            "retired package badges after the list was viewed"
                        );
                    }
                    Ok(_) => {}
                    Err(err) => tracing::warn!(%err, "failed to retire package badges"),
                }
            });
        });

        let session_live = use_game_snapshot().is_active(cluster_id);
        let cluster = crate::hooks::use_cluster(cluster_id);
        let shares_content = cluster
            .as_ref()
            .map(|cluster| cluster.shares_content(content_type));
        let active = use_state(|| 0usize);

        let search = use_state(String::new);
        let advanced_open = use_state(|| false);
        let toolbar_width = use_state(|| 0f32);
        let selection = use_selection::<String>();
        let mutation = use_cluster_mutation();
        let dispatch = use_dispatch();
        let guard = use_essential_guard();
        let warnings_query = use_disable_warnings();
        let pending_disable = use_disable_confirm();
        let mut confirm_delete = use_state(|| false);
        let view = use_view_state("cluster.packages");
        let sort = view.sort;
        let layout = view.layout;
        let query = SearchQuery::new(&search.read());

        let searching = !query.is_empty();
        let filters = view.filters;
        use_side_effect_with_deps(&searching, move |&searching| {
            let mut filters = filters;
            let next = if searching {
                HiddenFilter::Show
            } else {
                HiddenFilter::Hide
            };
            let current = filters
                .peek()
                .get(HiddenFilter::STORAGE_KEY)
                .and_then(|key| HiddenFilter::from_key(key));
            if current != Some(next) {
                filters
                    .write()
                    .insert(HiddenFilter::STORAGE_KEY.into(), next.key().into());
            }
        });
        let sort_mode = sort
            .read()
            .as_deref()
            .and_then(SortMode::from_key)
            .unwrap_or(SortMode::NameAsc);

        let show = filters
            .read()
            .get(EnabledFilter::STORAGE_KEY)
            .and_then(|key| EnabledFilter::from_key(key))
            .unwrap_or(EnabledFilter::All);
        let hidden = filters
            .read()
            .get(HiddenFilter::STORAGE_KEY)
            .and_then(|key| HiddenFilter::from_key(key))
            .unwrap_or(HiddenFilter::Hide);
        let card_layout = CardLayout::from(*layout.read());

        let bisecting = self.bisecting;
        let disabled_essentials: Vec<&'static str> = items
            .iter()
            .filter(|_| !bisecting)
            .filter(|package| !package.enabled)
            .filter_map(|package| package.essential.map(|essential| essential.name))
            .collect();

        let tabs = build_tabs(&self.categories, &items, hidden);
        let active_idx = (*active.read()).min(tabs.len().saturating_sub(1));
        let tab_filter = tabs.get(active_idx);

        let mut filtered = visible_packages(&items, tab_filter, &query, show, hidden);
        sort_mode.sort(&mut filtered);
        // Relevance has to win while searching a fuzzy typo match would otherwise outrank the exact one
        if !query.is_empty() {
            rank_by_query(&mut filtered, &query);
        }

        // Coming up empty during a search is about the query not the tab so it gets its own empty state
        let content_kind = if filtered.is_empty() && !query.is_empty() {
            ContentKind::NoMatches {
                scope: match tab_filter {
                    Some(Tab::All) | None => None,
                    Some(tab) => Some(tab.label()),
                },
            }
        } else {
            match tab_filter {
                Some(Tab::Browser) => ContentKind::Browser,
                Some(Tab::Local) => ContentKind::Local,
                _ => ContentKind::Other,
            }
        };

        let mut notices = Vec::new();
        if content_type.is_global()
            && let Some(shares_content) = shares_content
        {
            notices.push(if shares_content {
                views::global_notice(noun_plural)
            } else {
                views::instance_only_notice(noun_plural)
            });
        }
        if session_live {
            notices.push(views::running_notice(noun_plural, content_type));
        }
        if !disabled_essentials.is_empty() {
            notices.push(views::essential_notice(&disabled_essentials));
        }
        if bisecting {
            notices.push(views::bisect_notice(noun_plural));
        }

        let (advanced, filtered): (Vec<_>, Vec<_>) = filtered.into_iter().partition(|p| p.advanced);

        let section = AdvancedSection {
            open: advanced_open,
            forced: !query.is_empty(),
        };
        let shown: Vec<&PackageEntry> = filtered
            .iter()
            .chain(advanced.iter().filter(|_| section.expanded()))
            .collect();
        let order: Vec<String> = shown.iter().map(|p| p.package_id.clone()).collect();
        let chosen: Vec<PackageEntry> = shown
            .into_iter()
            .filter(|p| selection.is_selected(&p.package_id))
            .cloned()
            .collect();
        let deletable: Vec<String> = chosen
            .iter()
            .filter(|p| p.installed && !p.in_bundle())
            .filter_map(|p| p.hash.clone())
            .collect();
        let folder_deletable: Vec<(String, bool)> = chosen
            .iter()
            .filter_map(|p| p.folder_pack())
            .map(|(name, enabled)| (name.to_string(), enabled))
            .collect();
        let bundled_deletable: Vec<PackageEntry> = chosen
            .iter()
            .filter(|_| content_type == ContentType::Mod)
            .filter(|p| p.installed && p.in_bundle() && !p.deleted)
            .cloned()
            .collect();

        let set_enabled: EventHandler<bool> = {
            let chosen = chosen.clone();
            let dispatch = dispatch.clone();
            let warnings = disable_warnings(&warnings_query);
            (move |enabled: bool| {
                if bisecting {
                    return;
                }
                let targets: Vec<&PackageEntry> =
                    chosen.iter().filter(|p| p.enabled != enabled).collect();
                let actions: Vec<ClusterAction> = targets
                    .iter()
                    .filter_map(|p| toggle_action(p, cluster_id, enabled))
                    .collect();
                if actions.is_empty() {
                    return;
                }
                if enabled {
                    mutation.mutate(ClusterAction::Batch(actions));
                    return;
                }
                let (folders, targets): (Vec<&PackageEntry>, Vec<&PackageEntry>) = targets
                    .into_iter()
                    .filter(|p| toggle_action(p, cluster_id, false).is_some())
                    .partition(|p| p.folder_pack().is_some());
                if !folders.is_empty() {
                    mutation.mutate(ClusterAction::Batch(
                        folders
                            .iter()
                            .filter_map(|p| toggle_action(p, cluster_id, false))
                            .collect(),
                    ));
                }
                let name = match targets.as_slice() {
                    [] => return,
                    [only] => only.name.clone(),
                    _ => tf(
                        "oneclient.cluster.package_manager.count",
                        &[&targets.len(), &noun_plural],
                    ),
                };
                guard_disable(
                    disable_request(&targets, cluster_id, name),
                    &targets,
                    warnings.clone(),
                    guard,
                    pending_disable,
                    dispatch.clone(),
                );
            })
            .into()
        };

        let bulk = Bulk {
            selection,
            order,
            count: chosen.len(),
            deletable: deletable.len() + folder_deletable.len() + bundled_deletable.len(),
            set_enabled,
            delete: (move |()| confirm_delete.set(true)).into(),
        };

        let delete_dialog = confirm_delete.read().then(|| {
            let count = deletable.len() + folder_deletable.len() + bundled_deletable.len();
            let noun = if count == 1 {
                noun_one(content_type)
            } else {
                noun_plural
            };
            let shared = shares_content == Some(true);
            let body = match (deletable.is_empty(), bundled_deletable.is_empty(), shared) {
                (_, true, false) => t("oneclient.cluster.package_manager.delete.body").to_string(),
                (_, true, true) => tf(
                    "oneclient.cluster.package_manager.delete.body.shared",
                    &[&noun_plural],
                ),
                (true, false, _) => tf(
                    "oneclient.cluster.package_manager.delete.body.bundled",
                    &[&noun_plural],
                ),
                (false, false, false) => tf(
                    "oneclient.cluster.package_manager.delete.body.mixed",
                    &[&noun_plural],
                ),
                (false, false, true) => tf(
                    "oneclient.cluster.package_manager.delete.body.mixed_shared",
                    &[&noun_plural, &noun_plural],
                ),
            };
            let warnings = disable_warnings(&warnings_query);
            confirm_dialog(
                tf(
                    "oneclient.cluster.package_manager.delete.title",
                    &[&count, &noun],
                ),
                body,
                move || confirm_delete.set(false),
                move || {
                    let action = ClusterAction::Batch(
                        deletable
                            .iter()
                            .map(|hash| ClusterAction::RemoveArtifact {
                                cluster_id,
                                hash: hash.clone(),
                            })
                            .chain(folder_deletable.iter().map(|(name, enabled)| {
                                ClusterAction::RemoveFolderPack {
                                    cluster_id,
                                    name: name.clone(),
                                    enabled: *enabled,
                                }
                            }))
                            .chain(
                                bundled_deletable
                                    .iter()
                                    .filter_map(|p| bundled_delete_action(p, cluster_id)),
                            )
                            .collect(),
                    );
                    let targets: Vec<&PackageEntry> = bundled_deletable.iter().collect();
                    run_guarded(
                        action,
                        &targets,
                        match (deletable.as_slice(), targets.as_slice()) {
                            ([], [only]) => only.name.clone(),
                            _ => tf("oneclient.cluster.package_manager.count", &[&count, &noun]),
                        },
                        EssentialGuardKind::Remove,
                        warnings.clone(),
                        mutation,
                        guard,
                    );
                    selection.exit();
                    confirm_delete.set(false);
                },
            )
        });

        selection
            .track_modifiers(rect())
            .vertical()
            .width(Size::fill())
            .height(Size::fill())
            .child(toolbar_bar(
                &tabs,
                active_idx,
                active,
                search,
                sort,
                sort_mode,
                filters,
                show,
                hidden,
                layout,
                cluster_id,
                package_type,
                content_type,
                dispatch,
                toolbar_width,
                &bulk,
                noun_plural,
                export_rows(&items, hidden),
                cluster.as_ref().map(list_header),
            ))
            .child(
                ContentBox::new(
                    filtered,
                    advanced,
                    section,
                    noun_plural,
                    package_type,
                    content_type,
                    cluster_id,
                    content_kind,
                    card_layout,
                    bulk,
                )
                .notices(notices),
            )
            .maybe_child(delete_dialog)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::view::onboarding::test_support::{archive, file};
    use oneclient_core::{BundleFile, FileUpdateStatus};

    fn bundle(category: &str, opted_in: bool, files: Vec<BundleFile>) -> BundleWithUpdateStatus {
        BundleWithUpdateStatus {
            files: files
                .iter()
                .cloned()
                .map(|f| (f, FileUpdateStatus::NotInstalled))
                .collect(),
            archive: archive(category, true, files),
            has_updates: false,
            opted_in_types: if opted_in {
                [ContentType::Mod].into()
            } else {
                HashSet::new()
            },
        }
    }

    #[test]
    fn all_tab_skips_bundles_not_opted_into() {
        let bundles = [
            bundle(
                "Declined",
                false,
                vec![
                    file("only-declined", true, false),
                    file("shared", true, false),
                ],
            ),
            bundle(
                "Taken",
                true,
                vec![file("shared", true, false), file("only-taken", true, false)],
            ),
        ];
        let rows = bundle_packages(
            Vec::new(),
            &bundles,
            &HashMap::new(),
            &PackageMetaMap::new(),
            &HashSet::new(),
            ContentType::Mod,
        );
        let all: Vec<&str> = rows
            .iter()
            .filter(|p| Tab::All.matches(p))
            .map(|p| p.package_id.as_str())
            .collect();
        assert_eq!(all, ["shared", "only-taken"]);
        let shared = rows.iter().find(|p| p.package_id == "shared").unwrap();
        assert_eq!(shared.categories, ["Taken"]);
        let only_declined = rows
            .iter()
            .find(|p| p.package_id == "only-declined")
            .unwrap();
        assert!(
            !only_declined.enabled,
            "a turned down bundle's mods read off"
        );
        let only_taken = rows.iter().find(|p| p.package_id == "only-taken").unwrap();
        assert!(only_taken.enabled);
        let declined = Tab::Category("Declined".into());
        assert!(
            rows.iter()
                .any(|p| p.package_id == "only-declined" && declined.matches(p))
        );
    }

    fn installed_off(hash: &str) -> LinkedArtifactInfo {
        LinkedArtifactInfo {
            hash: hash.to_string(),
            cluster_file_name: format!("{hash}.jar"),
            enabled: false,
            content_type: ContentType::Mod,
            file_name: format!("{hash}.jar"),
            project_id: None,
            version_id: None,
            display_name: None,
            display_version: None,
            provider: None,
            published_at: None,
            added_at: None,
            seen_status: oneclient_core::SeenStatus::Seen,
            size_bytes: None,
        }
    }

    #[test]
    fn deleted_tab_holds_only_deleted_mods() {
        let taken = bundle(
            "Taken",
            true,
            vec![
                file("deleted", true, false),
                file("turned-off", false, false),
            ],
        );
        let declined = bundle("Declined", false, vec![file("turned-off", true, false)]);
        let name = |b: &BundleWithUpdateStatus| b.archive.manifest.name.clone();
        let overrides = HashMap::from([
            ((name(&taken), "deleted".to_string()), "removed".to_string()),
            (
                (name(&taken), "turned-off".to_string()),
                "disabled".to_string(),
            ),
            (
                (name(&declined), "turned-off".to_string()),
                "removed".to_string(),
            ),
        ]);
        let rows = bundle_packages(
            vec![installed_off("deleted"), installed_off("turned-off")],
            &[taken, declined],
            &overrides,
            &PackageMetaMap::new(),
            &HashSet::new(),
            ContentType::Mod,
        );
        let deleted: Vec<&str> = rows
            .iter()
            .filter(|p| Tab::Deleted.matches(p))
            .map(|p| p.package_id.as_str())
            .collect();
        assert_eq!(deleted, ["deleted"]);
        assert!(
            rows.iter()
                .any(|p| p.package_id == "turned-off" && Tab::All.matches(p))
        );
    }

    #[test]
    fn mod_list_skips_deleted_and_declined_mods() {
        let taken = bundle(
            "Taken",
            true,
            vec![file("kept", true, false), file("deleted", true, false)],
        );
        let declined = bundle("Declined", false, vec![file("only-declined", true, false)]);
        let overrides = HashMap::from([(
            (taken.archive.manifest.name.clone(), "deleted".to_string()),
            "removed".to_string(),
        )]);
        let rows = bundle_packages(
            vec![installed_off("deleted")],
            &[taken, declined],
            &overrides,
            &PackageMetaMap::new(),
            &HashSet::new(),
            ContentType::Mod,
        );
        let exported = export_rows(&rows, HiddenFilter::Hide);
        let ids: Vec<&str> = exported.iter().map(|p| p.package_id.as_str()).collect();
        assert_eq!(ids, ["kept"]);
        let kept = &exported[0];
        assert_eq!(
            package_list_text(&exported, ContentType::Mod, None),
            format!(
                "- {} | {} | enabled",
                kept.name,
                kept.bundle_name.clone().unwrap()
            )
        );
    }

    #[test]
    fn date_sorts_put_newest_first_and_undated_last() {
        let row = |name: &str, added: Option<&str>, published: Option<&str>| {
            let mut row = make_row(
                name.to_string(),
                None,
                ProviderId::Local,
                0,
                Vec::new(),
                true,
                false,
                false,
                None,
                None,
                name.to_string(),
                false,
                false,
                true,
            );
            row.added_at = added.map(Into::into);
            row.published_at = published.map(Into::into);
            row
        };
        let (jan, oct) = (Some("2026-01-01T00:00:00Z"), Some("2026-10-01T00:00:00Z"));
        let mut rows = vec![
            row("undated", None, None),
            row("old", jan, oct),
            row("new", oct, jan),
        ];
        let names = |rows: &[PackageEntry]| rows.iter().map(|p| p.name.clone()).collect::<Vec<_>>();

        SortMode::AddedDesc.sort(&mut rows);
        assert_eq!(names(&rows), ["new", "old", "undated"]);
        SortMode::UpdatedDesc.sort(&mut rows);
        assert_eq!(names(&rows), ["old", "new", "undated"]);
    }
}
