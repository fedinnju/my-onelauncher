use std::collections::BTreeMap;

use super::*;

use freya::router::RouterContext;
use freya::text_edit::Clipboard;
use oneclient_content::packages::ContentType;
use oneclient_core::settings::ViewLayout;

use crate::components::{
    Button, CardLayout, ChevronToggle, ContextMenu, CopyStatus, FilterMenu, FilterOption, Icon,
    IconType, LazySection, OVERLAY_BASE_LEVEL, OverlayPopup, PackageEntry, PackageRow, ScrollArea,
    Segment, SegmentedControl, TextInput, bundled_delete_action, package_context_menu,
    parse_folder_pack_id, run_guarded, use_shared_delete,
};
use crate::hooks::{ClusterAction, Selection, use_cluster_mutation, use_dispatch};
use crate::i18n::{t, tf};
use crate::routes::Route;
use crate::theme::{colors, rounded, rounded_px, text_size};
use crate::ui::border_all_color;
use crate::{Actions, utils};

#[derive(Clone, Copy, PartialEq)]
pub(super) enum SortMode {
    NameAsc,
    NameDesc,
    SizeAsc,
    SizeDesc,
    AddedDesc,
    UpdatedDesc,
}

impl SortMode {
    const ALL: [SortMode; 6] = [
        SortMode::NameAsc,
        SortMode::NameDesc,
        SortMode::SizeAsc,
        SortMode::SizeDesc,
        SortMode::AddedDesc,
        SortMode::UpdatedDesc,
    ];

    fn key(self) -> &'static str {
        match self {
            SortMode::NameAsc => "name_asc",
            SortMode::NameDesc => "name_desc",
            SortMode::SizeAsc => "size_asc",
            SortMode::SizeDesc => "size_desc",
            SortMode::AddedDesc => "added_desc",
            SortMode::UpdatedDesc => "updated_desc",
        }
    }

    pub(super) fn from_key(key: &str) -> Option<Self> {
        SortMode::ALL.into_iter().find(|s| s.key() == key)
    }

    fn label(self) -> &'static str {
        match self {
            SortMode::NameAsc => t("oneclient.cluster.package_manager.sort.name_asc"),
            SortMode::NameDesc => t("oneclient.cluster.package_manager.sort.name_desc"),
            SortMode::SizeAsc => t("oneclient.cluster.package_manager.sort.size_asc"),
            SortMode::SizeDesc => t("oneclient.cluster.package_manager.sort.size_desc"),
            SortMode::AddedDesc => t("oneclient.cluster.package_manager.sort.added_desc"),
            SortMode::UpdatedDesc => t("oneclient.cluster.package_manager.sort.updated_desc"),
        }
    }

    pub(super) fn sort(self, rows: &mut [PackageEntry]) {
        let title = |p: &PackageEntry| p.name.to_lowercase();

        match self {
            SortMode::NameDesc => rows.sort_by_key(|p| std::cmp::Reverse(title(p))),
            SortMode::SizeAsc => rows.sort_by_key(|p| p.size),
            SortMode::SizeDesc => rows.sort_by_key(|p| std::cmp::Reverse(p.size)),
            // Undated rows (not installed, or added before dates were kept) sink to the bottom
            SortMode::AddedDesc => {
                rows.sort_by_key(|p| (std::cmp::Reverse(p.added_at.clone()), title(p)))
            }
            SortMode::UpdatedDesc => {
                rows.sort_by_key(|p| (std::cmp::Reverse(p.published_at.clone()), title(p)))
            }
            _ => rows.sort_by_key(title),
        }
    }
}

#[derive(Clone, Copy, PartialEq)]
pub(super) enum EnabledFilter {
    All,
    Enabled,
    Disabled,
}

impl EnabledFilter {
    pub(super) const STORAGE_KEY: &'static str = "show";

    const ALL: [EnabledFilter; 3] = [
        EnabledFilter::All,
        EnabledFilter::Enabled,
        EnabledFilter::Disabled,
    ];

    fn key(self) -> &'static str {
        match self {
            EnabledFilter::All => "all",
            EnabledFilter::Enabled => "enabled",
            EnabledFilter::Disabled => "disabled",
        }
    }

    pub(super) fn from_key(key: &str) -> Option<Self> {
        EnabledFilter::ALL.into_iter().find(|f| f.key() == key)
    }

    fn label(self) -> &'static str {
        match self {
            EnabledFilter::All => t("oneclient.cluster.package_manager.filter.show.all"),
            EnabledFilter::Enabled => t("oneclient.cluster.package_manager.filter.show.enabled"),
            EnabledFilter::Disabled => t("oneclient.cluster.package_manager.filter.show.disabled"),
        }
    }

    pub(super) fn keep(self, p: &PackageEntry) -> bool {
        match self {
            EnabledFilter::All => true,
            EnabledFilter::Enabled => p.enabled,
            EnabledFilter::Disabled => !p.enabled,
        }
    }
}

/// Hidden files are dependencies the bundle manages so the list leaves them out until asked
#[derive(Clone, Copy, PartialEq)]
pub(super) enum HiddenFilter {
    Hide,
    Show,
}

impl HiddenFilter {
    pub(super) const STORAGE_KEY: &'static str = "hidden";

    const ALL: [HiddenFilter; 2] = [HiddenFilter::Hide, HiddenFilter::Show];

    pub(super) fn key(self) -> &'static str {
        match self {
            HiddenFilter::Hide => "hide",
            HiddenFilter::Show => "show",
        }
    }

    pub(super) fn from_key(key: &str) -> Option<Self> {
        HiddenFilter::ALL.into_iter().find(|f| f.key() == key)
    }

    fn label(self) -> &'static str {
        match self {
            HiddenFilter::Hide => t("oneclient.cluster.package_manager.filter.hidden.hide"),
            HiddenFilter::Show => t("oneclient.cluster.package_manager.filter.hidden.show"),
        }
    }

    pub(super) fn keep(self, p: &PackageEntry) -> bool {
        match self {
            HiddenFilter::Hide => !p.hidden,
            HiddenFilter::Show => true,
        }
    }
}

#[derive(Clone, PartialEq)]
pub(super) struct Bulk {
    pub(super) selection: Selection<String>,
    pub(super) order: Vec<String>,
    pub(super) count: usize,
    pub(super) deletable: usize,
    pub(super) set_enabled: EventHandler<bool>,
    pub(super) delete: EventHandler<()>,
}

impl Bulk {
    pub(super) fn active(&self) -> bool {
        self.selection.is_active()
    }

    fn all_selected(&self) -> bool {
        self.count > 0 && self.count == self.order.len()
    }

    fn toggle_all_label(&self) -> (IconType, &'static str) {
        if self.all_selected() {
            (
                IconType::XClose,
                t("oneclient.cluster.package_manager.select.unselect_all"),
            )
        } else {
            (
                IconType::Check,
                t("oneclient.cluster.package_manager.select.select_all"),
            )
        }
    }

    fn controls(&self) -> Vec<Element> {
        let selection = self.selection;
        let order = self.order.clone();
        let enable = self.set_enabled.clone();
        let disable = self.set_enabled.clone();
        let delete = self.delete.clone();
        let (toggle_icon, toggle_label) = self.toggle_all_label();
        let button = |icon: IconType, text: String| {
            Button::new()
                .secondary()
                .height(Size::px(34.))
                .font_size(text_size(12.))
                .child(Icon::new(icon).size(15.))
                .text(text)
        };

        vec![
            label()
                .text(tf(
                    "oneclient.cluster.package_manager.select.count",
                    &[&self.count],
                ))
                .font_size(text_size(12.))
                .max_lines(1)
                .color(colors::fg_secondary())
                .into_element(),
            button(toggle_icon, toggle_label.to_string())
                .on_press(move |_| selection.toggle_all(&order))
                .into_element(),
            button(
                IconType::CheckCircle,
                t("oneclient.cluster.package_manager.select.enable").to_string(),
            )
            .enabled(self.count > 0)
            .on_press(move |_| enable.call(true))
            .into_element(),
            button(
                IconType::Minus,
                t("oneclient.cluster.package_manager.select.disable").to_string(),
            )
            .enabled(self.count > 0)
            .on_press(move |_| disable.call(false))
            .into_element(),
            button(
                IconType::Trash01,
                tf(
                    "oneclient.cluster.package_manager.select.delete",
                    &[&self.deletable],
                ),
            )
            .danger()
            .enabled(self.deletable > 0)
            .on_press(move |_| delete.call(()))
            .into_element(),
            Button::new()
                .ghost()
                .icon()
                .height(Size::px(34.))
                .tooltip(t("oneclient.cluster.package_manager.select.exit"))
                .on_press(move |_| selection.exit())
                .child(Icon::new(IconType::XClose).size(15.))
                .into_element(),
        ]
    }

    fn menu(&self, x: f32, y: f32, key: String) -> ContextMenu {
        let selection = self.selection;
        let order = self.order.clone();
        let enable = self.set_enabled.clone();
        let disable = self.set_enabled.clone();
        let delete = self.delete.clone();
        let (toggle_icon, toggle_label) = self.toggle_all_label();

        let (icon, text) = if selection.is_selected(&key) {
            (
                IconType::XClose,
                t("oneclient.cluster.package_manager.select.unselect"),
            )
        } else {
            (
                IconType::Check,
                t("oneclient.cluster.package_manager.select.select"),
            )
        };

        let mut menu = ContextMenu::new(x, y)
            .title(tf(
                "oneclient.cluster.package_manager.select.count",
                &[&self.count],
            ))
            .action(icon, text, move |()| selection.toggle(key.clone()))
            .separator();
        if self.count > 0 {
            menu = menu
                .action(
                    IconType::CheckCircle,
                    t("oneclient.cluster.package_manager.select.enable_selected"),
                    move |()| enable.call(true),
                )
                .action(
                    IconType::Minus,
                    t("oneclient.cluster.package_manager.select.disable_selected"),
                    move |()| disable.call(false),
                )
                .separator();
        }
        menu = menu.action(toggle_icon, toggle_label, move |()| {
            selection.toggle_all(&order)
        });
        if self.count > 0 && !self.all_selected() {
            menu = menu.action(
                IconType::XClose,
                t("oneclient.cluster.package_manager.select.clear"),
                move |()| selection.clear(),
            );
        }

        if self.deletable == 0 {
            return menu;
        }
        menu.separator().danger_action(
            IconType::Trash01,
            tf(
                "oneclient.cluster.package_manager.select.delete_count",
                &[&self.deletable],
            ),
            move |()| delete.call(()),
        )
    }
}

const TOOLBAR_STACK_W: f32 = 640.;
const TABS_ROW_H: f32 = 34.;

#[derive(PartialEq)]
struct FilterTabs {
    width: Size,
    chips: Vec<Element>,
}

impl Component for FilterTabs {
    fn render(&self) -> impl IntoElement {
        let mut chips_w = use_state(|| 0f32);

        ScrollArea::new()
            .horizontal(*chips_w.read())
            .show_scrollbar(false)
            .width(self.width.clone())
            .height(Size::px(TABS_ROW_H))
            .child(
                rect()
                    .horizontal()
                    .width(Size::auto())
                    .height(Size::px(TABS_ROW_H))
                    .cross_align(Alignment::Center)
                    .spacing(6.)
                    .on_sized(move |e: Event<SizedEventData>| {
                        let w = e.area.width();
                        if (*chips_w.peek() - w).abs() > 0.5 {
                            chips_w.set(w);
                        }
                    })
                    .children(self.chips.clone()),
            )
    }
}

#[allow(clippy::too_many_arguments)]
pub(super) fn toolbar_bar(
    tabs: &[Tab],
    active_idx: usize,
    active: State<usize>,
    search: State<String>,
    sort: State<Option<String>>,
    current_sort: SortMode,
    filters: State<BTreeMap<String, String>>,
    show: EnabledFilter,
    hidden: HiddenFilter,
    layout: State<ViewLayout>,
    cluster_id: i64,
    package_type: &'static str,
    content_type: ContentType,
    dispatch: Actions,
    mut toolbar_width: State<f32>,
    bulk: &Bulk,
    noun_plural: &'static str,
    export: Vec<PackageEntry>,
    header: Option<String>,
) -> impl IntoElement {
    let local_tab = matches!(tabs.get(active_idx), Some(Tab::Local));

    let chips = tabs.iter().enumerate().map(|(i, tab)| {
        let mut active = active;
        CategoryChip {
            label: tab.label(),
            selected: i == active_idx,
            on_press: (move |_| *active.write() = i).into(),
        }
        .into_element()
    });

    let mut top_corners = CornerRadius::new_all(0.);
    top_corners.fill_top(rounded_px(12.));

    let measured = *toolbar_width.read();
    let stacked = measured > 0. && measured < TOOLBAR_STACK_W;

    let filter_tabs = FilterTabs {
        width: if stacked {
            Size::fill()
        } else {
            Size::flex(1.0)
        },
        chips: chips.collect(),
    }
    .into_element();

    let mut controls: Vec<Element> = vec![
        TextInput::new(search)
            .placeholder(t("oneclient.cluster.package_manager.search"))
            .width(Size::px(180.))
            .leading(
                Icon::new(IconType::SearchMd)
                    .size(14.)
                    .color(colors::fg_secondary())
                    .into_element(),
            )
            .into_element(),
        filter_button(sort, current_sort, filters, show, hidden).into_element(),
    ];

    controls.push(
        SegmentedControl::new(layout)
            .height(34.)
            .icon_size(15.)
            .equal_width(34.)
            .segment(Segment::new(ViewLayout::List).icon(IconType::ParagraphWrap))
            .segment(Segment::new(ViewLayout::Grid).icon(IconType::DotsGrid))
            .into_element(),
    );
    if !export.is_empty() {
        controls.push(copy_list_button(
            dispatch.clone(),
            export.len(),
            noun_one(content_type),
            noun_plural,
            move || package_list_text(&export, content_type, header.as_deref()),
        ));
    }
    controls.push(
        Button::new()
            .primary()
            .height(Size::px(34.))
            .font_size(text_size(12.))
            .on_press(move |_| {
                if local_tab {
                    import_from_file(cluster_id, content_type, dispatch.clone());
                } else {
                    open_browser(cluster_id, package_type);
                }
            })
            .child(
                Icon::new(if local_tab {
                    IconType::FilePlus02
                } else {
                    IconType::Plus
                })
                .size(15.),
            )
            .text(if local_tab {
                t("oneclient.cluster.package_manager.add_from_file")
            } else {
                t("oneclient.cluster.package_manager.add_content")
            })
            .into_element(),
    );
    let controls = if bulk.active() {
        bulk.controls()
    } else {
        controls
    };

    let inner = if stacked {
        rect()
            .vertical()
            .width(Size::fill())
            .spacing(8.)
            .child(
                rect()
                    .horizontal()
                    .width(Size::fill())
                    .height(Size::px(TABS_ROW_H))
                    .cross_align(Alignment::Center)
                    .child(filter_tabs),
            )
            .child(
                rect()
                    .horizontal()
                    .width(Size::fill())
                    .cross_align(Alignment::Center)
                    .spacing(8.)
                    .content(Content::Flex)
                    .children(controls),
            )
            .into_element()
    } else {
        rect()
            .horizontal()
            .width(Size::fill())
            .cross_align(Alignment::Center)
            .spacing(8.)
            .content(Content::Flex)
            .child(filter_tabs)
            .children(controls)
            .into_element()
    };

    rect()
        .vertical()
        .width(Size::fill())
        .overflow(Overflow::Clip)
        .padding(Gaps::new_symmetric(8., 12.))
        .corner_radius(top_corners)
        .background(colors::page_elevated())
        .on_sized(move |event: Event<SizedEventData>| {
            let next = event.data().area.width();
            if (*toolbar_width.peek() - next).abs() > 0.5 {
                toolbar_width.set(next);
            }
        })
        .child(inner)
        .into_element()
}

pub(crate) fn copy_list_button(
    dispatch: Actions,
    count: usize,
    noun: &'static str,
    noun_plural: &'static str,
    text: impl Fn() -> String + 'static,
) -> Element {
    let noun = if count == 1 { noun } else { noun_plural };
    Button::new()
        .secondary()
        .icon()
        .width(Size::px(34.))
        .height(Size::px(34.))
        .on_press(move |_| {
            if let Err(err) = Clipboard::set(text()) {
                tracing::warn!("clipboard copy failed: {err:?}");
                dispatch
                    .notify(t("oneclient.cluster.package_manager.copy.failed.title"))
                    .body(tf(
                        "oneclient.cluster.package_manager.copy.failed.body",
                        &[&noun_plural],
                    ))
                    .error()
                    .send();
            } else {
                dispatch
                    .notify(t("oneclient.cluster.package_manager.copy.done.title"))
                    .body(tf(
                        "oneclient.cluster.package_manager.copy.done.body",
                        &[&count, &noun],
                    ))
                    .info()
                    .icon(IconType::ClipboardCheck)
                    .send();
            }
        })
        .child(
            Icon::new(IconType::Copy01)
                .size(16.)
                .color(colors::fg_secondary()),
        )
        .into_element()
}

#[derive(PartialEq)]
struct CategoryChip {
    label: String,
    selected: bool,
    on_press: EventHandler<Event<PressEventData>>,
}

impl Component for CategoryChip {
    fn render(&self) -> impl IntoElement {
        let mut hovered = use_state(|| false);
        let selected = self.selected;

        let a11y_id = use_a11y();
        let focus = use_focus(a11y_id);
        let focused = focus().is_focused();

        let background = if selected {
            colors::brand()
        } else if *hovered.read() {
            colors::component_bg_hover()
        } else {
            colors::component_bg()
        };

        rect()
            .horizontal()
            .height(Size::px(32.))
            .center()
            .padding(Gaps::new_symmetric(0., 12.))
            .corner_radius(rounded(8.))
            .background(background)
            .border(crate::ui::border_all_color(
                1.,
                if selected || focused {
                    colors::brand()
                } else {
                    colors::component_border()
                },
            ))
            .cursor(CursorIcon::Pointer)
            .a11y_id(a11y_id)
            .a11y_focusable(true)
            .a11y_role(AccessibilityRole::Tab)
            .on_pointer_enter(move |_| hovered.set(true))
            .on_pointer_leave(move |_| hovered.set(false))
            .on_press(self.on_press.clone())
            .child(
                label()
                    .text(self.label.clone())
                    .font_size(text_size(12.))
                    .font_weight(FontWeight::MEDIUM)
                    .max_lines(1)
                    .color(if selected {
                        colors::on_brand()
                    } else {
                        colors::fg_primary()
                    }),
            )
    }
}

pub(super) fn running_notice(noun_plural: &'static str, content_type: ContentType) -> String {
    match content_type {
        ContentType::ResourcePack => tf(
            "oneclient.cluster.package_manager.notice.running.resource_pack",
            &[&noun_plural],
        ),
        ContentType::Shader => tf(
            "oneclient.cluster.package_manager.notice.running.shader",
            &[&noun_plural],
        ),
        _ => tf(
            "oneclient.cluster.package_manager.notice.running",
            &[&noun_plural],
        ),
    }
}

pub(super) fn bisect_notice(noun_plural: &'static str) -> String {
    tf(
        "oneclient.cluster.package_manager.notice.bisect",
        &[&noun_plural],
    )
}

pub(super) fn global_notice(noun_plural: &'static str) -> String {
    tf(
        "oneclient.cluster.package_manager.notice.global",
        &[&noun_plural],
    )
}

pub(super) fn instance_only_notice(noun_plural: &'static str) -> String {
    tf(
        "oneclient.cluster.package_manager.notice.instance_only",
        &[&noun_plural],
    )
}

pub(super) fn essential_notice(names: &[&'static str]) -> String {
    match names {
        [only] => tf(
            "oneclient.cluster.package_manager.notice.essential.one",
            &[only],
        ),
        _ => tf(
            "oneclient.cluster.package_manager.notice.essential.other",
            &[&names.join(", ")],
        ),
    }
}

pub(crate) fn notice_bar(text: String) -> Element {
    rect()
        .horizontal()
        .width(Size::fill())
        .cross_align(Alignment::Center)
        .content(Content::Flex)
        .spacing(10.)
        .margin(Gaps::new(0., 0., 8., 0.))
        .padding(Gaps::new_symmetric(9., 12.))
        .corner_radius(rounded(10.))
        .background(colors::brand().with_a(30))
        .border(crate::ui::border_all_color(1., colors::brand().with_a(90)))
        .child(
            Icon::new(IconType::InfoCircle)
                .size(16.)
                .color(colors::brand()),
        )
        .child(
            label()
                .text(text)
                .font_size(text_size(12.))
                .width(Size::flex(1.0))
                .color(colors::fg_secondary()),
        )
        .into_element()
}

fn filter_button(
    mut sort: State<Option<String>>,
    current_sort: SortMode,
    mut filters: State<BTreeMap<String, String>>,
    show: EnabledFilter,
    hidden: HiddenFilter,
) -> FilterMenu {
    // Hiding hidden packages is the default so it does not count as the filters being touched
    let active = current_sort != SortMode::NameAsc
        || show != EnabledFilter::All
        || hidden != HiddenFilter::Hide;

    FilterMenu::new(active)
        .section(
            t("oneclient.cluster.package_manager.filter.sort.title"),
            SortMode::ALL.map(|mode| {
                FilterOption::new(mode.label(), mode == current_sort, move |()| {
                    sort.set(Some(mode.key().to_string()));
                })
            }),
        )
        .section(
            t("oneclient.cluster.package_manager.filter.show.title"),
            EnabledFilter::ALL.map(|filter| {
                FilterOption::new(filter.label(), filter == show, move |()| {
                    filters
                        .write()
                        .insert(EnabledFilter::STORAGE_KEY.into(), filter.key().into());
                })
            }),
        )
        .section(
            t("oneclient.cluster.package_manager.filter.hidden.title"),
            HiddenFilter::ALL.map(|filter| {
                FilterOption::new(filter.label(), filter == hidden, move |()| {
                    filters
                        .write()
                        .insert(HiddenFilter::STORAGE_KEY.into(), filter.key().into());
                })
            }),
        )
}

fn import_from_file(cluster_id: i64, content_type: ContentType, dispatch: Actions) {
    spawn(async move {
        if let Some(handles) = rfd::AsyncFileDialog::new()
            .set_title(t("oneclient.cluster.package_manager.import.picker_title"))
            .pick_files()
            .await
        {
            dispatch.import_local_files(
                cluster_id,
                handles
                    .iter()
                    .map(|handle| (handle.path().to_path_buf(), content_type))
                    .collect(),
            );
        }
    });
}

fn add_from_file_button(
    cluster_id: i64,
    content_type: ContentType,
    dispatch: Actions,
) -> impl IntoElement {
    Button::new()
        .primary()
        .on_press(move |_| import_from_file(cluster_id, content_type, dispatch.clone()))
        .child(Icon::new(IconType::FilePlus02).size(14.))
        .text(t("oneclient.cluster.package_manager.add_from_file"))
}

fn open_browser(cluster_id: i64, package_type: &'static str) {
    let _ = RouterContext::get().push(Route::Browser {
        cluster_id,
        package_type: package_type.to_string(),
        pick_cluster: false,
    });
}

fn browse_button(cluster_id: i64, package_type: &'static str) -> impl IntoElement {
    Button::new()
        .primary()
        .on_press(move |_| open_browser(cluster_id, package_type))
        .child(Icon::new(IconType::SearchMd).size(14.))
        .text(t("oneclient.cluster.package_manager.browse_content"))
}

#[derive(Clone, PartialEq)]
pub(super) enum ContentKind {
    Browser,
    Local,
    Other,
    /// `scope` names the tab that was searched when it is narrower than "All"
    NoMatches {
        scope: Option<String>,
    },
}

const SECTION_HEADER_H: f32 = 36.;

#[derive(Clone, Copy, PartialEq)]
pub(super) struct AdvancedSection {
    pub(super) open: State<bool>,
    pub(super) forced: bool,
}

impl AdvancedSection {
    pub(super) fn expanded(self) -> bool {
        self.forced || *self.open.read()
    }
}

#[derive(PartialEq)]
struct SectionHeader {
    label: &'static str,
    count: usize,
    section: AdvancedSection,
}

impl Component for SectionHeader {
    fn render(&self) -> impl IntoElement {
        let mut hovered = use_state(|| false);
        let section = self.section;
        let mut open = section.open;
        let expanded = section.expanded();
        let interactive = !section.forced;

        rect()
            .horizontal()
            .width(Size::fill())
            .height(Size::fill())
            .cross_align(Alignment::Center)
            .spacing(8.)
            .padding(Gaps::new_symmetric(0., 12.))
            .corner_radius(rounded(10.))
            .background(if interactive && *hovered.read() {
                colors::ghost_overlay_hover()
            } else {
                Color::TRANSPARENT
            })
            .maybe(interactive, |el| {
                el.cursor(CursorIcon::Pointer)
                    .on_pointer_enter(move |_| hovered.set(true))
                    .on_pointer_leave(move |_| hovered.set(false))
                    .on_press(move |_| open.toggle())
            })
            .child(ChevronToggle { expanded })
            .child(
                label()
                    .text(self.label)
                    .font_size(text_size(13.))
                    .font_weight(FontWeight::SEMI_BOLD)
                    .color(colors::fg_primary()),
            )
            .child(
                label()
                    .text(self.count.to_string())
                    .font_size(text_size(12.))
                    .color(colors::fg_secondary()),
            )
    }
}

#[derive(PartialEq)]
pub(super) struct ContentBox {
    items: Vec<PackageEntry>,
    advanced: Vec<PackageEntry>,
    section: AdvancedSection,
    noun_plural: &'static str,
    package_type: &'static str,
    content_type: ContentType,
    cluster_id: i64,
    kind: ContentKind,
    layout: CardLayout,
    bulk: Bulk,
    notices: Vec<String>,
}

impl ContentBox {
    #[allow(clippy::too_many_arguments)]
    pub(super) fn new(
        items: Vec<PackageEntry>,
        advanced: Vec<PackageEntry>,
        section: AdvancedSection,
        noun_plural: &'static str,
        package_type: &'static str,
        content_type: ContentType,
        cluster_id: i64,
        kind: ContentKind,
        layout: CardLayout,
        bulk: Bulk,
    ) -> Self {
        Self {
            items,
            advanced,
            section,
            noun_plural,
            package_type,
            content_type,
            cluster_id,
            kind,
            layout,
            bulk,
            notices: Vec::new(),
        }
    }

    pub(super) fn notices(mut self, notices: Vec<String>) -> Self {
        self.notices = notices;
        self
    }
}

impl Component for ContentBox {
    fn render(&self) -> impl IntoElement {
        let section = self.section;
        let expanded = section.expanded();
        let advanced_count = self.advanced.len();
        let mut items = self.items.clone();
        let normal_count = items.len();
        if expanded {
            items.extend(self.advanced.iter().cloned());
        }
        let package_type = self.package_type;
        let content_type = self.content_type;
        let cluster_id = self.cluster_id;
        let noun_plural = self.noun_plural;
        let kind = &self.kind;
        let layout = self.layout;

        let dispatch = use_dispatch();
        let cluster = use_cluster_mutation();
        let guard = use_essential_guard();
        let warnings_query = use_disable_warnings();
        let mut menu = use_state(|| None::<(f32, f32, PackageEntry)>);
        let mut copies_of = use_state(|| None::<String>);
        let (on_delete, delete_dialog) =
            use_shared_delete(cluster_id, move |(_, hash): (String, String)| {
                cluster.mutate(match parse_folder_pack_id(&hash) {
                    Some((name, enabled)) => ClusterAction::RemoveFolderPack {
                        cluster_id,
                        name: name.to_string(),
                        enabled,
                    },
                    None => ClusterAction::RemoveArtifact { cluster_id, hash },
                });
            });

        let bulk = self.bulk.clone();
        let selection = bulk.selection;
        let active = bulk.active();
        let selecting = active || selection.modifier_held();
        let selected: Vec<bool> = items
            .iter()
            .map(|p| selection.is_selected(&p.package_id))
            .collect();

        let row = {
            let items = items.clone();
            let order = bulk.order.clone();
            move |i: usize| {
                let item: PackageEntry = items[i].clone();
                let key = item.package_id.clone();
                let for_menu = item.clone();
                let is_selected = selected[i];
                let order = order.clone();
                let click_key = key.clone();
                let copies_key = key.clone();
                PackageRow::new(item, cluster_id, package_type)
                    .layout(layout)
                    .selection(is_selected, selecting, move |()| {
                        selection.click(click_key.clone(), &order)
                    })
                    .on_context(move |(x, y)| menu.set(Some((x, y, for_menu.clone()))))
                    .on_copies(move |()| copies_of.set(Some(copies_key.clone())))
                    .key(key)
                    .into_element()
            }
        };

        let count = normal_count + advanced_count;
        let scroll = (count > 0).then(|| {
            let mut sections = vec![LazySection {
                header: false,
                count: normal_count,
            }];
            if advanced_count > 0 {
                sections.push(LazySection {
                    header: true,
                    count: if expanded { advanced_count } else { 0 },
                });
            }
            let (item_height, gap, min_width, max_cols) = match layout {
                CardLayout::List => (CARD_H, CARD_SPACING, 0., 1),
                CardLayout::Grid => (CARD_GRID_H, GRID_GAP, GRID_MIN_W, GRID_MAX_COLS),
            };
            ScrollArea::new()
                .width(Size::fill())
                .height(Size::flex(1.0))
                .scrollbar_gutter(true)
                .lazy_sections(
                    sections,
                    item_height,
                    gap,
                    min_width,
                    max_cols,
                    SECTION_HEADER_H,
                    row,
                    move |_| {
                        SectionHeader {
                            label: t("oneclient.cluster.package_manager.advanced"),
                            count: advanced_count,
                            section,
                        }
                        .into_element()
                    },
                )
                .into_element()
        });

        let copies_target = copies_of
            .read()
            .as_ref()
            .and_then(|key| items.iter().find(|item| &item.package_id == key))
            .filter(|item| !item.copies.is_empty())
            .cloned();
        let copies_open = copies_target.is_some();
        let copies_popup = copies_target.map(|item| {
            let mut loaded = item.clone();
            if item.copies.iter().any(|copy| copy.copy_status.is_some()) {
                loaded.copy_status = Some(CopyStatus::Loaded);
            }
            let rows = std::iter::once(loaded)
                .chain(item.copies.iter().cloned())
                .map(|entry| {
                    let for_menu = entry.clone();
                    let key = entry.package_id.clone();
                    rect()
                        .width(Size::fill())
                        .height(Size::px(CARD_H))
                        .child(
                            PackageRow::new(entry, cluster_id, package_type)
                                .on_context(move |(x, y)| menu.set(Some((x, y, for_menu.clone()))))
                                .key(key),
                        )
                        .into_element()
                });
            OverlayPopup::new()
                .on_close(move |_| copies_of.set(None))
                .child(
                    rect()
                        .width(Size::window_percent(100.))
                        .height(Size::window_percent(100.))
                        .center()
                        .child(
                            rect()
                                .vertical()
                                .width(Size::px(720.))
                                .max_width(Size::window_percent(90.))
                                .spacing(CARD_SPACING)
                                .padding(Gaps::new_all(20.))
                                .corner_radius(rounded(14.))
                                .background(colors::page_elevated())
                                .border(border_all_color(1., colors::component_border()))
                                .child(
                                    label()
                                        .text(tf(
                                            "oneclient.cluster.package_manager.copies.title",
                                            &[&(item.copies.len() + 1), &item.name],
                                        ))
                                        .font_size(text_size(16.))
                                        .font_weight(FontWeight::SEMI_BOLD)
                                        .color(colors::fg_strong()),
                                )
                                .child(
                                    label()
                                        .text(t("oneclient.cluster.package_manager.copies.body"))
                                        .font_size(text_size(12.))
                                        .color(colors::fg_secondary()),
                                )
                                .children(rows),
                        ),
                )
                .into_element()
        });

        let menu_overlay = menu.read().clone().map(|(x, y, item)| {
            let menu_for = if bulk.active() {
                bulk.menu(x, y, item.package_id.clone())
            } else {
                let key = item.package_id.clone();
                let on_bundled = (content_type == ContentType::Mod).then(|| {
                    let item = item.clone();
                    let warnings = disable_warnings(&warnings_query);
                    let handler: EventHandler<()> = (move |()| {
                        let Some(action) = bundled_delete_action(&item, cluster_id) else {
                            return;
                        };
                        let only = [&item];
                        run_guarded(
                            action,
                            if item.deleted { &[] } else { &only[..] },
                            item.name.clone(),
                            EssentialGuardKind::Remove,
                            warnings.clone(),
                            cluster,
                            guard,
                        );
                    })
                    .into();
                    handler
                });
                package_context_menu(
                    x,
                    y,
                    &item,
                    cluster_id,
                    package_type,
                    on_delete,
                    on_bundled,
                    (move |()| selection.toggle(key.clone())).into(),
                )
            };
            menu_for
                .on_close(move |_| menu.set(None))
                .overlay_level(OVERLAY_BASE_LEVEL + if copies_open { 3 } else { 0 })
                .into_element()
        });

        let empty = (count == 0).then(|| match kind {
            ContentKind::Browser => browser_empty(cluster_id, package_type).into_element(),
            ContentKind::Local => {
                local_empty(cluster_id, content_type, dispatch.clone(), noun_plural).into_element()
            }
            ContentKind::Other => empty_state(noun_plural).into_element(),
            ContentKind::NoMatches { scope } => {
                search_empty(noun_plural, scope.as_deref()).into_element()
            }
        });

        let mut bottom_corners = CornerRadius::new_all(0.);
        bottom_corners.fill_bottom(rounded_px(12.));

        // File drops are handled window-wide by the app shell so this box does not claim them
        rect()
            .vertical()
            .width(Size::fill())
            .height(Size::flex(1.0))
            .padding(Gaps::new(0., 12., 12., 12.))
            .corner_radius(bottom_corners)
            .background(colors::page_elevated())
            .overflow(Overflow::Clip)
            .content(Content::Flex)
            .children(self.notices.iter().map(|text| notice_bar(text.clone())))
            .maybe_child(scroll)
            .maybe_child(empty.map(|empty| {
                rect()
                    .width(Size::fill())
                    .height(Size::flex(1.0))
                    .child(empty)
            }))
            .maybe_child(copies_popup)
            .maybe_child(menu_overlay)
            .maybe_child(delete_dialog)
    }
}

pub(crate) fn empty_shell(icon: IconType) -> Rect {
    rect()
        .vertical()
        .width(Size::fill())
        .height(Size::fill())
        .center()
        .padding(Gaps::new_all(48.))
        .spacing(8.)
        .child(Icon::new(icon).size(28.).color(colors::fg_secondary()))
}

pub(crate) fn empty_title(text: impl Into<String>) -> impl IntoElement {
    label()
        .text(text.into())
        .font_size(text_size(14.))
        .color(colors::fg_secondary())
}

pub(crate) fn empty_hint(text: impl Into<String>) -> impl IntoElement {
    label()
        .text(text.into())
        .font_size(text_size(12.))
        .color(colors::fg_secondary())
}

fn empty_state(noun_plural: &'static str) -> impl IntoElement {
    empty_shell(IconType::DotsGrid)
        .child(empty_title(tf(
            "oneclient.cluster.package_manager.empty.title",
            &[&noun_plural],
        )))
        .child(empty_hint(t(
            "oneclient.cluster.package_manager.empty.hint",
        )))
        .into_element()
}

/// The search only looks inside the active tab so name it and point at the tab that covers everything
fn search_empty(noun_plural: &'static str, scope: Option<&str>) -> impl IntoElement {
    let (title, hint) = match scope {
        Some(tab) => (
            tf(
                "oneclient.cluster.package_manager.search_empty.scoped.title",
                &[&noun_plural, &tab],
            ),
            t("oneclient.cluster.package_manager.search_empty.scoped.hint"),
        ),
        None => (
            tf(
                "oneclient.cluster.package_manager.search_empty.title",
                &[&noun_plural],
            ),
            t("oneclient.cluster.package_manager.search_empty.hint"),
        ),
    };

    empty_shell(IconType::SearchMd)
        .child(empty_title(title))
        .child(empty_hint(hint))
        .into_element()
}

fn browser_empty(cluster_id: i64, package_type: &'static str) -> impl IntoElement {
    empty_shell(IconType::SearchMd)
        .child(empty_title(t(
            "oneclient.cluster.package_manager.browser_empty.title",
        )))
        .child(empty_hint(t(
            "oneclient.cluster.package_manager.browser_empty.hint",
        )))
        .child(rect().height(Size::px(6.)))
        .child(browse_button(cluster_id, package_type))
        .into_element()
}

fn local_empty(
    cluster_id: i64,
    content_type: ContentType,
    dispatch: Actions,
    noun_plural: &'static str,
) -> impl IntoElement {
    let is_wayland = utils::is_wayland();

    empty_shell(IconType::FilePlus02)
        .child(empty_title(tf(
            "oneclient.cluster.package_manager.local_empty.title",
            &[&noun_plural],
        )))
        .maybe(!is_wayland, |e| {
            e.child(empty_hint(t(
                "oneclient.cluster.package_manager.local_empty.hint",
            )))
        })
        .child(rect().height(Size::px(6.)))
        .child(add_from_file_button(cluster_id, content_type, dispatch))
        .into_element()
}
