use freya::prelude::*;
use freya::router::RouterContext;
use oneclient_db::console::{ConsoleQueryResult, run_console_query};
use oneclient_db::models::OptionalModStatus;

use oneclient_auth::preview_samples;
use oneclient_core::game::{
    CrashDiagnosis, ModProblem, ModProblemKind, ModRef, crash_mod_issues, crashdata, suspected_mods,
};
use oneclient_core::simulate::Damage;
use oneclient_net::status::{self, ServiceStatus};

use crate::Actions;
use crate::components::{
    Button, Dropdown, Icon, IconType, ScrollArea, TextInput, login_dialog, toggle,
};
use crate::hooks::{
    invalidate_auth_queries, settled_or_loading, try_default_account, use_active_cluster_id,
    use_clusters, use_current_account, use_dispatch,
};
use crate::i18n::{t, tf};
use crate::notifications::{
    ClusterUpdateItem, ClusterUpdateSummary, NotificationAction, NotificationActionKind,
    NotificationSpec, OptionalModsGroup,
};
use crate::routes::Route;
use crate::theme::{self, colors, rounded, text_size};
use crate::ui::border_all_color;

type SqlResult = Option<Result<ConsoleQueryResult, String>>;

#[derive(PartialEq)]
pub struct Debug;

impl Component for Debug {
    fn render(&self) -> impl IntoElement {
        let dispatch = use_dispatch();
        let log_debug_info = use_state(|| false);
        let show_dev_stuff = use_state(|| false);
        let seen_onboarding = use_state(|| true);
        let use_grid_on_mods_list = use_state(|| true);

        rect()
            .vertical()
            .width(Size::fill())
            .height(Size::fill())
            .padding(40.)
            .spacing(8.)
            .child(
                ScrollArea::new()
                    .height(Size::fill())
                    .child(
                        rect()
                            .vertical()
                            .child(
                                label()
                                    .text("Debug")
                                    .font_size(text_size(32.))
                                    .font_weight(FontWeight::BOLD)
                                    .color(colors::fg_primary()),
                            )
                            .child(
                                label()
                                    .text("The end user won't really be looking at this page.")
                                    .font_size(text_size(13.))
                                    .color(colors::fg_secondary()),
                            ),
                    )
                    .child(divider())
                    .child(section(
                        "Settings",
                        vec![
                            toggle_row("Log Debug Info", log_debug_info),
                            toggle_row("Show Dev stuff", show_dev_stuff),
                            toggle_row("Seen Onboarding", seen_onboarding),
                            toggle_row("Use Grid On Mods List", use_grid_on_mods_list),
                        ],
                    ))
                    .child(divider())
                    .child(section(
                        "Toast Controller",
                        vec![ToastController.into_element()],
                    ))
                    .child(divider())
                    .child(section(
                        "Toast Simulator",
                        vec![ToastSimulator.into_element()],
                    ))
                    .child(divider())
                    .child(section(
                        "Cluster Update Simulator",
                        vec![ClusterUpdateSimulator.into_element()],
                    ))
                    .child(divider())
                    .child(section(
                        "Release Migration",
                        vec![ReleaseMigrationSimulator.into_element()],
                    ))
                    .child(divider())
                    .child(section(
                        "Launcher Auto Update",
                        vec![LauncherUpdateSimulator.into_element()],
                    ))
                    .child(divider())
                    .child(section(
                        "Connectivity Status Bar",
                        vec![StatusBarSimulator.into_element()],
                    ))
                    .child(divider())
                    .child(section(
                        "Auth Error Guidance",
                        vec![AuthGuidancePreview.into_element()],
                    ))
                    .child(divider())
                    .child(section(
                        "Session Expiry",
                        vec![SessionExpirySimulator.into_element()],
                    ))
                    .child(divider())
                    .child(section(
                        "Corruption Simulator",
                        vec![CorruptionSimulator.into_element()],
                    ))
                    .child(divider())
                    .child(section("Clusters", vec![ClusterList.into_element()]))
                    .child(divider())
                    .child(section("SQL Console", vec![SqlConsole.into_element()]))
                    .child(divider())
                    .child(section(
                        "Other",
                        vec![action_row(
                            &dispatch,
                            vec![
                                ("Open Dev Tools", IconType::CodeSnippet02),
                                ("Open Onboarding", IconType::Rocket02),
                                ("Open Launcher Data", IconType::Folder),
                                ("Log Running Processes", IconType::Terminal),
                            ],
                        )],
                    )),
            )
    }
}

const SAMPLE_PLAYER: &str = "Steve";
const SAMPLE_GROUP: &str = "Test Group";
const SAMPLE_MESSAGE: &str = "Anyone up for a game?";
const SAMPLE_ERROR: &str = "Simulated failure reason";

fn toast_spec(title: impl Into<String>, body: impl Into<String>) -> NotificationSpec {
    NotificationSpec {
        title: title.into(),
        body: body.into(),
        level: oneclient_events::Level::Info,
        icon: None,
        progress: None,
        actions: Vec::new(),
        toast_only: false,
    }
}

fn error_toast(title: impl Into<String>, body: impl Into<String>) -> NotificationSpec {
    NotificationSpec {
        level: oneclient_events::Level::Error,
        toast_only: true,
        ..toast_spec(title, body)
    }
}

fn party_toast(title: impl Into<String>, body: impl Into<String>) -> NotificationSpec {
    NotificationSpec {
        icon: Some(IconType::Users01),
        toast_only: true,
        ..toast_spec(title, body)
    }
}

fn chat_toast(
    title: impl Into<String>,
    body: impl Into<String>,
    toast_only: bool,
) -> NotificationSpec {
    NotificationSpec {
        icon: Some(IconType::MessageTextSquare01),
        actions: vec![NotificationAction {
            label: t("oneclient.chat.notify.open").to_string(),
            kind: NotificationActionKind::OpenChat(None),
        }],
        toast_only,
        ..toast_spec(title, body)
    }
}

fn social_toasts() -> Vec<(&'static str, Vec<NotificationSpec>)> {
    let name: &[&dyn std::fmt::Display] = &[&SAMPLE_PLAYER];
    vec![
        (
            "Party: things that happen to you",
            vec![
                party_toast(
                    tf("oneclient.components.lobby.toast.invite_received", name),
                    t("oneclient.components.lobby.toast.invite_received_body"),
                ),
                party_toast(
                    t("oneclient.components.lobby.toast.you_were_kicked"),
                    t("oneclient.components.lobby.toast.you_were_kicked_body"),
                ),
                party_toast(
                    t("oneclient.components.lobby.toast.disbanded_by_leader"),
                    t("oneclient.components.lobby.toast.disbanded_by_leader_body"),
                ),
                party_toast(
                    t("oneclient.components.lobby.toast.party_lost"),
                    t("oneclient.components.lobby.toast.party_lost_body"),
                ),
            ],
        ),
        (
            "Party: your own actions",
            vec![
                party_toast(
                    t("oneclient.components.lobby.toast.created"),
                    t("oneclient.components.lobby.toast.created_body"),
                ),
                party_toast(
                    tf("oneclient.components.lobby.toast.joined", name),
                    t("oneclient.components.lobby.toast.joined_body"),
                ),
                party_toast(
                    tf("oneclient.components.lobby.toast.invited", name),
                    t("oneclient.components.lobby.toast.invited_body"),
                ),
                NotificationSpec {
                    toast_only: true,
                    ..toast_spec(
                        tf("oneclient.components.lobby.toast.invite_cancelled", name),
                        t("oneclient.components.lobby.toast.invite_cancelled_body"),
                    )
                },
                party_toast(
                    tf("oneclient.components.lobby.toast.kicked", name),
                    t("oneclient.components.lobby.toast.kicked_body"),
                ),
                party_toast(
                    tf("oneclient.components.lobby.toast.promoted", name),
                    t("oneclient.components.lobby.toast.promoted_body"),
                ),
                party_toast(
                    t("oneclient.components.lobby.toast.left"),
                    t("oneclient.components.lobby.toast.left_body"),
                ),
                party_toast(
                    t("oneclient.components.lobby.toast.disbanded"),
                    t("oneclient.components.lobby.toast.disbanded_body"),
                ),
                error_toast(t("oneclient.components.lobby.toast.failed"), SAMPLE_ERROR),
            ],
        ),
        (
            "Chat",
            vec![
                chat_toast(SAMPLE_PLAYER, SAMPLE_MESSAGE, true),
                chat_toast(
                    tf(
                        "oneclient.chat.notify.group_message",
                        &[&SAMPLE_PLAYER, &SAMPLE_GROUP],
                    ),
                    SAMPLE_MESSAGE,
                    true,
                ),
                chat_toast(
                    tf("oneclient.chat.notify.invite", name),
                    t("oneclient.chat.notify.invite_body"),
                    false,
                ),
                chat_toast(
                    tf("oneclient.chat.notify.friend_request", name),
                    t("oneclient.chat.notify.friend_request_body"),
                    false,
                ),
            ],
        ),
        (
            "Joining a world invite",
            vec![
                error_toast(
                    t("oneclient.components.invite_join.expired"),
                    t("oneclient.components.invite_join.expired_body"),
                ),
                toast_spec(
                    t("oneclient.components.invite_join.running_title"),
                    t("oneclient.components.invite_join.running_body"),
                ),
                toast_spec(
                    t("oneclient.components.invite_join.unknown_title"),
                    t("oneclient.components.invite_join.unknown_body"),
                ),
            ],
        ),
    ]
}

#[derive(PartialEq)]
struct ToastSimulator;

impl Component for ToastSimulator {
    fn render(&self) -> impl IntoElement {
        let dispatch = use_dispatch();
        let mut open = use_state(|| false);
        let is_open = open();
        let groups = social_toasts();
        let count: usize = groups.iter().map(|(_, toasts)| toasts.len()).sum();

        rect()
            .vertical()
            .width(Size::fill())
            .spacing(10.)
            .child(
                Button::new()
                    .secondary()
                    .child(
                        Icon::new(if is_open {
                            IconType::ChevronDown
                        } else {
                            IconType::ChevronRight
                        })
                        .size(16.),
                    )
                    .text(format!("Social ({count})"))
                    .on_press(move |_| open.set(!is_open)),
            )
            .maybe_child(is_open.then(|| {
                rect()
                    .vertical()
                    .width(Size::fill())
                    .spacing(14.)
                    .children(
                        groups
                            .into_iter()
                            .map(|(title, toasts)| toast_group(title, toasts, &dispatch)),
                    )
                    .into_element()
            }))
    }
}

fn toast_group(title: &'static str, toasts: Vec<NotificationSpec>, dispatch: &Actions) -> Element {
    rect()
        .vertical()
        .width(Size::fill())
        .spacing(6.)
        .child(
            label()
                .text(title)
                .font_size(text_size(13.))
                .font_weight(FontWeight::SEMI_BOLD)
                .color(colors::fg_secondary()),
        )
        .children(toasts.into_iter().map(|toast| toast_row(toast, dispatch)))
        .into_element()
}

fn toast_row(toast: NotificationSpec, dispatch: &Actions) -> Element {
    let dispatch = dispatch.clone();
    rect()
        .horizontal()
        .width(Size::fill())
        .content(Content::Flex)
        .cross_align(Alignment::Center)
        .spacing(12.)
        .padding(Gaps::new_symmetric(10., 14.))
        .corner_radius(rounded(10.))
        .background(colors::page_elevated())
        .child(
            rect()
                .vertical()
                .width(Size::flex(1.0))
                .child(
                    label()
                        .text(toast.title.clone())
                        .font_size(text_size(14.))
                        .color(colors::fg_primary()),
                )
                .child(
                    label()
                        .text(toast.body.clone())
                        .font_size(text_size(12.))
                        .color(colors::fg_secondary()),
                ),
        )
        .child(
            Button::new()
                .secondary()
                .text("Simulate")
                .on_press(move |_| dispatch.push_notification(toast.clone())),
        )
        .into_element()
}

#[derive(PartialEq)]
struct ClusterList;

impl Component for ClusterList {
    fn render(&self) -> impl IntoElement {
        let dispatch = use_dispatch();
        let active_id = use_active_cluster_id();
        let clusters = settled_or_loading(&use_clusters()).unwrap_or_default();

        let mut list = rect().vertical().width(Size::fill()).spacing(8.);

        if clusters.is_empty() {
            return list.child(
                label()
                    .text("No clusters in the database.")
                    .font_size(text_size(13.))
                    .color(colors::fg_secondary()),
            );
        }

        for cluster in clusters {
            let cluster_id = cluster.id;
            let launch = dispatch.clone();
            let mut active_id = active_id;
            let loader_version = cluster
                .mc_loader_version
                .as_deref()
                .map_or_else(String::new, |version| format!(" {version}"));

            list = list.child(
                rect()
                    .horizontal()
                    .width(Size::fill())
                    .cross_align(Alignment::Center)
                    .main_align(Alignment::SpaceBetween)
                    .spacing(12.)
                    .padding(Gaps::new_symmetric(10., 14.))
                    .corner_radius(rounded(10.))
                    .background(colors::page_elevated())
                    .child(
                        rect()
                            .vertical()
                            .child(
                                label()
                                    .text(cluster.name.clone())
                                    .font_size(text_size(14.))
                                    .color(colors::fg_primary()),
                            )
                            .child(
                                label()
                                    .text(format!(
                                        "#{cluster_id} · {} · {}{loader_version} · {:?}",
                                        cluster.mc_version, cluster.mc_loader, cluster.stage
                                    ))
                                    .font_size(text_size(12.))
                                    .color(colors::fg_secondary()),
                            ),
                    )
                    .child(
                        rect()
                            .horizontal()
                            .spacing(8.)
                            .child(
                                Button::new()
                                    .primary()
                                    .on_press(move |_| launch.launch_cluster(cluster_id))
                                    .text("Launch"),
                            )
                            .child(
                                Button::new()
                                    .secondary()
                                    .on_press(move |_| {
                                        *active_id.write() = Some(cluster_id);
                                        let _ = RouterContext::get()
                                            .push(Route::ClusterOverview { cluster_id });
                                    })
                                    .text("View"),
                            ),
                    ),
            );
        }

        list
    }
}

#[derive(PartialEq)]
struct ToastController;

impl Component for ToastController {
    fn render(&self) -> impl IntoElement {
        let dispatch = use_dispatch();
        let title = use_state(|| "Downloading assets".to_string());
        let body = use_state(|| "PolyBlock by Polyfrost".to_string());
        let mut progress = use_state(|| 0u64);

        let info = dispatch.clone();
        let error = dispatch.clone();
        let prog = dispatch.clone();
        let truncated = dispatch.clone();
        let reset = dispatch;

        rect()
            .vertical()
            .width(Size::fill())
            .spacing(10.)
            .child(
                rect()
                    .horizontal()
                    .width(Size::fill())
                    .spacing(12.)
                    .child(
                        rect()
                            .width(Size::flex(1.0))
                            .child(TextInput::new(title).placeholder("Title")),
                    )
                    .child(
                        rect()
                            .width(Size::flex(1.0))
                            .child(TextInput::new(body).placeholder("Body")),
                    ),
            )
            .child(
                rect()
                    .horizontal()
                    .width(Size::fill())
                    .spacing(12.)
                    .child(
                        Button::new()
                            .primary()
                            .child(Icon::new(IconType::InfoCircle).size(16.))
                            .text("Send Info")
                            .on_press(move |_| {
                                info.notify(title.read().clone())
                                    .body(body.read().clone())
                                    .info()
                                    .send();
                            }),
                    )
                    .child(
                        Button::new()
                            .danger()
                            .child(Icon::new(IconType::AlertTriangle).size(16.))
                            .text("Send Error")
                            .on_press(move |_| {
                                error
                                    .notify(title.read().clone())
                                    .body(body.read().clone())
                                    .error()
                                    .send();
                            }),
                    )
                    .child(
                        Button::new()
                            .secondary()
                            .child(Icon::new(IconType::AlertTriangle).size(16.))
                            .text("mclo.gs Shortened")
                            .on_press(move |_| {
                                crate::components::upload_mclogs::notify_log_truncated(&truncated);
                            }),
                    )
                    .child(
                        Button::new()
                            .secondary()
                            .child(Icon::new(IconType::FolderDownload).size(16.))
                            .text("Progress +10")
                            .on_press(move |_| {
                                let next = (*progress.read() + 10).min(100);
                                progress.set(next);
                                prog.send_test_progress(next, 100);
                            }),
                    )
                    .child(
                        Button::new()
                            .secondary()
                            .text("Reset Progress")
                            .on_press(move |_| {
                                progress.set(0);
                                reset.send_test_progress(0, 100);
                            }),
                    ),
            )
            .into_element()
    }
}

#[derive(PartialEq)]
struct ClusterUpdateSimulator;

impl Component for ClusterUpdateSimulator {
    fn render(&self) -> impl IntoElement {
        let dispatch = use_dispatch();
        let cluster_id = use_state(|| "1".to_string());
        let cluster_name = use_state(|| "PolyBlock".to_string());
        let updated = use_state(|| "Sodium 0.5 → 0.6, Iris 1.7 → 1.8".to_string());
        let added = use_state(|| "Lithium".to_string());
        let removed = use_state(|| "OptiFine".to_string());
        let optional = use_state(|| "Lithium".to_string());

        let simulate = dispatch.clone();

        rect()
            .vertical()
            .width(Size::fill())
            .spacing(10.)
            .child(
                label()
                    .text("Builds the same notification the bundle sync sends: one \"View changes\" action carrying every changed cluster, opened into the changes modal. Anything listed under Optional also raises the \"Optional mods available\" prompt, exactly as the real sync does. Optional mods are not installed, so they are independent of Added rather than a subset of it.")
                    .font_size(text_size(13.))
                    .color(colors::fg_secondary()),
            )
            .child(
                rect()
                    .horizontal()
                    .width(Size::fill())
                    .spacing(12.)
                    .child(
                        rect()
                            .width(Size::px(120.))
                            .child(TextInput::new(cluster_id).placeholder("Cluster ID")),
                    )
                    .child(
                        rect()
                            .width(Size::flex(1.0))
                            .child(TextInput::new(cluster_name).placeholder("Cluster name")),
                    ),
            )
            .child(
                rect()
                    .horizontal()
                    .width(Size::fill())
                    .spacing(12.)
                    .child(
                        rect().width(Size::flex(1.0)).child(
                            TextInput::new(updated).placeholder("Updated (comma separated)"),
                        ),
                    )
                    .child(
                        rect()
                            .width(Size::flex(1.0))
                            .child(TextInput::new(added).placeholder("Added (comma separated)")),
                    )
                    .child(
                        rect().width(Size::flex(1.0)).child(
                            TextInput::new(removed).placeholder("Removed (comma separated)"),
                        ),
                    )
                    .child(
                        rect().width(Size::flex(1.0)).child(
                            TextInput::new(optional).placeholder("Optional (comma separated)"),
                        ),
                    ),
            )
            .child(
                Button::new()
                    .primary()
                    .child(Icon::new(IconType::DownloadCloud02).size(16.))
                    .text("Simulate Cluster Update")
                    .on_press(move |_| {
                        let summary = ClusterUpdateSummary {
                            cluster_id: cluster_id.read().trim().parse().unwrap_or(1),
                            cluster_name: cluster_name.read().clone(),
                            updated: cluster_update_items(&split_csv(&updated.read())),
                            added: cluster_update_items(&split_csv(&added.read())),
                            removed: cluster_update_items(&split_csv(&removed.read())),
                            optional: cluster_update_items(&split_csv(&optional.read()))
                        };
                        send_cluster_update(&simulate, vec![summary]);
                    }),
            )
            .child(
                label()
                    .text("Presets: every shape the notification and modal can take.")
                    .font_size(text_size(13.))
                    .color(colors::fg_secondary()),
            )
            .children(cluster_update_preset_rows(&dispatch))
            .into_element()
    }
}

type ClusterUpdatePreset = fn() -> Vec<ClusterUpdateSummary>;

/// Each preset pins one variation plural copy empty category tab single- vs multi-cluster footer grouping header overflow
const CLUSTER_UPDATE_PRESETS: [(&str, IconType, ClusterUpdatePreset); 7] = [
    (
        "1 cluster · all categories",
        IconType::DownloadCloud02,
        || {
            vec![preset_summary(
                1,
                "PolyBlock",
                &["Sodium 0.5 → 0.6", "Iris 1.7 → 1.8", "Patcher 1.8 → 1.9"],
                &["Lithium", "FerriteCore"],
                &["OptiFine"],
                &["Distant Horizons"],
            )]
        },
    ),
    ("1 cluster · updates only", IconType::RefreshCw01, || {
        vec![preset_summary(
            1,
            "PolyBlock",
            &[
                "Sodium 0.5 → 0.6",
                "Iris 1.7 → 1.8",
                "Indium 1.0 → 1.1",
                "Fabric API 0.92 → 0.100",
            ],
            &[],
            &[],
            &[],
        )]
    }),
    ("1 cluster · single change", IconType::Plus, || {
        vec![preset_summary(1, "PolyBlock", &[], &["Lithium"], &[], &[])]
    }),
    ("3 clusters · mixed", IconType::DotsGrid, || {
        vec![
            preset_summary(
                1,
                "PolyBlock",
                &["Sodium 0.5 → 0.6", "Iris 1.7 → 1.8"],
                &["Lithium"],
                &[],
                &[],
            ),
            preset_summary(2, "Skyblock", &[], &[], &["OptiFine", "Skytils"], &[]),
            preset_summary(
                3,
                "Vanilla+",
                &[],
                &["Sodium", "Iris", "FerriteCore"],
                &[],
                &[],
            ),
        ]
    }),
    ("2 clusters · removals only", IconType::Trash01, || {
        vec![
            preset_summary(1, "PolyBlock", &[], &[], &["OptiFine"], &[]),
            preset_summary(
                2,
                "Skyblock",
                &[],
                &[],
                &["Skytils", "NotEnoughUpdates"],
                &[],
            ),
        ]
    }),
    ("6 clusters · long names", IconType::Database01, || {
        (1..=6)
            .map(|i| ClusterUpdateSummary {
                cluster_id: i,
                cluster_name: format!(
                    "Cluster {i} with a deliberately overlong name that has to truncate"
                ),
                updated: cluster_update_items(&[
                    format!("Sodium 0.{i} → 0.{}", i + 1),
                    format!("Iris 1.{i} → 1.{}", i + 1),
                ]),
                added: cluster_update_items(&[format!("Lithium {i}")]),
                removed: Vec::new(),
                optional: Vec::new(),
            })
            .collect()
    }),
    ("2 clusters · offers only", IconType::Plus, || {
        vec![
            preset_summary(1, "PolyBlock", &[], &[], &[], &["Lithium", "FerriteCore"]),
            preset_summary(2, "Skyblock", &[], &["Skytils"], &[], &["Skytils"]),
        ]
    }),
];

fn cluster_update_preset_rows(dispatch: &crate::Actions) -> Vec<Element> {
    CLUSTER_UPDATE_PRESETS
        .chunks(3)
        .map(|chunk| {
            let mut row = rect().horizontal().width(Size::fill()).spacing(12.);

            for (text, icon, build) in chunk {
                let dispatch = dispatch.clone();
                let build = *build;
                row = row.child(
                    Button::new()
                        .secondary()
                        .child(Icon::new(*icon).size(16.))
                        .text(*text)
                        .on_press(move |_| send_cluster_update(&dispatch, build())),
                );
            }

            row.into_element()
        })
        .collect()
}

fn preset_summary(
    cluster_id: i64,
    cluster_name: &str,
    updated: &[&str],
    added: &[&str],
    removed: &[&str],
    optional: &[&str],
) -> ClusterUpdateSummary {
    ClusterUpdateSummary {
        cluster_id,
        cluster_name: cluster_name.to_string(),
        updated: cluster_update_items(updated),
        added: cluster_update_items(added),
        removed: cluster_update_items(removed),
        optional: cluster_update_items(optional),
    }
}

fn cluster_update_items(names: &[impl AsRef<str>]) -> Vec<ClusterUpdateItem> {
    names
        .iter()
        .enumerate()
        .map(|(index, name)| ClusterUpdateItem {
            offer: Some(("simulated-bundle".to_string(), name.as_ref().to_string())),
            status: Some(if index % 2 == 0 {
                OptionalModStatus::New
            } else {
                OptionalModStatus::Skipped
            }),
            ..ClusterUpdateItem::from_name(name.as_ref())
        })
        .collect()
}

fn send_cluster_update(dispatch: &crate::Actions, summaries: Vec<ClusterUpdateSummary>) {
    if summaries.is_empty() {
        return;
    }

    let total: usize = summaries.iter().map(|s| s.total()).sum();
    let plural = if total == 1 { "" } else { "s" };
    let (title, body) = match summaries.as_slice() {
        [only] => (
            "Cluster updated",
            format!("{total} package{plural} changed in {}", only.cluster_name),
        ),
        many => (
            "Mods updated",
            format!(
                "{total} package{plural} updated across {} clusters",
                many.len()
            ),
        ),
    };

    let optional: Vec<OptionalModsGroup> = summaries
        .iter()
        .filter_map(OptionalModsGroup::from_summary)
        .collect();

    dispatch
        .notify(title)
        .body(body)
        .icon(IconType::DownloadCloud02)
        .action(NotificationAction {
            label: "View changes".to_string(),
            kind: NotificationActionKind::OpenClusterUpdate(summaries),
        })
        .send();

    // No continuation the real prompt is raised by a launch, which waits on one
    dispatch.open_optional_mods(optional, None);
}

#[derive(PartialEq)]
struct ReleaseMigrationSimulator;

fn newest_first(clusters: &mut [oneclient_core::clusters::Cluster]) {
    clusters.sort_by_key(|cluster| {
        std::cmp::Reverse(
            oneclient_common::version::parse_mc_version(&cluster.mc_version).map(|parsed| {
                (
                    parsed.major,
                    parsed.minor.unwrap_or(0),
                    parsed.patch.unwrap_or(0),
                )
            }),
        )
    });
}

impl Component for ReleaseMigrationSimulator {
    fn render(&self) -> impl IntoElement {
        let dispatch = use_dispatch();
        let clusters_query = use_clusters();
        let mut target = use_state(|| None::<i64>);

        let mut clusters = settled_or_loading(&clusters_query).unwrap_or_default();
        newest_first(&mut clusters);

        let selected = target
            .read()
            .and_then(|id| clusters.iter().find(|cluster| cluster.id == id))
            .or_else(|| clusters.first())
            .cloned();

        let ids: Vec<i64> = clusters.iter().map(|cluster| cluster.id).collect();
        let options: Vec<String> = clusters
            .iter()
            .map(|cluster| cluster.name.clone())
            .collect();
        let selected_name = selected
            .as_ref()
            .map(|cluster| cluster.name.clone())
            .unwrap_or_else(|| "No clusters".to_string());
        let selected_id = selected.as_ref().map(|cluster| cluster.id);

        let simulate = dispatch.clone();
        let fake = dispatch.clone();
        let queue = dispatch.clone();

        rect()
            .vertical()
            .width(Size::fill())
            .spacing(10.)
            .child(
                label()
                    .text("\"Simulate\" opens the real migration modal with the chosen cluster as the new release and the real compatibility check against every other cluster with the same loader; closing it changes nothing. \"Fake Plan\" skips the check and fills the same modal with made-up packages, so the UI can be reviewed when no cluster has anything to migrate. \"Queue as New Version\" adds the chosen version to the pending list exactly as a new manifest entry would, then runs the startup check, so the real one-time flow can be tested.")
                    .font_size(text_size(13.))
                    .color(colors::fg_secondary()),
            )
            .child(
                rect()
                    .horizontal()
                    .width(Size::fill())
                    .cross_align(Alignment::Center)
                    .spacing(12.)
                    .child(
                        label()
                            .text("Target")
                            .font_size(text_size(13.))
                            .color(colors::fg_secondary()),
                    )
                    .child(
                        Dropdown::new(selected_name, options)
                            .width(Size::px(220.))
                            .height(Size::px(32.))
                            .on_select(move |index: usize| {
                                if let Some(id) = ids.get(index) {
                                    target.set(Some(*id));
                                }
                            }),
                    )
                    .child(
                        Button::new()
                            .primary()
                            .enabled(selected_id.is_some())
                            .child(Icon::new(IconType::RefreshCw01).size(16.))
                            .text("Simulate Release Migration")
                            .on_press(move |_| {
                                if let Some(id) = selected_id {
                                    simulate.simulate_release_migration(id);
                                }
                            }),
                    )
                    .child(
                        Button::new()
                            .secondary()
                            .enabled(selected_id.is_some())
                            .text("Fake Plan")
                            .on_press(move |_| {
                                if let Some(id) = selected_id {
                                    fake.simulate_fake_release_migration(id);
                                }
                            }),
                    )
                    .child(
                        Button::new()
                            .secondary()
                            .enabled(selected_id.is_some())
                            .text("Queue as New Version")
                            .on_press(move |_| {
                                if let Some(id) = selected_id {
                                    queue.queue_release_migration(id);
                                }
                            }),
                    ),
            )
            .into_element()
    }
}

#[derive(PartialEq)]
struct LauncherUpdateSimulator;

impl Component for LauncherUpdateSimulator {
    fn render(&self) -> impl IntoElement {
        rect()
            .vertical()
            .width(Size::fill())
            .spacing(10.)
            .child(
                label()
                    .text("Drives the real auto-update UX (prompt → download progress → \"restart to apply\") against a fake release, with no network or disk. \"Simulate Manual Update Toast\" shows the notify-only toast that non-AppImage Linux installs get. \"Check for Updates Now\" runs the real check against the release feed.")
                    .font_size(text_size(13.))
                    .color(colors::fg_secondary()),
            )
            .child(
                rect()
                    .horizontal()
                    .width(Size::fill())
                    .spacing(12.)
                    .child(
                        Button::new()
                            .primary()
                            .child(Icon::new(IconType::DownloadCloud02).size(16.))
                            .text("Simulate Auto Update")
                            .on_press(|_| crate::updater::spawn_simulated_update()),
                    )
                    .child(
                        Button::new()
                            .secondary()
                            .child(Icon::new(IconType::LinkExternal01).size(16.))
                            .text("Simulate Manual Update Toast")
                            .on_press(|_| crate::updater::simulate_manual_update_toast()),
                    )
                    .child(
                        Button::new()
                            .secondary()
                            .child(Icon::new(IconType::RefreshCw01).size(16.))
                            .text("Check for Updates Now")
                            .on_press(|_| {
                                if let Ok(state) = crate::launcher::state() {
                                    crate::updater::spawn_update_check(
                                        false,
                                        state.services.events.clone(),
                                    );
                                }
                            }),
                    ),
            )
            .into_element()
    }
}

/// Pins `oneclient_net::status` so the connectivity banner can be seen without unplugging anything
#[derive(PartialEq)]
struct StatusBarSimulator;

const STATUS_PRESETS: [(&str, IconType, ServiceStatus); 4] = [
    (
        "No internet",
        IconType::Globe01,
        ServiceStatus {
            online: false,
            mc_auth_up: false,
            polyfrost_up: false,
        },
    ),
    (
        "Minecraft auth down",
        IconType::AlertTriangle,
        ServiceStatus {
            online: true,
            mc_auth_up: false,
            polyfrost_up: true,
        },
    ),
    (
        "Polyfrost down",
        IconType::AlertCircle,
        ServiceStatus {
            online: true,
            mc_auth_up: true,
            polyfrost_up: false,
        },
    ),
    (
        "Both services down",
        IconType::AlertTriangle,
        ServiceStatus {
            online: true,
            mc_auth_up: false,
            polyfrost_up: false,
        },
    ),
];

impl Component for StatusBarSimulator {
    fn render(&self) -> impl IntoElement {
        let mut pinned = use_state(status::forced);

        let mut row = rect().horizontal().width(Size::fill()).spacing(12.);
        for (text, icon, forced) in STATUS_PRESETS {
            row = row.child(
                Button::new()
                    .secondary()
                    .child(Icon::new(icon).size(16.))
                    .text(text)
                    .on_press(move |_| {
                        status::force(Some(forced));
                        pinned.set(Some(forced));
                    }),
            );
        }

        let current = *pinned.read();
        let state_text = match current {
            Some(_) => "Pinned. Probing still runs, but its result is not published.".to_string(),
            None => "Not pinned; showing the real probe result.".to_string(),
        };

        rect()
            .vertical()
            .width(Size::fill())
            .spacing(10.)
            .child(
                label()
                    .text("Forces what the connectivity prober reports, so the real status bar renders its banner. Dismissing a banner is remembered until the issue clears.")
                    .font_size(text_size(13.))
                    .color(colors::fg_secondary()),
            )
            .child(row)
            .child(
                rect()
                    .horizontal()
                    .width(Size::fill())
                    .cross_align(Alignment::Center)
                    .spacing(12.)
                    .child(
                        Button::new()
                            .primary()
                            .child(Icon::new(IconType::RefreshCw01).size(16.))
                            .text("Clear + recheck")
                            .enabled(current.is_some())
                            .on_press(move |_| {
                                status::force(None);
                                pinned.set(None);
                            }),
                    )
                    .child(
                        label()
                            .text(state_text)
                            .font_size(text_size(13.))
                            .color(colors::fg_secondary()),
                    ),
            )
            .into_element()
    }
}

#[derive(PartialEq)]
struct AuthGuidancePreview;

impl Component for AuthGuidancePreview {
    fn render(&self) -> impl IntoElement {
        let samples = preview_samples();
        // Index 0 is the no-error state the rest line up with `samples`
        let mut choice = use_state(|| 0usize);
        let mut open = use_state(|| false);

        let mut options: Vec<String> = vec!["No error (in progress)".to_string()];
        options.extend(samples.iter().map(|s| s.label.to_string()));

        let index = (*choice.read()).min(options.len() - 1);
        let selected_label = options[index].clone();

        let popup = open().then(|| {
            let (error, guidance) = match index.checked_sub(1) {
                None => (None, None),
                Some(i) => {
                    let s = &samples[i];
                    (Some(s.message.clone()), s.guidance.clone())
                }
            };
            login_dialog(
                "https://login.live.com/oauth20_authorize (preview)".to_string(),
                "ABCD-EFGH".to_string(),
                "https://www.microsoft.com/link".to_string(),
                false,
                None,
                error,
                guidance,
                move || open.set(false),
            )
        });

        rect()
            .vertical()
            .width(Size::fill())
            .spacing(10.)
            .child(
                label()
                    .text("Opens the real Microsoft sign-in popup exactly as users see it, in the chosen error state.")
                    .font_size(text_size(13.))
                    .color(colors::fg_secondary()),
            )
            .child(
                rect()
                    .horizontal()
                    .width(Size::fill())
                    .cross_align(Alignment::Center)
                    .spacing(12.)
                    .child(
                        Dropdown::new(selected_label, options)
                            .width(Size::px(300.))
                            .height(Size::px(34.))
                            .on_select(move |idx: usize| choice.set(idx)),
                    )
                    .child(
                        Button::new()
                            .primary()
                            .child(Icon::new(IconType::Eye).size(16.))
                            .text("Open preview")
                            .on_press(move |_| open.set(true)),
                    ),
            )
            .maybe_child(popup)
            .into_element()
    }
}

#[derive(PartialEq)]
struct SessionExpirySimulator;

#[derive(Clone, Copy)]
enum ExpiryKind {
    /// Skips the network and flips the account straight to signed out
    SignedOut,
    /// Leaves detection to Microsoft on the next launch
    RejectedToken,
}

impl Component for SessionExpirySimulator {
    fn render(&self) -> impl IntoElement {
        let dispatch = use_dispatch();
        let current = use_current_account();

        let account = try_default_account(&current).filter(|a| a.is_microsoft());
        let target = account.as_ref().map(|a| (a.id, a.username.clone()));
        let usable = account.as_ref().is_some_and(|a| !a.needs_sign_in());

        let description = match &account {
            Some(a) if a.needs_sign_in() => format!("{} is already signed out.", a.username),
            Some(a) => format!("Acts on the active account, {}.", a.username),
            None => "The active account must be a Microsoft account.".to_string(),
        };

        let button = |text: &'static str, icon: IconType, kind: ExpiryKind| {
            let dispatch = dispatch.clone();
            let target = target.clone();
            Button::new()
                .danger()
                .enabled(usable)
                .child(Icon::new(icon).size(16.))
                .text(text)
                .on_press(move |_| {
                    if let Some((id, username)) = target.clone() {
                        run_expiry(&dispatch, kind, id, username);
                    }
                })
        };

        rect()
            .vertical()
            .width(Size::fill())
            .spacing(10.)
            .child(
                label()
                    .text(description)
                    .font_size(text_size(13.))
                    .color(colors::fg_secondary()),
            )
            .child(
                rect()
                    .horizontal()
                    .width(Size::fill())
                    .spacing(8.)
                    .child(button(
                        "Force signed out",
                        IconType::AlertTriangle,
                        ExpiryKind::SignedOut,
                    ))
                    .child(button(
                        "Invalidate refresh token",
                        IconType::RefreshCw01,
                        ExpiryKind::RejectedToken,
                    )),
            )
            .child(
                label()
                    .text("Invalidate keeps the account looking fine until the next launch, where Microsoft answers invalid_grant.")
                    .font_size(text_size(11.))
                    .color(colors::fg_secondary()),
            )
            .into_element()
    }
}

fn run_expiry(dispatch: &crate::Actions, kind: ExpiryKind, id: uuid::Uuid, username: String) {
    let dispatch = dispatch.clone();
    spawn(async move {
        let result = match crate::launcher::state() {
            Ok(state) => match kind {
                ExpiryKind::SignedOut => state.auth.mark_signed_out(id).await,
                ExpiryKind::RejectedToken => state.auth.corrupt_refresh_token(id).await,
            }
            .map_err(|err| err.to_string()),
            Err(err) => Err(err.to_string()),
        };
        invalidate_auth_queries(Some(id)).await;

        match result {
            Ok(()) => {
                let body = match kind {
                    ExpiryKind::SignedOut => format!("{username} is now signed out"),
                    ExpiryKind::RejectedToken => {
                        format!("{username} will be rejected on the next launch")
                    }
                };
                dispatch
                    .notify("Session expiry simulated")
                    .body(body)
                    .icon(IconType::AlertTriangle)
                    .send();
            }
            Err(err) => {
                dispatch
                    .notify("Simulation failed")
                    .body(err)
                    .error()
                    .send();
            }
        }
    });
}

/// Presets are grouped by which layer should catch them same-length corruption only the hashing pass finds truncation the launch-time size check
#[derive(PartialEq)]
struct CorruptionSimulator;

/// `(label, icon, what it does, which check is meant to catch it)`
type DamagePreset = (&'static str, IconType, DamageKind, &'static str);

#[derive(Clone, Copy, PartialEq, Eq)]
enum DamageKind {
    Assets(usize, Damage),
    Libraries(usize, Damage),
    Content(usize, Damage),
    DeleteAssetsTree,
}

const DAMAGE_PRESETS: [DamagePreset; 6] = [
    (
        "Corrupt 25 assets",
        IconType::AlertTriangle,
        DamageKind::Assets(25, Damage::Corrupt),
        "Survives launch; only Verify Files finds it",
    ),
    (
        "Truncate 25 assets",
        IconType::FileX02,
        DamageKind::Assets(25, Damage::Truncate),
        "Caught at launch by the size check",
    ),
    (
        "Delete 25 assets",
        IconType::Trash01,
        DamageKind::Assets(25, Damage::Delete),
        "Caught at launch, re-downloaded",
    ),
    (
        "Corrupt 5 libraries",
        IconType::AlertCircle,
        DamageKind::Libraries(5, Damage::Corrupt),
        "Crashes with ZipException, then offers repair",
    ),
    (
        "Corrupt 5 mods",
        IconType::File02,
        DamageKind::Content(5, Damage::Corrupt),
        "Repaired from the provider, not Mojang",
    ),
    (
        "Delete the assets tree",
        IconType::Folder,
        DamageKind::DeleteAssetsTree,
        "The reported bug; auto-repairs on launch",
    ),
];

impl Component for CorruptionSimulator {
    fn render(&self) -> impl IntoElement {
        let dispatch = use_dispatch();
        let cluster_id = use_state(|| "1".to_string());

        let mut rows = Vec::new();
        for chunk in DAMAGE_PRESETS.chunks(3) {
            let mut row = rect().horizontal().width(Size::fill()).spacing(8.);

            for (text, icon, kind, hint) in chunk {
                let dispatch = dispatch.clone();
                let kind = *kind;
                let hint = *hint;

                row = row.child(
                    rect()
                        .vertical()
                        .width(Size::flex(1.0))
                        .spacing(2.)
                        .child(
                            Button::new()
                                .danger()
                                .width(Size::fill())
                                .child(Icon::new(*icon).size(16.))
                                .text(*text)
                                .on_press(move |_| {
                                    let target =
                                        cluster_id.read().trim().parse::<i64>().unwrap_or(1);
                                    run_damage(&dispatch, kind, target);
                                }),
                        )
                        .child(
                            label()
                                .text(hint)
                                .font_size(text_size(11.))
                                .max_lines(1)
                                .color(colors::fg_secondary()),
                        ),
                );
            }

            rows.push(row.into_element());
        }

        rect()
            .vertical()
            .width(Size::fill())
            .spacing(10.)
            .child(
                label()
                    .text("Damages the real installation so the repair paths can be exercised. Everything here is repairable by \"Verify Files\" in cluster settings, or by launching - which is the point.")
                    .font_size(text_size(13.))
                    .color(colors::fg_secondary()),
            )
            .child(
                rect()
                    .horizontal()
                    .width(Size::fill())
                    .cross_align(Alignment::Center)
                    .spacing(12.)
                    .child(
                        label()
                            .text("Cluster (for mods)")
                            .font_size(text_size(13.))
                            .color(colors::fg_secondary()),
                    )
                    .child(
                        rect()
                            .width(Size::px(120.))
                            .child(TextInput::new(cluster_id).placeholder("Cluster ID")),
                    ),
            )
            .child(
                rect()
                    .vertical()
                    .width(Size::fill())
                    .spacing(8.)
                    .children(rows),
            )
            .child(
                label()
                    .text("Modals: the real prompts, built by the code that raises them for real.")
                    .font_size(text_size(13.))
                    .color(colors::fg_secondary()),
            )
            .child(
                rect()
                    .horizontal()
                    .width(Size::fill())
                    .spacing(12.)
                    .child(prompt_button(
                        "Failed assets prompt",
                        IconType::AlertTriangle,
                        3,
                        0,
                    ))
                    .child(prompt_button(
                        "Failed libraries prompt",
                        IconType::AlertCircle,
                        0,
                        2,
                    ))
                    .child(prompt_button("Mixed failures prompt", IconType::File02, 4, 1)),
            )
            .child(
                rect()
                    .horizontal()
                    .width(Size::fill())
                    .spacing(12.)
                    .child(crash_dialog_button(
                        "Crash: damaged jar",
                        Some(CrashDiagnosis::CorruptArchive {
                            file: Some("fabric-loader-0.15.11.jar".to_string()),
                        }),
                        cluster_id,
                    ))
                    .child(crash_dialog_button(
                        "Crash: out of memory",
                        Some(CrashDiagnosis::OutOfMemory),
                        cluster_id,
                    ))
                    .child(crash_dialog_button(
                        "Crash: missing dependency",
                        Some(CrashDiagnosis::ModLoadFailure {
                            problems: vec![
                                ModProblem {
                                    kind: ModProblemKind::Missing,
                                    required_by: Some(
                                        ModRef::with_id("Sodium Extra", "sodium-extra")
                                            .at(Some("0.6.0")),
                                    ),
                                    dependency: ModRef::with_id("Fabric API", "fabric-api"),
                                    wanted: None,
                                },
                                ModProblem {
                                    kind: ModProblemKind::WrongVersion,
                                    required_by: Some(
                                        ModRef::with_id("Iris", "iris").at(Some("1.8.0")),
                                    ),
                                    dependency: ModRef::with_id("Sodium", "sodium")
                                        .at(Some("0.5.1")),
                                    wanted: Some("0.6.0 or later".to_string()),
                                },
                            ],
                        }),
                        cluster_id,
                    ))
                    .child(crash_dialog_button(
                        "Crash: incompatible mods",
                        Some(CrashDiagnosis::ModLoadFailure {
                            problems: vec![ModProblem {
                                kind: ModProblemKind::Incompatible,
                                required_by: Some(
                                    ModRef::with_id("Sodium", "sodium").at(Some("0.6.0")),
                                ),
                                dependency: ModRef::with_id("OptiFabric", "optifabric")
                                    .at(Some("1.14.3")),
                                wanted: None,
                            }],
                        }),
                        cluster_id,
                    ))
                    .child(crash_dialog_button("Crash: data only", None, cluster_id)),
            )
            .into_element()
    }
}

/// Calls the same function the download path calls so the simulated modal cannot drift from the real one
fn prompt_button(
    text: &'static str,
    icon: IconType,
    failed_assets: usize,
    failed_libraries: usize,
) -> impl IntoElement {
    Button::new()
        .secondary()
        .child(Icon::new(icon).size(16.))
        .text(text)
        .on_press(move |_| {
            spawn(async move {
                let Ok(state) = crate::launcher::state() else {
                    return;
                };
                let answer = oneclient_core::game::confirm_incomplete_install(
                    &state.services.mc(),
                    failed_assets,
                    failed_libraries,
                )
                .await;
                tracing::info!(?answer, "incomplete install prompt answered");
            });
        })
}

fn crash_dialog_button(
    text: &'static str,
    diagnosis: Option<CrashDiagnosis>,
    cluster_id: State<String>,
) -> impl IntoElement {
    Button::new()
        .secondary()
        .child(Icon::new(IconType::AlertCircle).size(16.))
        .text(text)
        .on_press(move |_| {
            let target = cluster_id.read().trim().parse::<i64>().unwrap_or(1);
            let diagnosis = diagnosis.clone();
            spawn(async move {
                let Ok(state) = crate::launcher::state() else {
                    return;
                };

                let fixes = crashdata::fixes_for(&SAMPLE_CRASH_LOG.join("\n"));
                let mod_issues = match &diagnosis {
                    Some(diagnosis) => crash_mod_issues(&state.services, target, diagnosis).await,
                    None => Vec::new(),
                };
                let diagnosis = diagnosis.as_ref();

                let name = state
                    .clusters
                    .get(target)
                    .await
                    .map_or_else(|_| format!("Cluster {target}"), |cluster| cluster.name);

                state
                    .services
                    .events
                    .game_crashed(oneclient_events::GameCrash {
                        cluster_id: target,
                        cluster_name: name.clone(),
                        title: diagnosis
                            .map_or_else(|| format!("{name} crashed"), CrashDiagnosis::title),
                        exit: "exit code: 1".to_string(),
                        played_secs: 252,
                        cause: diagnosis.map(CrashDiagnosis::body),
                        suspects: SAMPLE_CRASH_LOG
                            .iter()
                            .find_map(|line| suspected_mods(line))
                            .unwrap_or_default(),
                        remedy: diagnosis.and_then(CrashDiagnosis::remedy),
                        fixes,
                        excerpt: SAMPLE_CRASH_LOG
                            .iter()
                            .map(|line| (*line).to_string())
                            .collect(),
                        game_dir: oneclient_common::paths::shared_minecraft_dir()
                            .ok()
                            .map(|dir| dir.to_string_lossy().to_string()),
                        mod_issues,
                    });
            });
        })
}

const SAMPLE_CRASH_LOG: &[&str] = &[
    "[12:04:11] [main/INFO]: Loading 42 mods",
    "[12:04:12] [main/ERROR]: Unable to launch",
    "java.lang.NullPointerException: Initializing game",
    "\tat net.minecraft.client.Minecraft.displayGuiScreen(Minecraft.java)",
    "\tat io.github.moulberry.notenoughupdates.NotEnoughUpdates.onTick",
    "\tat java.base/java.lang.Thread.run(Thread.java:840)",
    "\tSuspected Mods: NotEnoughUpdates (notenoughupdates), Minecraft (minecraft)",
];

fn run_damage(dispatch: &crate::Actions, kind: DamageKind, cluster_id: i64) {
    let dispatch = dispatch.clone();
    spawn(async move {
        let result = match kind {
            DamageKind::Assets(count, damage) => {
                oneclient_core::simulate::damage_assets(count, damage)
                    .await
                    .map(|report| (report, damage.verb()))
            }
            DamageKind::Libraries(count, damage) => {
                oneclient_core::simulate::damage_libraries(count, damage)
                    .await
                    .map(|report| (report, damage.verb()))
            }
            DamageKind::Content(count, damage) => match crate::launcher::state() {
                Ok(state) => oneclient_core::simulate::damage_cluster_content(
                    &state, cluster_id, count, damage,
                )
                .await
                .map(|report| (report, damage.verb())),
                Err(err) => Err(err),
            },
            DamageKind::DeleteAssetsTree => oneclient_core::simulate::delete_assets_tree()
                .await
                .map(|report| (report, "Deleted")),
        };

        match result {
            Ok((report, verb)) => {
                dispatch
                    .notify("Damage simulated")
                    .body(report.summary(verb))
                    .icon(IconType::AlertTriangle)
                    .error()
                    .send();
            }
            Err(err) => {
                dispatch
                    .notify("Simulation failed")
                    .body(err.to_string())
                    .error()
                    .send();
            }
        }
    });
}

#[derive(PartialEq)]
struct SqlConsole;

impl Component for SqlConsole {
    fn render(&self) -> impl IntoElement {
        let query = use_state(|| "SELECT * FROM clusters;".to_string());
        let result = use_state(|| None::<Result<ConsoleQueryResult, String>>);
        let running = use_state(|| false);

        rect()
            .vertical()
            .width(Size::fill())
            .spacing(10.)
            .child(
                TextInput::new(query)
                    .multiline(true)
                    .placeholder("SELECT * FROM …")
                    .font_family(theme::mono_font())
                    .width(Size::fill())
                    .height(Size::px(140.))
                    .on_submit(move |_| run_sql(query, result, running)),
            )
            .child(
                rect()
                    .horizontal()
                    .width(Size::fill())
                    .cross_align(Alignment::Center)
                    .spacing(12.)
                    .child(
                        Button::new()
                            .primary()
                            .child(Icon::new(IconType::Terminal).size(16.))
                            .text(if *running.read() { "Running…" } else { "Run" })
                            .on_press(move |_| run_sql(query, result, running)),
                    )
                    .child(
                        label()
                            .text(if cfg!(target_os = "macos") {
                                "⌘ Enter"
                            } else {
                                "Ctrl+Enter"
                            })
                            .font_size(text_size(12.))
                            .color(colors::fg_secondary()),
                    ),
            )
            .child(sql_result(&result.read()))
            .into_element()
    }
}

fn run_sql(query: State<String>, mut result: State<SqlResult>, mut running: State<bool>) {
    if *running.read() {
        return;
    }
    let sql = query.read().clone();
    if sql.trim().is_empty() {
        return;
    }

    running.set(true);
    spawn(async move {
        let res = match crate::launcher::state() {
            Ok(state) => run_console_query(&state.services.db, &sql)
                .await
                .map_err(|e| e.to_string()),
            Err(e) => Err(e.to_string()),
        };
        result.set(Some(res));
        running.set(false);
    });
}

fn sql_result(state: &SqlResult) -> Element {
    match state {
        None => label()
            .text("No query run yet.")
            .font_size(text_size(13.))
            .color(colors::fg_secondary())
            .into_element(),
        Some(Err(err)) => rect()
            .width(Size::fill())
            .padding(Gaps::new_symmetric(10., 14.))
            .corner_radius(rounded(8.))
            .background(colors::component_bg())
            .border(border_all_color(1., colors::danger()))
            .child(
                label()
                    .text(err.clone())
                    .font_size(text_size(13.))
                    .color(colors::danger()),
            )
            .into_element(),
        Some(Ok(res)) if !res.is_select => label()
            .text(format!("OK, {} row(s) affected.", res.rows_affected))
            .font_size(text_size(13.))
            .color(colors::success())
            .into_element(),
        Some(Ok(res)) => sql_table(res),
    }
}

fn sql_table(res: &ConsoleQueryResult) -> Element {
    if res.columns.is_empty() {
        return label()
            .text("0 rows returned.")
            .font_size(text_size(13.))
            .color(colors::fg_secondary())
            .into_element();
    }

    let header = table_row(&res.columns, true);
    let mut table = rect()
        .vertical()
        .width(Size::fill())
        .corner_radius(rounded(8.))
        .border(border_all_color(1., colors::component_border()))
        .child(header);

    for row in &res.rows {
        table = table.child(table_row(row, false));
    }

    rect()
        .vertical()
        .width(Size::fill())
        .spacing(6.)
        .child(
            label()
                .text(format!("{} row(s)", res.rows.len()))
                .font_size(text_size(12.))
                .color(colors::fg_secondary()),
        )
        .child(table)
        .into_element()
}

fn table_row(cells: &[String], header: bool) -> Element {
    let mut row = rect()
        .horizontal()
        .width(Size::fill())
        .content(Content::Flex)
        .background(if header {
            colors::page_elevated()
        } else {
            colors::component_bg()
        });

    for cell in cells {
        row = row.child(
            rect()
                .width(Size::flex(1.0))
                .padding(Gaps::new_symmetric(6., 10.))
                .border(border_all_color(0.5, colors::component_border()))
                .child(
                    label()
                        .text(cell.clone())
                        .font_size(text_size(12.))
                        .max_lines(1)
                        .font_weight(if header {
                            FontWeight::SEMI_BOLD
                        } else {
                            FontWeight::NORMAL
                        })
                        .color(if header {
                            colors::fg_primary()
                        } else {
                            colors::fg_secondary()
                        }),
                ),
        );
    }

    row.into_element()
}

fn split_csv(raw: &str) -> Vec<String> {
    raw.split(',')
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty())
        .collect()
}

fn divider() -> impl IntoElement {
    crate::ui::divider()
        .margin(Gaps::new_symmetric(8., 0.))
        .corner_radius(rounded(1.))
        .into_element()
}

fn section(title: &'static str, rows: Vec<Element>) -> impl IntoElement {
    rect()
        .vertical()
        .width(Size::fill())
        .spacing(10.)
        .child(
            label()
                .text(title)
                .font_size(text_size(22.))
                .font_weight(FontWeight::SEMI_BOLD)
                .color(colors::fg_primary()),
        )
        .children(rows)
        .into_element()
}

fn toggle_row(title: &'static str, on: State<bool>) -> Element {
    rect()
        .horizontal()
        .width(Size::fill())
        .cross_align(Alignment::Center)
        .main_align(Alignment::SpaceBetween)
        .padding(Gaps::new_symmetric(10., 14.))
        .corner_radius(rounded(10.))
        .background(colors::page_elevated())
        .child(
            label()
                .text(title)
                .font_size(text_size(14.))
                .color(colors::fg_primary()),
        )
        .child(toggle(on))
        .into_element()
}

fn action_row(dispatch: &Actions, buttons: Vec<(&'static str, IconType)>) -> Element {
    let mut row = rect().horizontal().width(Size::fill()).spacing(12.);

    for (text, icon) in buttons {
        let mut button = Button::new()
            .secondary()
            .child(Icon::new(icon).size(16.))
            .text(text);

        if text == "Open Onboarding" {
            let dispatch = dispatch.clone();
            button = button.on_press(move |_| {
                dispatch.reset_onboarding();
                let _ = RouterContext::get().replace(Route::OnboardingWelcome {});
            });
        }

        row = row.child(button);
    }

    row.into_element()
}
