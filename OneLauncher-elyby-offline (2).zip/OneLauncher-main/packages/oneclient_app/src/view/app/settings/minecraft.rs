use freya::prelude::*;
use oneclient_common::Patch;
use oneclient_core::settings::{
    GameSettingsProfile, PackageUpdateMode, ProfileUpdate, Resolution, SettingsOsExtra,
};

use super::settings_page;
use crate::Route;
use crate::components::{
    Dropdown, Icon, IconType, TextInput, memory_field, toggle, validate_number,
};
use crate::hooks::{use_dispatch, use_settings_snapshot};
use crate::i18n::t;
use crate::layout::SearchItem;
use crate::theme::colors;
use crate::view::app::settings::{resettable, resettable_all, section_header, settings_row};

#[derive(PartialEq)]
pub struct SettingsMinecraft;

impl Component for SettingsMinecraft {
    fn render(&self) -> impl IntoElement {
        let settings = use_settings_snapshot().settings;
        let profile = settings.global_game_settings.clone();
        let defaults = GameSettingsProfile::default_global_profile();
        let dispatch = use_dispatch();

        let fullscreen = use_state({
            let v = profile.force_fullscreen.unwrap_or(false);
            move || v
        });
        let width = use_state({
            let v = profile
                .resolution
                .map(|r| r.width.to_string())
                .unwrap_or_default();
            move || v
        });
        let height = use_state({
            let v = profile
                .resolution
                .map(|r| r.height.to_string())
                .unwrap_or_default();
            move || v
        });
        let memory = use_state({
            let v = profile.mem_max.map(|m| m.to_string()).unwrap_or_default();
            move || v
        });
        let jvm_args = use_state({
            let v = profile.launch_args.clone().unwrap_or_default();
            move || v
        });
        let game_args = use_state({
            let v = profile.game_args.clone().unwrap_or_default();
            move || v
        });
        let pre_launch_command = use_state({
            let v = profile.hook_pre.clone().unwrap_or_default();
            move || v
        });
        let wrapper_command = use_state({
            let v = profile.hook_wrapper.clone().unwrap_or_default();
            move || v
        });
        let post_exit_command = use_state({
            let v = profile.hook_post.clone().unwrap_or_default();
            move || v
        });
        let update_mode = use_state({
            let v = profile.browser_update_mode.unwrap_or_default();
            move || v
        });

        let gpu = use_state({
            let v = profile.gpu().map(str::to_owned);
            move || v
        });
        let gpus = use_state(oneclient_core::game::gpu::detect);

        let mut first = use_state(|| true);
        use_side_effect(move || {
            let update = build_update(
                *fullscreen.read(),
                &width.read(),
                &height.read(),
                &memory.read(),
                &jvm_args.read(),
                &game_args.read(),
                &pre_launch_command.read(),
                &wrapper_command.read(),
                &post_exit_command.read(),
                *update_mode.read(),
            );
            let selected_gpu = gpu.read().clone();
            if *first.peek() {
                first.set(false);
                return;
            }

            let update = with_gpu(update, selected_gpu);

            dispatch.update_global_profile(update);
        });

        let page = settings_page()
            .child(section_header(t(
                "oneclient.settings.minecraft.section.game",
            )))
            .child(settings_row(
                IconType::Maximize01,
                t("oneclient.settings.minecraft.force_fullscreen.title"),
                t("oneclient.settings.minecraft.force_fullscreen.description"),
                resettable(
                    toggle(fullscreen),
                    fullscreen,
                    defaults.force_fullscreen.unwrap_or(false),
                ),
            ))
            .child(settings_row(
                IconType::LayoutTop,
                t("oneclient.settings.minecraft.resolution.title"),
                t("oneclient.settings.minecraft.resolution.description"),
                resettable_all(
                    resolution_field(width, height),
                    vec![
                        (
                            width,
                            defaults
                                .resolution
                                .map(|r| r.width.to_string())
                                .unwrap_or_default(),
                        ),
                        (
                            height,
                            defaults
                                .resolution
                                .map(|r| r.height.to_string())
                                .unwrap_or_default(),
                        ),
                    ],
                ),
            ))
            .child(settings_row(
                IconType::Database01,
                t("oneclient.settings.minecraft.memory.title"),
                t("oneclient.settings.minecraft.memory.description"),
                resettable(
                    memory_field(
                        memory,
                        t("oneclient.common.default"),
                        oneclient_common::default_mem_max(),
                    ),
                    memory,
                    String::new(),
                ),
            ))
            .child(settings_row(
                IconType::Terminal,
                t("oneclient.settings.minecraft.jvm_args.title"),
                t("oneclient.settings.minecraft.jvm_args.description"),
                resettable(
                    TextInput::new(jvm_args)
                        .placeholder("-XX:+UseG1GC")
                        .expandable(true)
                        .width(Size::px(220.)),
                    jvm_args,
                    defaults.launch_args.clone().unwrap_or_default(),
                ),
            ))
            .child(settings_row(
                IconType::Play,
                t("oneclient.settings.minecraft.game_args.title"),
                t("oneclient.settings.minecraft.game_args.description"),
                resettable(
                    TextInput::new(game_args)
                        .placeholder("--tracy --tracyNoImages")
                        .expandable(true)
                        .width(Size::px(220.)),
                    game_args,
                    defaults.game_args.clone().unwrap_or_default(),
                ),
            ))
            .child(section_header(t(
                "oneclient.settings.minecraft.section.content",
            )))
            .child(settings_row(
                IconType::RefreshCw01,
                t("oneclient.settings.minecraft.browser_updates.title"),
                t("oneclient.settings.minecraft.browser_updates.description"),
                resettable(
                    update_mode_field(update_mode),
                    update_mode,
                    defaults.browser_update_mode.unwrap_or_default(),
                ),
            ))
            .child(section_header(t(
                "oneclient.settings.minecraft.section.process",
            )))
            .child(settings_row(
                IconType::FilePlus02,
                t("oneclient.settings.minecraft.pre_launch.title"),
                t("oneclient.settings.minecraft.pre_launch.description"),
                resettable(
                    TextInput::new(pre_launch_command)
                        .placeholder("echo 'Game started'")
                        .expandable(true)
                        .width(Size::px(220.)),
                    pre_launch_command,
                    defaults.hook_pre.clone().unwrap_or_default(),
                ),
            ))
            .child(settings_row(
                IconType::ParagraphWrap,
                t("oneclient.settings.minecraft.wrapper.title"),
                t("oneclient.settings.minecraft.wrapper.description"),
                resettable(
                    TextInput::new(wrapper_command)
                        .placeholder("gamescope")
                        .expandable(true)
                        .width(Size::px(220.)),
                    wrapper_command,
                    defaults.hook_wrapper.clone().unwrap_or_default(),
                ),
            ))
            .child(settings_row(
                IconType::FileX02,
                t("oneclient.settings.minecraft.post_exit.title"),
                t("oneclient.settings.minecraft.post_exit.description"),
                resettable(
                    TextInput::new(post_exit_command)
                        .placeholder("echo 'Game exited'")
                        .expandable(true)
                        .width(Size::px(220.)),
                    post_exit_command,
                    defaults.hook_post.clone().unwrap_or_default(),
                ),
            ));

        let page = if gpus.read().is_empty() {
            page
        } else {
            page.child(section_header(t(
                "oneclient.settings.minecraft.section.graphics",
            )))
            .child(settings_row(
                IconType::Rocket02,
                t("oneclient.settings.minecraft.gpu.title"),
                t("oneclient.settings.minecraft.gpu.description"),
                resettable(gpu_field(gpu, &gpus.read()), gpu, None),
            ))
        };

        page.into_element()
    }
}

fn with_gpu(mut update: ProfileUpdate, gpu: Option<String>) -> ProfileUpdate {
    let base = crate::launcher::state()
        .ok()
        .and_then(|state| state.settings.read().global_game_settings.os_extra.clone())
        .unwrap_or_default();

    update.os_extra = Patch::Set(SettingsOsExtra { gpu, ..base });
    update
}

fn gpu_field(
    mut selected: State<Option<String>>,
    gpus: &[oneclient_core::game::gpu::Gpu],
) -> impl IntoElement {
    let system_default = t("oneclient.settings.minecraft.gpu.system_default");

    let default = oneclient_core::game::gpu::DEFAULT;

    let current = selected
        .read()
        .as_deref()
        .or(default)
        .and_then(|id| gpus.iter().find(|gpu| gpu.id == id))
        .map_or(system_default.to_string(), |gpu| gpu.name.clone());

    let offset = usize::from(default.is_none());
    let options = std::iter::repeat_n(system_default.to_string(), offset)
        .chain(gpus.iter().map(|gpu| gpu.name.clone()))
        .collect();
    let ids: Vec<String> = gpus.iter().map(|gpu| gpu.id.clone()).collect();

    Dropdown::new(current, options)
        .width(Size::px(220.))
        .height(Size::px(34.))
        .on_select(move |idx: usize| {
            selected.set(idx.checked_sub(offset).and_then(|i| ids.get(i).cloned()));
        })
}

#[allow(clippy::too_many_arguments)]
fn build_update(
    fullscreen: bool,
    width: &str,
    height: &str,
    memory: &str,
    jvm_args: &str,
    game_args: &str,
    pre: &str,
    wrapper: &str,
    post: &str,
    update_mode: PackageUpdateMode,
) -> ProfileUpdate {
    let resolution = match (width.trim(), height.trim()) {
        ("", "") => Patch::Clear,
        (w, h) => match (w.parse::<u32>(), h.parse::<u32>()) {
            (Ok(w), Ok(h)) => Patch::Set(Resolution::new(w, h)),
            _ => Patch::Unchanged,
        },
    };

    let mem_max = match memory.trim() {
        "" => Patch::Clear,
        m => m.parse::<u32>().map(Patch::Set).unwrap_or(Patch::Unchanged),
    };

    ProfileUpdate {
        force_fullscreen: Patch::Set(fullscreen),
        resolution,
        mem_max,
        launch_args: command_patch(jvm_args),
        game_args: command_patch(game_args),
        hook_pre: command_patch(pre),
        hook_wrapper: command_patch(wrapper),
        hook_post: command_patch(post),
        browser_update_mode: Patch::Set(update_mode),
        ..Default::default()
    }
}

fn update_mode_field(mut selected: State<PackageUpdateMode>) -> impl IntoElement {
    let options: Vec<String> = PackageUpdateMode::ALL
        .iter()
        .map(|mode| mode.label().to_string())
        .collect();

    Dropdown::new(selected.read().label(), options)
        .width(Size::px(220.))
        .height(Size::px(34.))
        .on_select(move |idx: usize| {
            if let Some(mode) = PackageUpdateMode::ALL.get(idx).copied() {
                selected.set(mode);
            }
        })
}

fn command_patch(value: &str) -> Patch<String> {
    match value.trim() {
        "" => Patch::Clear,
        v => Patch::Set(v.to_string()),
    }
}

fn resolution_field(width: State<String>, height: State<String>) -> impl IntoElement {
    rect()
        .horizontal()
        .cross_align(Alignment::Center)
        .spacing(8.)
        .child(
            TextInput::new(width)
                .placeholder("854")
                .on_validate(validate_number)
                .text_align(TextAlign::Center)
                .width(Size::px(70.))
                .text_align(TextAlign::Center),
        )
        .child(
            Icon::new(IconType::X)
                .size(14.)
                .color(colors::fg_secondary()),
        )
        .child(
            TextInput::new(height)
                .placeholder("480")
                .on_validate(validate_number)
                .text_align(TextAlign::Center)
                .width(Size::px(70.))
                .text_align(TextAlign::Center),
        )
        .into_element()
}

inventory::submit! {
    SearchItem {
        id: "minecraft.force_fullscreen",
        icon: IconType::Maximize01,
        title: "oneclient.settings.minecraft.force_fullscreen.title",
        description: "oneclient.settings.minecraft.force_fullscreen.description",
        keywords: &["fullscreen", "window"],
        route: Route::SettingsMinecraft {},
    }
}

inventory::submit! {
    SearchItem {
        id: "minecraft.resolution",
        icon: IconType::LayoutTop,
        title: "oneclient.settings.minecraft.resolution.title",
        description: "oneclient.settings.minecraft.resolution.description",
        keywords: &["width", "height", "window size", "resolution"],
        route: Route::SettingsMinecraft {},
    }
}

inventory::submit! {
    SearchItem {
        id: "minecraft.memory",
        icon: IconType::Database01,
        title: "oneclient.settings.minecraft.memory.title",
        description: "oneclient.layout.search.minecraft.memory.description",
        keywords: &["ram", "memory", "heap", "xmx"],
        route: Route::SettingsMinecraft {},
    }
}

inventory::submit! {
    SearchItem {
        id: "minecraft.pre_launch",
        icon: IconType::FilePlus02,
        title: "oneclient.settings.minecraft.pre_launch.title",
        description: "oneclient.settings.minecraft.pre_launch.description",
        keywords: &["hook", "command", "pre launch", "prelaunch"],
        route: Route::SettingsMinecraft {},
    }
}

inventory::submit! {
    SearchItem {
        id: "minecraft.wrapper",
        icon: IconType::ParagraphWrap,
        title: "oneclient.settings.minecraft.wrapper.title",
        description: "oneclient.settings.minecraft.wrapper.description",
        keywords: &["hook", "command", "wrapper", "gamescope"],
        route: Route::SettingsMinecraft {},
    }
}

inventory::submit! {
    SearchItem {
        id: "minecraft.post_exit",
        icon: IconType::FileX02,
        title: "oneclient.settings.minecraft.post_exit.title",
        description: "oneclient.settings.minecraft.post_exit.description",
        keywords: &["hook", "command", "post exit", "postexit"],
        route: Route::SettingsMinecraft {},
    }
}

inventory::submit! {
    SearchItem {
        id: "minecraft.jvm_args",
        icon: IconType::Terminal,
        title: "oneclient.settings.minecraft.jvm_args.title",
        description: "oneclient.settings.minecraft.jvm_args.description",
        keywords: &["jvm", "java", "arguments", "args", "flags", "gc"],
        route: Route::SettingsMinecraft {},
    }
}

inventory::submit! {
    SearchItem {
        id: "minecraft.game_args",
        icon: IconType::Play,
        title: "oneclient.settings.minecraft.game_args.title",
        description: "oneclient.settings.minecraft.game_args.description",
        keywords: &["game", "arguments", "args", "launch options"],
        route: Route::SettingsMinecraft {},
    }
}

inventory::submit! {
    SearchItem {
        id: "minecraft.browser_updates",
        icon: IconType::RefreshCw01,
        title: "oneclient.settings.minecraft.browser_updates.title",
        description: "oneclient.settings.minecraft.browser_updates.description",
        keywords: &["update", "mods", "auto update", "content"],
        route: Route::SettingsMinecraft {},
    }
}
