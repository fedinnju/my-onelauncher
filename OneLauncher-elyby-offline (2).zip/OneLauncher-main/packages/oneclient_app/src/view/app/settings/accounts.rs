use chrono::{DateTime, Utc};
use freya::animation::{AnimNum, Function, OnFinish, use_animation};
use freya::prelude::*;
use oneclient_auth::{AccountKind, MinecraftAccount};
use uuid::Uuid;

use super::{section_header, settings_page};
use crate::Route;
use crate::components::{
    Avatar, Button, ElyLogin, Icon, IconType, MicrosoftLogin, PlayerModel, use_ely_login,
    use_microsoft_login, use_offline_login,
};
use crate::hooks::{
    RefreshAccountKeys, RemoveAccountKeys, SetDefaultAccountKeys, try_accounts,
    try_default_account, use_accounts, use_current_account, use_refresh_account,
    use_remove_account, use_set_default_account,
};
use crate::i18n::t;
use crate::layout::SearchItem;
use crate::theme::{colors, rounded, text_size};
use crate::ui::border_all_color;

/// The shader scales the model off `res.y` alone so height makes the player bigger width only needs to clear the arms
const MODEL_WIDTH_PX: f32 = 160.;
const MODEL_HEIGHT_PX: f32 = 264.;

const AVATAR_SIZE_PX: f32 = 36.;

#[derive(PartialEq)]
pub struct SettingsAccounts;

impl Component for SettingsAccounts {
    fn render(&self) -> impl IntoElement {
        let accounts_query = use_accounts();
        let default_query = use_current_account();

        let msa = use_microsoft_login();
        let ely = use_ely_login();
        let offline = use_offline_login();
        let set_default = use_set_default_account();
        let remove = use_remove_account();
        let refresh = use_refresh_account();

        let accounts = try_accounts(&accounts_query).unwrap_or_default();
        let default_account = try_default_account(&default_query);
        let default_id = default_account.as_ref().map(|a| a.id);

        let mut rows: Vec<Element> = accounts
            .iter()
            .map(|account| {
                AccountRow {
                    id: account.id,
                    username: account.username.clone(),
                    kind: account.kind,
                    expires: account.expires,
                    signed_out: account.needs_sign_in(),
                    is_default: Some(account.id) == default_id,
                    set_default,
                    remove,
                    refresh,
                    sign_in: msa.clone(),
                    ely: ely.clone(),
                }
                .into_element()
            })
            .collect();
        if rows.is_empty() {
            rows.push(empty_state());
        }

        settings_page()
            .child(hero(
                default_account,
                msa.pending,
                msa.error.clone(),
                ely.pending,
                ely.error.clone(),
                {
                    let open_offline = offline.clone();
                    move |_| open_offline.start()
                },
                {
                    let open_ely = ely.clone();
                    move |_| open_ely.start()
                },
                {
                    let msa = msa.clone();
                    move |_| msa.start()
                },
            ))
            .child(section_header(t(
                "oneclient.settings.accounts.section.your_accounts",
            )))
            .children(rows)
            .maybe_child(offline.popup())
            .maybe_child(ely.popup())
            .maybe_child(msa.popup())
            .into_element()
    }
}

fn hero(
    account: Option<MinecraftAccount>,
    microsoft_pending: bool,
    microsoft_error: Option<String>,
    ely_pending: bool,
    ely_error: Option<String>,
    on_open_offline: impl FnMut(Event<PressEventData>) + 'static,
    on_open_ely: impl FnMut(Event<PressEventData>) + 'static,
    on_add_microsoft: impl FnMut(Event<PressEventData>) + 'static,
) -> impl IntoElement {
    let (name, subtitle) = match &account {
        Some(account) if account.needs_sign_in() => (
            account.username.clone(),
            t("oneclient.settings.accounts.hero.signed_out"),
        ),
        Some(account) => (account.username.clone(), kind_label(account.kind)),
        None => (
            t("oneclient.settings.accounts.hero.no_account").to_string(),
            t("oneclient.settings.accounts.hero.no_account_hint"),
        ),
    };

    // Every add path shares one error line the first failure wins
    let error = microsoft_error.or(ely_error);

    rect()
        .horizontal()
        .width(Size::fill())
        .content(Content::Flex)
        .cross_align(Alignment::Center)
        .spacing(16.)
        .padding(Gaps::new_all(16.))
        .corner_radius(rounded(12.))
        .background(colors::page_elevated())
        .child(model_frame(account.as_ref().map(|account| account.id)))
        .child(
            rect()
                .vertical()
                .width(Size::flex(1.0))
                .spacing(16.)
                .child(
                    rect()
                        .vertical()
                        .width(Size::fill())
                        .spacing(2.)
                        .child(
                            label()
                                .text(t("oneclient.settings.accounts.hero.active_account"))
                                .font_size(text_size(11.))
                                .font_weight(FontWeight::MEDIUM)
                                .color(colors::fg_secondary()),
                        )
                        .child(
                            label()
                                .text(name)
                                .font_size(text_size(24.))
                                .font_weight(FontWeight::SEMI_BOLD)
                                .max_lines(1)
                                .color(colors::fg_primary()),
                        )
                        .child(
                            label()
                                .text(subtitle)
                                .font_size(text_size(12.))
                                .color(colors::fg_secondary()),
                        ),
                )
                .child(
                    rect()
                        .vertical()
                        .width(Size::fill())
                        .spacing(8.)
                        .child(
                            // The three buttons overflow the ~245px beside the model at the 800px minimum so they wrap
                            rect()
                                .horizontal()
                                .width(Size::fill())
                                .content(Content::wrap_spacing(8.))
                                .spacing(8.)
                                .child(
                                    Button::new()
                                        .primary()
                                        .enabled(!microsoft_pending)
                                        .on_press(on_add_microsoft)
                                        .child(Icon::new(IconType::Globe01).size(16.))
                                        .text(if microsoft_pending {
                                            t("oneclient.settings.accounts.signing_in")
                                        } else {
                                            t("oneclient.settings.accounts.add_microsoft")
                                        }),
                                )
                                .child(
                                    Button::new()
                                        .secondary()
                                        .enabled(!ely_pending)
                                        .on_press(on_open_ely)
                                        .child(Icon::new(IconType::Key01).size(16.))
                                        .text(t("oneclient.settings.accounts.add_ely")),
                                )
                                .child(
                                    Button::new()
                                        .secondary()
                                        .on_press(on_open_offline)
                                        .child(Icon::new(IconType::Plus).size(16.))
                                        .text(t("oneclient.settings.accounts.add_offline")),
                                ),
                        )
                        .map(error, |el, msg| {
                            el.child(hint_line(IconType::AlertTriangle, msg, colors::danger()))
                        }),
                ),
        )
        .into_element()
}

fn model_frame(id: Option<Uuid>) -> impl IntoElement {
    rect()
        .vertical()
        .cross_align(Alignment::Center)
        .spacing(6.)
        .child(
            rect()
                .width(Size::px(MODEL_WIDTH_PX))
                .height(Size::px(MODEL_HEIGHT_PX))
                .center()
                .overflow(Overflow::Clip)
                .corner_radius(rounded(12.))
                .background(colors::component_bg())
                .border(border_all_color(1., colors::component_border()))
                .child(match id {
                    Some(id) => PlayerModel::new(id)
                        .yaw(-0.5)
                        .width(Size::fill())
                        .height(Size::fill())
                        .into_element(),
                    None => Icon::new(IconType::Users01)
                        .size(28.)
                        .color(colors::fg_secondary())
                        .into_element(),
                }),
        )
        .maybe_child(id.map(|_| {
            label()
                .text(t("oneclient.settings.accounts.drag_to_rotate"))
                .font_size(text_size(10.))
                .color(colors::fg_secondary())
                .into_element()
        }))
        .into_element()
}

fn field_label(text: &str) -> impl IntoElement {
    label()
        .text(text.to_string())
        .font_size(text_size(11.))
        .font_weight(FontWeight::MEDIUM)
        .color(colors::fg_secondary())
        .into_element()
}

/// Sits in whatever is left of the hero beside the model so the text must wrap
fn hint_line(icon: IconType, text: String, color: Color) -> impl IntoElement {
    rect()
        .horizontal()
        .width(Size::fill())
        .content(Content::Flex)
        .cross_align(Alignment::Center)
        .spacing(6.)
        .child(Icon::new(icon).size(13.).color(color))
        .child(
            label()
                .text(text)
                .font_size(text_size(12.))
                .width(Size::flex(1.0))
                .color(color),
        )
        .into_element()
}

const REFRESH_SPIN_TIME: u64 = 800;

const REFRESHING_OPACITY: f32 = 0.7;

/// Only the identity half fades the sign-in and remove buttons stay crisp
const SIGNED_OUT_OPACITY: f32 = 0.45;

struct AccountRow {
    id: Uuid,
    username: String,
    kind: AccountKind,
    expires: DateTime<Utc>,
    signed_out: bool,
    is_default: bool,
    set_default: crate::hooks::UseSetDefaultAccount,
    remove: crate::hooks::UseRemoveAccount,
    refresh: crate::hooks::UseRefreshAccount,
    sign_in: MicrosoftLogin,
    ely: ElyLogin,
}

impl PartialEq for AccountRow {
    fn eq(&self, other: &Self) -> bool {
        self.id == other.id
            && self.username == other.username
            && self.kind == other.kind
            && self.expires == other.expires
            && self.signed_out == other.signed_out
            && self.is_default == other.is_default
            && self.sign_in.pending == other.sign_in.pending
            && self.ely.pending == other.ely.pending
    }
}

impl Component for AccountRow {
    fn render_key(&self) -> DiffKey {
        DiffKey::from(&self.id)
    }

    fn render(&self) -> impl IntoElement {
        let id = self.id;
        let is_default = self.is_default;
        let set_default = self.set_default;
        let remove = self.remove;
        let refresh = self.refresh;

        let is_microsoft = self.kind == AccountKind::Microsoft;
        let is_ely = self.kind == AccountKind::ElyBy;
        let refreshable = is_microsoft || is_ely;
        // The prop already carries the kind awareness needs_sign_in only
        // counts refreshable kinds
        let signed_out = self.signed_out;
        // A signed-out entry has no token left to call expired
        let expired = refreshable && !signed_out && self.expires <= Utc::now();
        let identity_opacity = if signed_out { SIGNED_OUT_OPACITY } else { 1. };
        let sign_in = self.sign_in.clone();
        let ely = self.ely.clone();

        let mut refreshing = use_state(|| false);
        let is_refreshing = *refreshing.read();

        let spin = use_animation(|conf| {
            conf.on_finish(OnFinish::restart());
            AnimNum::new(0., 360.)
                .time(REFRESH_SPIN_TIME)
                .function(Function::Linear)
        });

        use_side_effect_with_deps(&is_refreshing, move |&is_refreshing| {
            let mut spin = spin;
            if is_refreshing {
                spin.start();
            } else {
                spin.reset();
            }
        });

        let rotation = if is_refreshing {
            spin.get().value()
        } else {
            0.
        };

        let border_color = if signed_out {
            colors::component_border()
        } else if expired {
            colors::danger()
        } else if is_default {
            colors::brand()
        } else {
            colors::component_border()
        };

        rect()
            .horizontal()
            .width(Size::fill())
            .cross_align(Alignment::Center)
            .content(Content::Flex)
            .spacing(12.)
            .padding(Gaps::new_all(12.))
            .corner_radius(rounded(12.))
            .background(colors::page_elevated())
            .border(border_all_color(1., border_color))
            .opacity(if is_refreshing {
                REFRESHING_OPACITY
            } else {
                1.
            })
            .a11y_role(AccessibilityRole::Button)
            .maybe(!is_default && !signed_out, |el| {
                el.on_press(move |_| set_default.mutate(SetDefaultAccountKeys { id: Some(id) }))
            })
            .child(
                rect().opacity(identity_opacity).child(
                    Avatar::new(id.to_string())
                        .width(Size::px(AVATAR_SIZE_PX))
                        .height(Size::px(AVATAR_SIZE_PX)),
                ),
            )
            .child(
                rect()
                    .vertical()
                    .width(Size::flex(1.0))
                    .spacing(4.)
                    .opacity(identity_opacity)
                    .child(
                        rect()
                            .horizontal()
                            .cross_align(Alignment::Center)
                            .spacing(6.)
                            .child(
                                label()
                                    .text(self.username.clone())
                                    .font_size(text_size(15.))
                                    .font_weight(FontWeight::MEDIUM)
                                    .max_lines(1)
                                    .color(colors::fg_primary()),
                            )
                            .maybe_child(is_default.then(default_badge))
                            .maybe_child(expired.then(expired_badge))
                            .maybe_child(signed_out.then(signed_out_badge)),
                    )
                    // The kind rides with the id a third badge and a full uuid do not both fit
                    .child(
                        label()
                            .text(if signed_out {
                                t("oneclient.settings.accounts.session_expired").to_string()
                            } else {
                                format!("{} · {id}", kind_label(self.kind))
                            })
                            .font_size(text_size(11.))
                            .max_lines(1)
                            .color(colors::fg_secondary()),
                    ),
            )
            .maybe_child(signed_out.then(|| {
                // An Ely.by entry re-signs through its own dialog the Microsoft
                // one cannot fill an Ely.by session
                let (pending, tooltip) = if is_ely {
                    (
                        ely.pending,
                        t("oneclient.settings.accounts.sign_in_again_ely"),
                    )
                } else {
                    (
                        sign_in.pending,
                        t("oneclient.settings.accounts.sign_in_again"),
                    )
                };
                Button::new()
                    .secondary()
                    .enabled(!pending)
                    .tooltip(tooltip)
                    .on_press(move |e: Event<PressEventData>| {
                        e.stop_propagation();
                        if is_ely {
                            ely.start();
                        } else {
                            sign_in.start();
                        }
                    })
                    .child(Icon::new(IconType::Globe01).size(16.))
                    .text(if pending {
                        t("oneclient.settings.accounts.signing_in")
                    } else {
                        t("oneclient.settings.accounts.sign_in")
                    })
                    .into_element()
            }))
            .maybe_child((refreshable && !signed_out).then(|| {
                Button::new()
                    .ghost()
                    .icon()
                    .tooltip(t("oneclient.settings.accounts.refresh"))
                    .on_press(move |e: Event<PressEventData>| {
                        e.stop_propagation();
                        if *refreshing.peek() {
                            return;
                        }
                        refreshing.set(true);
                        spawn(async move {
                            refresh.mutate_async(RefreshAccountKeys { id }).await;
                            refreshing.set(false);
                        });
                    })
                    .child(
                        rect().rotate(rotation).child(
                            Icon::new(IconType::RefreshCw01)
                                .size(18.)
                                .color(if expired {
                                    colors::danger()
                                } else {
                                    colors::fg_secondary()
                                }),
                        ),
                    )
                    .into_element()
            }))
            .child(
                Button::new()
                    .ghost()
                    .icon()
                    .enabled(false)
                    .tooltip(t("oneclient.common.edit"))
                    .child(
                        Icon::new(IconType::Pencil01)
                            .size(18.)
                            .color(colors::fg_secondary()),
                    ),
            )
            .child(
                Button::new()
                    .ghost()
                    .icon()
                    .tooltip(t("oneclient.settings.accounts.remove"))
                    .on_press(move |e: Event<PressEventData>| {
                        e.stop_propagation();
                        remove.mutate(RemoveAccountKeys { id });
                    })
                    .child(
                        Icon::new(IconType::Trash01)
                            .size(18.)
                            .color(colors::fg_secondary()),
                    ),
            )
            .into_element()
    }
}

fn kind_label(kind: AccountKind) -> &'static str {
    match kind {
        AccountKind::Microsoft => "Microsoft",
        AccountKind::ElyBy => t("oneclient.settings.accounts.kind.ely"),
        AccountKind::Offline => t("oneclient.settings.accounts.kind.offline"),
    }
}

fn default_badge() -> impl IntoElement {
    badge(
        Icon::new(IconType::CheckCircle)
            .size(12.)
            .color(colors::brand())
            .into_element(),
        t("oneclient.common.default").to_string(),
        colors::brand(),
        colors::brand(),
    )
}

fn expired_badge() -> impl IntoElement {
    badge(
        Icon::new(IconType::AlertTriangle)
            .size(12.)
            .color(colors::danger())
            .into_element(),
        t("oneclient.settings.accounts.badge.expired").to_string(),
        colors::danger(),
        colors::danger(),
    )
}

fn signed_out_badge() -> impl IntoElement {
    badge(
        Icon::new(IconType::AlertTriangle)
            .size(12.)
            .color(colors::fg_secondary())
            .into_element(),
        t("oneclient.settings.accounts.badge.signed_out").to_string(),
        colors::component_border(),
        colors::fg_secondary(),
    )
}

fn badge(icon: impl IntoElement, text: String, border: Color, fg: Color) -> impl IntoElement {
    rect()
        .horizontal()
        .cross_align(Alignment::Center)
        .spacing(4.)
        .padding(Gaps::new_symmetric(2., 8.))
        .corner_radius(rounded(999.))
        .border(border_all_color(1., border))
        .background(colors::component_bg())
        .child(icon)
        .child(
            label()
                .text(text)
                .font_size(text_size(10.))
                .font_weight(FontWeight::MEDIUM)
                .color(fg),
        )
        .into_element()
}

fn empty_state() -> Element {
    rect()
        .vertical()
        .width(Size::fill())
        .center()
        .padding(Gaps::new_all(32.))
        .spacing(8.)
        .corner_radius(rounded(12.))
        .background(colors::page_elevated())
        .child(
            Icon::new(IconType::Users01)
                .size(32.)
                .color(colors::fg_secondary()),
        )
        .child(
            label()
                .text(t("oneclient.settings.accounts.empty"))
                .font_size(text_size(14.))
                .color(colors::fg_secondary()),
        )
        .into_element()
}

inventory::submit! {
    SearchItem {
        id: "nav.accounts",
        icon: IconType::Users01,
        title: "oneclient.layout.settings.tab.accounts",
        description: "oneclient.layout.search.nav.accounts.description",
        keywords: &["account", "login", "microsoft", "msa", "ely", "offline"],
        route: Route::SettingsAccounts {},
    }
}
