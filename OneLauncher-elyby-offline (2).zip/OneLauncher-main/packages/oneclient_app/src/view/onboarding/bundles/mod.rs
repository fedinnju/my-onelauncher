use std::collections::{HashMap, HashSet};

use freya::prelude::*;
use oneclient_content::packages::ProviderId;
use oneclient_core::BundleArchive;
use oneclient_core::clusters::Cluster;

use crate::components::ScrollArea;
use crate::hooks::{
    ClusterBundles, onboarding_bundles_items, package_meta_batch, query_error, query_is_loading,
    use_onboarding_bundles, use_onboarding_selection, use_package_meta_batch,
};
use crate::i18n::{t, tf};

type MetaMap = HashMap<String, oneclient_content::packages::CachedPackageMeta>;
use crate::routes::Route;
use crate::theme::{colors, rounded, text_size};
use crate::ui::{border_all_color, fixed_grid};
use crate::utils::bundle_display_name;
use crate::view::onboarding::{
    archive_selected, choice_row_sized, is_default_bundle, onboarding_nav, onboarding_slide,
    pkg_key, set_archive_selected, step_heading, version_chip,
};

mod row;
use row::{CARD_GRID_H, GRID_GAP, OnboardingModCard, empty_hint};

const CHIPS_PER_ROW: usize = 4;

const MOD_GRID_COLS: usize = 3;

const ANSWER_H: f32 = 48.;

const FPS_WARNING_BUNDLE: &str = "SkyBlock";

fn fps_warning_runs() -> [(&'static str, bool, bool); 7] {
    [
        (
            t("oneclient.onboarding.bundles.fps_warning.your"),
            false,
            false,
        ),
        (
            t("oneclient.onboarding.bundles.fps_warning.fps"),
            true,
            false,
        ),
        (
            t("oneclient.onboarding.bundles.fps_warning.will_be"),
            false,
            false,
        ),
        (
            t("oneclient.onboarding.bundles.fps_warning.significantly_worse"),
            true,
            false,
        ),
        (
            t("oneclient.onboarding.bundles.fps_warning.with_skyblock_mods"),
            false,
            false,
        ),
        (
            t("oneclient.onboarding.bundles.fps_warning.do_not_install"),
            true,
            true,
        ),
        (
            t("oneclient.onboarding.bundles.fps_warning.unless_hypixel"),
            false,
            true,
        ),
    ]
}

fn fps_warning_banner() -> impl IntoElement {
    let mut text = paragraph();
    for (run, bold, underlined) in &fps_warning_runs() {
        let mut span = Span::new(*run)
            .font_size(text_size(12.))
            .font_weight(if *bold {
                FontWeight::BOLD
            } else {
                FontWeight::NORMAL
            })
            .color(colors::code_warn());
        if *underlined {
            span = span.text_decoration(TextDecoration::Underline);
        }
        text = text.span(span);
    }

    rect()
        .width(Size::fill())
        .corner_radius(rounded(8.))
        .border(border_all_color(1., colors::code_warn()))
        .padding(Gaps::new_all(8.))
        .child(text)
}

#[derive(Clone)]
struct OptInBundle {
    display_name: String,
    members: Vec<(Cluster, BundleArchive)>,
}

impl OptInBundle {
    fn chosen(&self, selected: &HashSet<String>) -> Vec<i64> {
        self.members
            .iter()
            .filter(|(cluster, archive)| archive_selected(cluster.id, archive, selected))
            .map(|(cluster, _)| cluster.id)
            .collect()
    }

    fn wanted(&self, selected: &HashSet<String>) -> bool {
        !self.chosen(selected).is_empty()
    }

    fn mod_count(&self) -> usize {
        self.members
            .first()
            .map(|(_, a)| {
                a.manifest
                    .files
                    .iter()
                    .filter(|f| f.enabled && !f.hidden)
                    .count()
            })
            .unwrap_or(0)
    }
}

fn opt_in_bundles(clusters: &[ClusterBundles]) -> Vec<OptInBundle> {
    let mut order: Vec<String> = Vec::new();
    let mut map: HashMap<String, OptInBundle> = HashMap::new();

    for cb in clusters {
        for archive in &cb.archives {
            if is_default_bundle(archive) {
                continue;
            }
            let name = bundle_display_name(archive);
            let entry = map.entry(name.clone()).or_insert_with(|| {
                order.push(name.clone());
                OptInBundle {
                    display_name: name.clone(),
                    members: Vec::new(),
                }
            });
            entry.members.push((cb.cluster.clone(), archive.clone()));
        }
    }

    for bundle in map.values_mut() {
        bundle
            .members
            .sort_by(|(a, _), (b, _)| a.mc_version.cmp(&b.mc_version));
    }

    order.into_iter().filter_map(|n| map.remove(&n)).collect()
}

#[derive(Clone)]
struct OptionalMod {
    package_id: String,
    metadata_id: String,
    provider: ProviderId,
    github_hosted: bool,
    fallback_name: String,
    size: u64,
    /// `(cluster_id, bundle_name)` pairs this mod is available from
    locations: Vec<(i64, String)>,
}

impl OptionalMod {
    fn keys(&self) -> Vec<String> {
        self.locations
            .iter()
            .map(|(cluster_id, bundle)| pkg_key(*cluster_id, bundle, &self.package_id))
            .collect()
    }

    fn selected(&self, selected: &HashSet<String>) -> bool {
        self.keys().iter().any(|k| selected.contains(k))
    }
}

fn optional_mods(clusters: &[ClusterBundles]) -> Vec<OptionalMod> {
    let mut order: Vec<String> = Vec::new();
    let mut map: HashMap<String, OptionalMod> = HashMap::new();

    for cb in clusters {
        for archive in &cb.archives {
            for file in archive
                .manifest
                .files
                .iter()
                .filter(|f| f.is_optional_offer())
            {
                let package_id = file.kind.package_id();
                let entry = map.entry(package_id.clone()).or_insert_with(|| {
                    order.push(package_id.clone());
                    OptionalMod {
                        package_id: package_id.clone(),
                        metadata_id: file.kind.metadata_id(),
                        provider: file.kind.metadata_provider(),
                        github_hosted: file.is_github_hosted(),
                        fallback_name: file.display_name(),
                        size: file.size,
                        locations: Vec::new(),
                    }
                });
                entry
                    .locations
                    .push((cb.cluster.id, archive.manifest.name.clone()));
            }
        }
    }

    order.into_iter().filter_map(|n| map.remove(&n)).collect()
}

fn set_bundle_versions(
    mut selected: State<HashSet<String>>,
    mut user_touched: State<bool>,
    bundle: &OptInBundle,
    clusters: &[i64],
) {
    let mut set = selected.peek().clone();
    for (cluster, archive) in &bundle.members {
        let on = clusters.contains(&cluster.id);
        set_archive_selected(cluster.id, archive, on, &mut set);
    }
    user_touched.set(true);
    selected.set(set);
}

fn toggle_optional_mod(
    mut selected: State<HashSet<String>>,
    mut user_touched: State<bool>,
    entry: &OptionalMod,
) {
    let mut set = selected.peek().clone();
    let on = entry.selected(&set);
    for key in entry.keys() {
        if on {
            set.remove(&key);
        } else {
            set.insert(key);
        }
    }
    user_touched.set(true);
    selected.set(set);
}

#[derive(PartialEq)]
pub struct OnboardingBundles;

impl Component for OnboardingBundles {
    fn render(&self) -> impl IntoElement {
        let bundles_query = use_onboarding_bundles();
        let selection = use_onboarding_selection();
        let selected = selection.selected;
        let user_touched = selection.user_touched;

        let clusters = onboarding_bundles_items(&bundles_query).unwrap_or_default();
        let bundles_loaded = onboarding_bundles_items(&bundles_query).is_some();
        let catalog_msg = match query_error(&bundles_query) {
            Some(err) => tf("oneclient.onboarding.bundles.load_failed", &[&err]),
            None if query_is_loading(&bundles_query) => {
                t("oneclient.onboarding.bundles.loading").to_string()
            }
            None => t("oneclient.onboarding.bundles.empty").to_string(),
        };

        let selected_set = selected.read().clone();
        let opt_ins = opt_in_bundles(&clusters);
        let extras = optional_mods(&clusters);

        // Hooks so they run every render regardless of whether there are extras yet
        let (mr_ids, cf_ids, local_ids) = collect_ids(&extras);
        let mr_meta = package_meta_batch(&use_package_meta_batch(ProviderId::Modrinth, mr_ids));
        let cf_meta = package_meta_batch(&use_package_meta_batch(ProviderId::CurseForge, cf_ids));
        let local_meta = package_meta_batch(&use_package_meta_batch(ProviderId::Local, local_ids));

        let mut sections: Vec<Element> = Vec::new();

        for bundle in &opt_ins {
            sections
                .push(opt_in_card(bundle, &selected_set, selected, user_touched).into_element());
        }

        if !extras.is_empty() {
            sections.push(extras_section(
                &extras,
                &selected_set,
                selected,
                user_touched,
                &mr_meta,
                &cf_meta,
                &local_meta,
            ));
        }

        let nothing_to_ask = opt_ins.is_empty() && extras.is_empty();

        rect()
            .vertical()
            .width(Size::fill())
            .height(Size::fill())
            .content(Content::Flex)
            .child(onboarding_slide(
                rect()
                    .vertical()
                    .width(Size::fill())
                    .height(Size::fill())
                    .content(Content::Flex)
                    .padding(Gaps::new(40., 80., 12., 80.))
                    .spacing(16.)
                    .child(step_heading(
                        t("oneclient.onboarding.bundles.title"),
                        t("oneclient.onboarding.bundles.subtitle"),
                    ))
                    .child(
                        rect()
                            .vertical()
                            .width(Size::fill())
                            .height(Size::flex(1.0))
                            .content(Content::Flex)
                            .corner_radius(rounded(12.))
                            .background(colors::page_elevated())
                            .border(border_all_color(1., colors::component_border()))
                            .padding(Gaps::new_all(12.))
                            .child(
                                ScrollArea::new()
                                    .width(Size::fill())
                                    .height(Size::flex(1.0))
                                    .spacing(20.)
                                    .children(sections),
                            )
                            .maybe_child(nothing_to_ask.then(|| empty_hint(&catalog_msg))),
                    ),
            ))
            .child(onboarding_nav(
                Some(Route::OnboardingAccount {}),
                Route::OnboardingPreferences {},
                bundles_loaded,
            ))
    }
}

fn opt_in_card(
    bundle: &OptInBundle,
    selected_set: &HashSet<String>,
    selected: State<HashSet<String>>,
    user_touched: State<bool>,
) -> impl IntoElement {
    let name = bundle.display_name.clone();
    let wanted = bundle.wanted(selected_set);
    let chosen = bundle.chosen(selected_set);
    let all_ids: Vec<i64> = bundle.members.iter().map(|(c, _)| c.id).collect();

    let yes_bundle = bundle.clone();
    let yes_ids = all_ids.clone();
    let no_bundle = bundle.clone();

    let mut card = rect().vertical().width(Size::fill()).spacing(10.).child(
        label()
            .text(tf("oneclient.onboarding.bundles.opt_in.question", &[&name]))
            .font_size(text_size(15.))
            .font_weight(FontWeight::SEMI_BOLD)
            .color(colors::fg_primary()),
    );

    card = card.child(
        rect()
            .horizontal()
            .width(Size::fill())
            .spacing(8.)
            .content(Content::Flex)
            .child(
                rect()
                    .width(Size::flex(1.0))
                    .height(Size::px(ANSWER_H))
                    .child(choice_row_sized(
                        t("oneclient.common.yes"),
                        &tf(
                            "oneclient.onboarding.bundles.opt_in.mod_count",
                            &[&yes_bundle.mod_count()],
                        ),
                        wanted,
                        Size::fill(),
                        colors::fg_primary(),
                        move |()| {
                            if wanted {
                                return;
                            }
                            set_bundle_versions(selected, user_touched, &yes_bundle, &yes_ids)
                        },
                    )),
            )
            .child(
                rect()
                    .width(Size::flex(1.0))
                    .height(Size::px(ANSWER_H))
                    .child(choice_row_sized(
                        t("oneclient.common.no"),
                        "",
                        !wanted,
                        Size::fill(),
                        colors::fg_primary(),
                        move |()| set_bundle_versions(selected, user_touched, &no_bundle, &[]),
                    )),
            ),
    );

    if wanted && name.eq_ignore_ascii_case(FPS_WARNING_BUNDLE) {
        card = card.child(fps_warning_banner());
    }

    if wanted {
        let mut rows: Vec<Element> = Vec::new();
        for chunk in bundle.members.chunks(CHIPS_PER_ROW) {
            let mut row = rect().horizontal().spacing(8.);
            for (cluster, _) in chunk {
                let active = chosen.contains(&cluster.id);
                let chip_bundle = bundle.clone();
                let chosen_now = chosen.clone();
                let cluster_id = cluster.id;
                row = row.child(version_chip(&cluster.mc_version, active, move |()| {
                    let mut next = chosen_now.clone();
                    if active {
                        next.retain(|id| *id != cluster_id);
                    } else {
                        next.push(cluster_id);
                    }
                    set_bundle_versions(selected, user_touched, &chip_bundle, &next);
                }));
            }
            rows.push(row.into_element());
        }

        card = card.child(
            rect()
                .vertical()
                .width(Size::fill())
                .spacing(8.)
                .padding(Gaps::new(4., 0., 0., 0.))
                .child(
                    label()
                        .text(tf("oneclient.onboarding.bundles.opt_in.versions", &[&name]))
                        .font_size(text_size(13.))
                        .color(colors::fg_secondary()),
                )
                .child(rect().vertical().spacing(8.).children(rows)),
        );
    }

    card
}

fn extras_section(
    extras: &[OptionalMod],
    selected_set: &HashSet<String>,
    selected: State<HashSet<String>>,
    user_touched: State<bool>,
    mr_meta: &MetaMap,
    cf_meta: &MetaMap,
    local_meta: &MetaMap,
) -> Element {
    let cards: Vec<Element> = extras
        .iter()
        .map(|entry| {
            let meta = match entry.provider {
                ProviderId::Modrinth => mr_meta.get(&entry.metadata_id),
                ProviderId::CurseForge => cf_meta.get(&entry.metadata_id),
                ProviderId::Local => local_meta.get(&entry.metadata_id),
            };
            let name = meta
                .map(|m| m.name.clone())
                .filter(|n| !n.is_empty())
                .unwrap_or_else(|| entry.fallback_name.clone());
            let author = meta.map(|m| m.author.clone()).unwrap_or_default();
            let description = meta.map(|m| m.summary.clone()).unwrap_or_default();
            let icon_url = meta.and_then(|m| m.icon_url.clone());
            let toggle_entry = entry.clone();

            OnboardingModCard {
                provider: entry.provider,
                github_hosted: entry.github_hosted,
                name,
                author,
                description,
                icon_url,
                size: entry.size,
                enabled: entry.selected(selected_set),
                on_toggle: (move |()| toggle_optional_mod(selected, user_touched, &toggle_entry))
                    .into(),
            }
            .into_element()
        })
        .collect();

    rect()
        .vertical()
        .width(Size::fill())
        .spacing(10.)
        .child(
            label()
                .text(t("oneclient.onboarding.bundles.extras"))
                .font_size(text_size(15.))
                .font_weight(FontWeight::SEMI_BOLD)
                .color(colors::fg_primary()),
        )
        .child(fixed_grid(cards, MOD_GRID_COLS, CARD_GRID_H, GRID_GAP))
        .into_element()
}

fn collect_ids(extras: &[OptionalMod]) -> (Vec<String>, Vec<String>, Vec<String>) {
    let mut mr = Vec::new();
    let mut cf = Vec::new();
    let mut local = Vec::new();
    for entry in extras {
        match entry.provider {
            ProviderId::Modrinth => mr.push(entry.metadata_id.clone()),
            ProviderId::CurseForge => cf.push(entry.metadata_id.clone()),
            ProviderId::Local => local.push(entry.metadata_id.clone()),
        }
    }
    (mr, cf, local)
}
