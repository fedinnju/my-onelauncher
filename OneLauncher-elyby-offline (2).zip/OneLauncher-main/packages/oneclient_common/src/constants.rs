pub const DUMMY_REPLACE_NEWLINE: &str = "\n";

pub const MICROSOFT_CLIENT_ID: &str = "9419b7ee-1448-4d1b-b52a-550d8f36ab56";
pub const MINECRAFT_SCOPES: &str = "XboxLive.SignIn XboxLive.offline_access";
pub const CURSEFORGE_API_KEY: &str = "$2a$10$6utA1UNSmFPrE/Lh7b7ndeeGmiOkjKNY8kpFB0fsmE/d42ZAfFgCe";
pub const DISCORD_CLIENT_ID: &str = "1426999264633946334";

pub const MODRINTH_API_URL: &str = "https://api.modrinth.com";
pub const MODRINTH_CDN_PREFIX: &str = "https://cdn.modrinth.com/data/";
pub const CURSEFORGE_API_URL: &str = "https://api.curseforge.com/v1";
pub const CURSEFORGE_GAME_ID: u32 = 432;
pub const METADATA_API_URL: &str = "https://meta.polyfrost.org";
pub const MCLOGS_API_URL: &str = "https://api.mclo.gs/1";
pub const SKYCLIENT_BASE_URL: &str =
    "https://raw.githubusercontent.com/SkyblockClient/SkyblockClient-REPO/refs/heads/main/v1";
pub const META_URL_BASE: &str = "https://data-v2.polyfrost.org";
pub const TOS_URL: &str = "https://polyfrost.org/legal/terms";
pub const PRIVACY_URL: &str = "https://polyfrost.org/legal/privacy";
pub const PLUS_BACKEND_URL: &str = "https://plus.polyfrost.org";
pub const CRASH_DATA_URL: &str =
    "https://raw.githubusercontent.com/Polyfrost/CrashData/refs/heads/main/crashes.json";

/// The agent injects Ely.by's Yggdrasil endpoints into the game so its session
/// requests stop going to Mojang the URL is the metadata root authlib-injector
/// fetches at startup
pub const ELY_BY_AUTHLIB_INJECTOR_URL: &str = "https://authserver.ely.by/api/authlib-injector";

/// A release is pinned instead of floating "latest" so a launch never pulls an
/// untested agent underneath the user the sha1 is of that exact jar
pub const AUTHLIB_INJECTOR_VERSION: &str = "1.2.8";
pub const AUTHLIB_INJECTOR_JAR_URL: &str = "https://github.com/yushijinhun/authlib-injector/releases/download/v1.2.8/authlib-injector-1.2.8.jar";
pub const AUTHLIB_INJECTOR_JAR_SHA1: &str = "0e0e66d8a4f91a26f33b9c09f5cdffce4a11f0b8";
pub const AUTHLIB_INJECTOR_JAR_SIZE: u64 = 349_681;

pub const DISCORD_URL: &str = "https://discord.com/invite/polyfrost";

pub const SENTRY_DSN: &str = match option_env!("ONECLIENT_SENTRY_DSN") {
    Some(dsn) => dsn,
    None => {
        "https://e7dff7e07427e1a28b9212cfcc8ddc1e@o4511714343124992.ingest.us.sentry.io/4511714354135040"
    }
};

pub const LAUNCHER_LABEL: &str = concat!(
    "OneClient v",
    env!("CARGO_PKG_VERSION"),
    cfg_select! {
        debug_assertions => " (debug)",
        _ => " (release)"
    }
);

pub const TARGET_OS: &str = cfg_select! {
    target_os = "windows" => "windows",
    target_os = "macos" => "osx",
    target_os = "linux" => "linux"
};

pub const NATIVE_ARCH: &str = cfg_select! {
    target_arch = "x86" => "32",
    target_arch = "x86_64" => "64",
    _ => "64"
};

pub const JAVA_BIN: &str = if cfg!(windows) { "javaw.exe" } else { "java" };

pub const ARCH_WIDTH: &str = if cfg!(target_pointer_width = "64") {
    "64"
} else {
    "32"
};

pub const LINE_ENDING: &str = if cfg!(windows) { "\r\n" } else { "\n" };
pub const CLASSPATH_SEPARATOR: &str = if cfg!(windows) { ";" } else { ":" };
