//! Ely.by account authentication over the Yggdrasil protocol
//! documented at <https://docs.ely.by/en/minecraft-auth.html>
//! The accessToken the game receives is validated by the authlib-injector
//! agent which routes the session requests at Ely.by see the launch wiring in
//! `oneclient_core::game::authlib`

use chrono::{DateTime, TimeDelta, Utc};
use serde::Deserialize;
use uuid::Uuid;

use super::data::{AccountKind, MinecraftAccount};
use super::error::{AuthError, AuthResult, MinecraftAuthError, MinecraftAuthStep};

const ELY_AUTHSERVER: &str = "https://authserver.ely.by";

/// Passed as the javaagent argument so the game talks to Ely.by instead of
/// Mojang mirrors the metadata root the agent fetches at startup
pub const ELY_BY_AUTHLIB_INJECTOR_URL: &str = "https://authserver.ely.by/api/authlib-injector";

/// Fallback for tokens whose `exp` claim cannot be read Ely.by tokens live
/// until revoked but renewing on a schedule keeps a stale token from ever
/// reaching the game
const ELY_TOKEN_FALLBACK_LIFETIME: TimeDelta = TimeDelta::days(14);

/// Ely.by replies with this exact message when the account has TOTP enabled
/// the launcher then asks for a one-time code and retries with it appended to
/// the password as `password:token`
const TWO_FACTOR_MESSAGE: &str = "two factor";

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct YggdrasilProfile {
    id: String,
    name: String,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct YggdrasilAuthResponse {
    access_token: String,
    #[serde(default)]
    client_token: String,
    #[serde(default)]
    selected_profile: Option<YggdrasilProfile>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct YggdrasilError {
    #[serde(default)]
    error: Option<String>,
    #[serde(default)]
    error_message: Option<String>,
}

/// The Ely.by counterpart of [`crate::msa`] everything happens in one round
/// trip there is no profile discovery step the selected profile rides with the
/// token response
#[tracing::instrument(level = "debug", skip(http, password, totp), fields(login = %login))]
pub async fn authenticate_ely_account(
    http: &reqwest::Client,
    login: &str,
    password: &str,
    totp: Option<&str>,
) -> AuthResult<MinecraftAccount> {
    // A fresh clientToken per sign-in the server echoes it back and the saved
    // pair is what `/auth/refresh` later renews
    let client_token = Uuid::new_v4().to_string();
    // The Yggdrasil protocol has no field for a TOTP code so Ely.by overload
    // the password field with a `password:token` suffix
    let secret = match totp.map(str::trim).filter(|code| !code.is_empty()) {
        Some(code) => format!("{password}:{code}"),
        None => password.to_string(),
    };

    let body = serde_json::json!({
        "agent": {"name": "Minecraft", "version": 1},
        "username": login,
        "password": secret,
        "clientToken": client_token,
        "requestUser": true,
    });

    let response = http
        .post(format!("{ELY_AUTHSERVER}/auth/authenticate"))
        .json(&body)
        .send()
        .await
        .map_err(|err| MinecraftAuthError::RequestError {
            step: MinecraftAuthStep::ElyAuthenticate,
            source: err,
        })?;

    let status = response.status();
    let raw = response.text().await.map_err(|err| {
        MinecraftAuthError::RequestError {
            step: MinecraftAuthStep::ElyAuthenticate,
            source: err,
        }
    })?;

    if !status.is_success() {
        return Err(ely_error(status, &raw, MinecraftAuthStep::ElyAuthenticate));
    }

    let parsed: YggdrasilAuthResponse = serde_json::from_str(&raw).map_err(|err| {
        MinecraftAuthError::DeserializeError {
            step: MinecraftAuthStep::ElyAuthenticate,
            raw,
            source: err,
            status_code: status,
        }
    })?;

    let profile = parsed
        .selected_profile
        .ok_or_else(|| AuthError::ElyAuth {
            message: "the account has no Minecraft profile on Ely.by".into(),
        })?;

    let account = build_ely_account(
        parsed.access_token,
        parsed.client_token,
        profile,
    )?;
    tracing::info!(username = %account.username, "Ely.by sign-in succeeded");
    Ok(account)
}

/// Swaps a live accessToken for a fresh one the clientToken must match the one
/// the accessToken was issued with which is why it is kept in the store
#[tracing::instrument(level = "debug", skip(http, account), fields(username = %account.username))]
pub async fn refresh_ely_account(
    http: &reqwest::Client,
    account: &MinecraftAccount,
) -> Result<MinecraftAccount, MinecraftAuthError> {
    tracing::debug!("refreshing Ely.by account token");

    let body = serde_json::json!({
        "accessToken": account.access_token,
        "clientToken": account.refresh_token,
        "requestUser": true,
    });

    let response = http
        .post(format!("{ELY_AUTHSERVER}/auth/refresh"))
        .json(&body)
        .send()
        .await
        .map_err(|err| MinecraftAuthError::RequestError {
            step: MinecraftAuthStep::ElyRefresh,
            source: err,
        })?;

    let status = response.status();
    let raw = response
        .text()
        .await
        .map_err(|err| MinecraftAuthError::RequestError {
            step: MinecraftAuthStep::ElyRefresh,
            source: err,
        })?;

    if !status.is_success() {
        // A rejected token means only a fresh interactive sign-in can recover
        // the same contract `refresh_microsoft_account` follows
        if status == reqwest::StatusCode::UNAUTHORIZED
            || status == reqwest::StatusCode::FORBIDDEN
        {
            return Err(MinecraftAuthError::RefreshTokenRevoked {
                error: error_message(&raw).unwrap_or_else(|| format!("HTTP {status}")),
            });
        }

        return Err(MinecraftAuthError::ServiceError {
            step: MinecraftAuthStep::ElyRefresh,
            status_code: status,
        });
    }

    let parsed: YggdrasilAuthResponse = serde_json::from_str(&raw).map_err(|err| {
        MinecraftAuthError::DeserializeError {
            step: MinecraftAuthStep::ElyRefresh,
            raw,
            source: err,
            status_code: status,
        }
    })?;

    let profile = parsed
        .selected_profile
        .ok_or(MinecraftAuthError::HashError)?;

    // Ely.by ignores profile switching on refresh the uuid stays the one the
    // entry was created with
    Ok(MinecraftAccount {
        id: account.id,
        username: profile.name,
        expires: token_expiry(&parsed.access_token),
        access_token: parsed.access_token,
        refresh_token: parsed.client_token,
        kind: AccountKind::ElyBy,
        signed_out: false,
    })
}

fn build_ely_account(
    access_token: String,
    client_token: String,
    profile: YggdrasilProfile,
) -> AuthResult<MinecraftAccount> {
    let id = parse_profile_uuid(&profile.id)?;
    let expires = token_expiry(&access_token);

    Ok(MinecraftAccount {
        id,
        username: profile.name,
        access_token,
        // The Yggdrasil clientToken is the refresh credential for this kind
        refresh_token: client_token,
        expires,
        kind: AccountKind::ElyBy,
        signed_out: false,
    })
}

fn parse_profile_uuid(raw: &str) -> AuthResult<Uuid> {
    Uuid::parse_str(raw).map_err(|_| AuthError::ElyAuth {
        message: "Ely.by returned an unparseable profile uuid".into(),
    })
}

/// Ely.by access tokens are JWTs whose `exp` claim gives the real lifetime
/// tokens that are not readable JWTs get the fixed fallback window
fn token_expiry(access_token: &str) -> DateTime<Utc> {
    let expiry = access_token
        .split('.')
        .nth(1)
        .and_then(decode_jwt_claims)
        .and_then(|claims| claims.get("exp").and_then(serde_json::Value::as_i64))
        .and_then(|exp| DateTime::from_timestamp(exp, 0));

    expiry.unwrap_or_else(|| Utc::now() + ELY_TOKEN_FALLBACK_LIFETIME)
}

fn decode_jwt_claims(segment: &str) -> Option<serde_json::Value> {
    use base64::Engine as _;

    let decoded = base64::engine::general_purpose::URL_SAFE_NO_PAD
        .decode(segment.trim_end_matches('='))
        .ok()?;
    serde_json::from_slice(&decoded).ok()
}

/// Maps a Yggdrasil error body onto the typed errors the two-factor case gets
/// its own variant so the dialog can surface the code field
fn ely_error(
    status: reqwest::StatusCode,
    raw: &str,
    step: MinecraftAuthStep,
) -> AuthError {
    if status == reqwest::StatusCode::UNAUTHORIZED && is_two_factor_challenge(raw) {
        return AuthError::ElyTwoFactorRequired;
    }

    if status == reqwest::StatusCode::UNAUTHORIZED
        || status == reqwest::StatusCode::FORBIDDEN
    {
        return AuthError::ElyAuth {
            message: error_message(raw).unwrap_or_else(|| format!("HTTP {status}")),
        };
    }

    AuthError::Minecraft(MinecraftAuthError::ServiceError { step, status_code: status })
}

fn is_two_factor_challenge(raw: &str) -> bool {
    error_message(raw)
        .is_some_and(|message| message.to_lowercase().contains(TWO_FACTOR_MESSAGE))
}

fn error_message(raw: &str) -> Option<String> {
    serde_json::from_str::<YggdrasilError>(raw)
        .ok()
        .and_then(|parsed| {
            parsed
                .error_message
                .or(parsed.error)
        })
        .filter(|message| !message.is_empty())
}

/// The Ely.by profile lives on the same host under the authlib-injector layout
/// the response shape matches the Mojang session server so callers can reuse
/// the same parser
#[allow(dead_code)] // kept for callers that want to fetch skins/profiles later
pub fn session_profile_url(uuid: &str) -> String {
    let stripped = uuid.trim().replace('-', "");
    format!("{ELY_AUTHSERVER}/api/authlib-injector/sessionserver/session/minecraft/profile/{stripped}")
}

#[cfg(test)]
mod tests {
    use super::*;
    use base64::Engine as _;

    fn jwt_with_exp(exp: i64) -> String {
        let encode = |value: &str| {
            base64::engine::general_purpose::URL_SAFE_NO_PAD.encode(value)
        };
        format!("{}.{}.sig", encode(r#"{"alg":"RS256"}"#), encode(&format!(r#"{{"exp":{exp}}}"#)))
    }

    #[test]
    fn token_expiry_reads_the_jwt_claim() {
        let exp = Utc::now().timestamp() + 3600;
        let expiry = token_expiry(&jwt_with_exp(exp));

        assert_eq!(expiry.timestamp(), exp);
    }

    #[test]
    fn token_expiry_falls_back_when_the_token_is_not_a_jwt() {
        let before = Utc::now() + ELY_TOKEN_FALLBACK_LIFETIME;
        let expiry = token_expiry("opaque-ely-by-token");
        // Padded segments decode too Ely.by has issued both over the years
        assert!(
            (before - expiry).num_seconds().abs() < 5,
            "opaque tokens must get the fallback window"
        );
    }

    #[test]
    fn two_factor_challenges_are_recognised() {
        let raw = r#"{"error":"ForbiddenOperationException","errorMessage":"Account protected with two factor auth."}"#;

        assert!(is_two_factor_challenge(raw));
        assert_eq!(
            error_message(raw).as_deref(),
            Some("Account protected with two factor auth.")
        );
    }

    #[test]
    fn plain_credential_errors_are_not_two_factor() {
        let raw = r#"{"error":"ForbiddenOperationException","errorMessage":"Invalid credentials. Invalid username or password."}"#;

        assert!(!is_two_factor_challenge(raw));
    }

    #[test]
    fn session_profile_url_strips_dashes() {
        let url = session_profile_url("ffc8fdc9-5824-509e-8a57-c99b940fb996");

        assert_eq!(
            url,
            "https://authserver.ely.by/api/authlib-injector/sessionserver/session/minecraft/profile/ffc8fdc95824509e8a57c99b940fb996"
        );
    }
}
